# Signed envelope format

Ed25519 signs canonical UTF-8 JSON for the `payload` object (sorted keys, compact separators).
The signature carries `alg`, `key_id`, and base64 `value`. Trust keys are configured out-of-band;
never trust a key supplied only by the envelope.

Required claims: schema, environment, approval/request IDs, request SHA-256 digest, issuer,
approver, issue/expiry timestamps with timezone, exact repositories, exact operations,
human-approval claim, and unique nonce.

The verifier consumes a nonce once in a local SQLite ledger. Production requires a durable,
access-controlled, concurrency-safe replay store and a separately authenticated issuer key
distribution process.
