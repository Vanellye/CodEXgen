# PONS Signature Verifier — runnable reference

**TEST FIXTURES ONLY. This is not a PONS-issued approval.**

This package demonstrates Ed25519 signature validation, trusted-key lookup, exact two-repository
scope checks, operation allow-list checks, request-digest binding, expiry checks, and nonce replay
protection. It does not connect to GitHub or execute payments, swaps, trades, or deployments.

## Termux
```sh
pkg update -y
pkg install python unzip -y
unzip PONS-Signature-Verifier.zip
cd PONS-Signature-Verifier
python -m pip install -r requirements.txt
python -m pons_verifier verify fixtures/demo_approval.json --trust trust/demo_trust.json --ledger state/used.sqlite3 --request fixtures/request.json
```
Expected first run: `DEMO_SIGNATURE_VALID_NON_AUTHORIZING`. A second run rejects the same nonce as replay.

## Production boundary
The included private key is intentionally a public demo key. Never use it for real approvals.
A real PONS issuer must sign the exact request using a protected private key (preferably HSM/KMS).
Obtain the trusted public key/fingerprint independently, then integrate this verifier at the actual
write adapter. This reference intentionally rejects non-TEST_ONLY environments; production
deployment requires security review, a production trust store, durable replay protection, revocation,
independent human approval, and adapter-level enforcement.

No repository writes or financial actions are performed by this package.
