import unittest,tempfile,json
from pathlib import Path
from pons_verifier.core import verify
class FixtureTests(unittest.TestCase):
 def test_demo_fixture(self):
  with tempfile.TemporaryDirectory() as d:
   ok,msg=verify("fixtures/demo_approval.json","trust/demo_trust.json",Path(d)/"used.db","fixtures/request.json")
   self.assertTrue(ok,msg)
 def test_replay_fails(self):
  with tempfile.TemporaryDirectory() as d:
   db=Path(d)/"used.db"
   verify("fixtures/demo_approval.json","trust/demo_trust.json",db,"fixtures/request.json")
   ok,msg=verify("fixtures/demo_approval.json","trust/demo_trust.json",db,"fixtures/request.json")
   self.assertFalse(ok); self.assertEqual(msg,"replay detected")
if __name__=="__main__": unittest.main()
