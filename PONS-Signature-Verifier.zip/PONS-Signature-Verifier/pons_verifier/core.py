import base64, hashlib, json, sqlite3
from pathlib import Path
from datetime import datetime, timezone
from cryptography.hazmat.primitives.serialization import load_pem_public_key
from cryptography.exceptions import InvalidSignature

REPOS = ["Vanellye/Ash", "Vanellye/CodEXgen"]
OPS = ["create_isolated_branches", "write_scoped_files", "run_tests", "prepare_pull_requests"]

def canonical(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode()

def request_digest(path):
    return hashlib.sha256(canonical(json.loads(Path(path).read_text()))).hexdigest()

def verify(envelope_path, trust_path, ledger_path, request_path):
    try:
        env=json.loads(Path(envelope_path).read_text()); p=env["payload"]; s=env["signature"]
        trust=json.loads(Path(trust_path).read_text())["trusted_issuers"][s["key_id"]]
        if p.get("schema") != "pons.approval.v1": return False, "unsupported schema"
        if p.get("environment") != "TEST_ONLY" or trust.get("environment") != "TEST_ONLY":
            return False, "reference build refuses non-demo environment"
        key=load_pem_public_key(trust["public_key_pem"].encode())
        key.verify(base64.b64decode(s["value"], validate=True), canonical(p))
        if p.get("repositories") != REPOS: return False, "repository scope mismatch"
        if p.get("operations") != OPS: return False, "operation scope mismatch"
        if p.get("human_approval") is not True: return False, "human approval claim missing"
        for k in ["approval_id","request_id","request_digest","issuer","approver","nonce","issued_at","expires_at"]:
            if not isinstance(p.get(k),str) or not p[k].strip(): return False, "missing "+k
        if p["request_digest"] != request_digest(request_path): return False, "request digest mismatch"
        issued=datetime.fromisoformat(p["issued_at"].replace("Z","+00:00"))
        expires=datetime.fromisoformat(p["expires_at"].replace("Z","+00:00"))
        now=datetime.now(timezone.utc)
        if issued.tzinfo is None or expires.tzinfo is None: return False, "timestamps must include timezone"
        if issued > now or expires <= now or expires <= issued: return False, "approval expired or invalid"
        if len(p["nonce"]) < 16: return False, "nonce too short"
        db=Path(ledger_path); db.parent.mkdir(parents=True,exist_ok=True)
        with sqlite3.connect(db,timeout=10) as con:
            con.execute("CREATE TABLE IF NOT EXISTS used (nonce TEXT PRIMARY KEY, approval_id TEXT UNIQUE, consumed_at TEXT)")
            try:
                con.execute("INSERT INTO used VALUES (?,?,?)",(p["nonce"],p["approval_id"],now.isoformat()))
                con.commit()
            except sqlite3.IntegrityError:
                return False, "replay detected"
        return True, "DEMO_SIGNATURE_VALID_NON_AUTHORIZING"
    except InvalidSignature: return False, "invalid Ed25519 signature"
    except Exception as e: return False, "rejected: "+type(e).__name__+": "+str(e)
