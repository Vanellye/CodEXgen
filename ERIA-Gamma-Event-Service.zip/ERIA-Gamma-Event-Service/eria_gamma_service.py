#!/usr/bin/env python3
"""Independent, local-only ERIA Ɣ event service. Standard library only."""
import json, os, secrets, uuid
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs

HOST, PORT = "127.0.0.1", 8765
CONFIG = Path.home() / ".config" / "eria-gamma"
DATA = Path.home() / ".local" / "share" / "eria-gamma"
TOKEN_FILE = CONFIG / "token"
LOG_FILE = DATA / "events.jsonl"
MAX_BODY = 65536

def utc_now():
    return datetime.now(timezone.utc).isoformat()

def ensure_token():
    CONFIG.mkdir(parents=True, exist_ok=True)
    DATA.mkdir(parents=True, exist_ok=True)
    if not TOKEN_FILE.exists():
        TOKEN_FILE.write_text(secrets.token_urlsafe(32) + "\n")
        TOKEN_FILE.chmod(0o600)
    return TOKEN_FILE.read_text().strip()

TOKEN = ensure_token()

class Handler(BaseHTTPRequestHandler):
    server_version = "ERIA-Gamma/1.0"

    def log_message(self, fmt, *args):
        # Avoid logging authorization headers or request bodies.
        print("%s - %s" % (self.log_date_time_string(), fmt % args))

    def send_json(self, code, obj):
        raw = json.dumps(obj, separators=(",", ":"), ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(raw)

    def authorized(self):
        supplied = self.headers.get("Authorization", "")
        return secrets.compare_digest(supplied, "Bearer " + TOKEN)

    def do_GET(self):
        path = urlparse(self.path)
        if path.path == "/health":
            return self.send_json(200, {
                "service": "eria-gamma-event-service",
                "version": "1.0",
                "status": "ok",
                "bind": HOST,
                "port": PORT,
                "authority": "event-publication-only"
            })
        if path.path == "/v1/events":
            if not self.authorized():
                return self.send_json(401, {"error": "unauthorized"})
            try:
                limit = int(parse_qs(path.query).get("limit", ["100"])[0])
                limit = max(1, min(limit, 500))
            except ValueError:
                return self.send_json(400, {"error": "invalid limit"})
            if not LOG_FILE.exists():
                return self.send_json(200, {"events": []})
            lines = LOG_FILE.read_text(encoding="utf-8").splitlines()[-limit:]
            events = []
            for line in lines:
                try: events.append(json.loads(line))
                except json.JSONDecodeError: continue
            return self.send_json(200, {"events": events})
        return self.send_json(404, {"error": "not found"})

    def do_POST(self):
        if urlparse(self.path).path != "/v1/events":
            return self.send_json(404, {"error": "not found"})
        if not self.authorized():
            return self.send_json(401, {"error": "unauthorized"})
        try:
            size = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            return self.send_json(400, {"error": "invalid content length"})
        if size < 2 or size > MAX_BODY:
            return self.send_json(413, {"error": "body must be 2..65536 bytes"})
        try:
            body = json.loads(self.rfile.read(size))
        except (json.JSONDecodeError, UnicodeDecodeError):
            return self.send_json(400, {"error": "invalid JSON"})
        if not isinstance(body, dict):
            return self.send_json(400, {"error": "event must be a JSON object"})
        source, kind = body.get("source"), body.get("kind")
        payload = body.get("payload", {})
        if not isinstance(source, str) or not source.strip() or len(source) > 128:
            return self.send_json(400, {"error": "source must be a non-empty string <=128 chars"})
        if not isinstance(kind, str) or not kind.strip() or len(kind) > 128:
            return self.send_json(400, {"error": "kind must be a non-empty string <=128 chars"})
        if not isinstance(payload, (dict, list, str, int, float, bool, type(None))):
            return self.send_json(400, {"error": "payload must be JSON data"})
        event = {
            "schema": "ERIA-GAMMA-EVENT-1",
            "id": str(uuid.uuid4()),
            "timestamp": utc_now(),
            "source": source,
            "kind": kind,
            "payload": payload
        }
        DATA.mkdir(parents=True, exist_ok=True)
        with LOG_FILE.open("a", encoding="utf-8") as f:
            f.write(json.dumps(event, ensure_ascii=False, separators=(",", ":")) + "\n")
            f.flush()
            os.fsync(f.fileno())
        return self.send_json(201, {"accepted": True, "event": event})

def main():
    httpd = ThreadingHTTPServer((HOST, PORT), Handler)
    httpd.daemon_threads = True
    print(f"Ɣ event service listening on http://{HOST}:{PORT}")
    httpd.serve_forever()

if __name__ == "__main__":
    main()
