# Authority and service boundaries

```text
Ɣ Adaptability sources
        |
        v
Independent Ɣ Event Service -----> FORGE consumers
        |
        +-------------------------> PONS observer (read-only consumer)
                                      |
                                      v
                               Advisory findings
                                      |
                                      v
                           Local administrator decision
                                      |
                                      v
                         Authorized execution elsewhere
```

The event service transports and journals data. It does not make policy decisions.
PONS observes and recommends; it cannot approve, execute, or enforce blocks.
The local administrator controls privileged execution and device/repository permissions.
The event service has no Git integration, shell execution, remote listener, or privileged API.
