# Ɣ Event Contract

Protocol: `ERIA-GAMMA-EVENT-1`

Required fields:
- `source`: non-empty string, maximum 128 characters.
- `kind`: non-empty string, maximum 128 characters.
- `payload`: optional JSON value; treated strictly as data.

Service-generated fields:
- `schema`
- `id` (UUID)
- `timestamp` (UTC ISO-8601)

Suggested event names:
- `adaptability.signal`
- `adaptability.capability.discovered`
- `adaptability.capability.changed`
- `forge.module.registered`
- `forge.build.started`
- `forge.build.completed`
- `forge.build.failed`

These names are conventions, not executable commands. PONS can consume events and publish separate observation records in its own service. It does not gain authority over Ɣ or FORGE.
