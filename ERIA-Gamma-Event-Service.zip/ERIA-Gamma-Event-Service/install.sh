#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
PREFIX="${PREFIX:-$HOME/.local}"
mkdir -p "$PREFIX/bin" "$HOME/.config/eria-gamma" "$HOME/.local/share/eria-gamma"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
install -m 755 "$SCRIPT_DIR/bin/eria-gamma" "$PREFIX/bin/eria-gamma"
install -m 644 "$SCRIPT_DIR/eria_gamma_service.py" "$PREFIX/lib/eria-gamma-service.py"
echo "Installed: $PREFIX/bin/eria-gamma"
echo "Ensure $PREFIX/bin is on PATH."
