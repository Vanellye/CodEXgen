# ERIA Ɣ Independent Event Service

A standalone, local-first event service for ERIA FORGE. It is separate from PONS:
- Ɣ publishes adaptability and system events.
- PONS may subscribe as an observer and produce advisory findings.
- The local administrator remains the only authority for privileged execution.
- This service never executes commands, grants permissions, approves actions, or writes to Git repositories.

## Requirements
Python 3.10+ (Termux: `pkg install python`).

## Install
```bash
unzip ERIA-Gamma-Event-Service.zip
cd ERIA-Gamma-Event-Service
chmod +x install.sh
./install.sh
```

## Start
```bash
eria-gamma start
```
The service binds only to `127.0.0.1:8765`. On first start it creates a local API token in:
`~/.config/eria-gamma/token`

Keep that token private. Do not paste it into chat or commit it to Git.

## Check / stop
```bash
eria-gamma status
eria-gamma stop
```

## API
Send `Authorization: Bearer <token>` on write requests.

- `GET /health` — health and service identity; no token required.
- `GET /v1/events?limit=100` — read recent events; token required.
- `POST /v1/events` — append an event; token required.

Example:
```bash
TOKEN="$(cat ~/.config/eria-gamma/token)"
curl -s http://127.0.0.1:8765/health
curl -s -X POST http://127.0.0.1:8765/v1/events \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"source":"gamma.adaptability","kind":"adaptability.signal","payload":{"state":"ready"}}'
```

Events are appended to `~/.local/share/eria-gamma/events.jsonl`. Each record includes a UUID, UTC timestamp, source, kind, payload, and schema version. Payloads are data only; they are never interpreted as commands.

## Security boundaries
- Loopback-only listener; no LAN or public binding.
- Bearer token required for event reads/writes.
- Request body limit: 64 KiB.
- No shell execution, plugin loading, repository mutation, device control, or privileged actions.
- The event log is append-only through this API. Local filesystem administrators can still edit files.
- This is a starter service, not a hardened multi-user production daemon.
