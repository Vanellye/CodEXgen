#include "pantheon/runtime.hpp"
#include <iostream>
#include <fstream>
#include <thread>
#include <chrono>
#include <filesystem>
#include <ctime>
#include <algorithm>
#include <cstdlib>
static void usage(){std::cout<<"Pantheon ∞ / Ɣ runtime\n"
"  pantheon validate <file.pa>\n  pantheon watch <file.pa> [seconds]\n"
"  pantheon knowledge-add <ledger> <source> <claim>\n  pantheon knowledge-list <ledger>\n  pantheon gamma\n";}
static int validate(const std::string& f){pantheon::Runtime rt;auto r=rt.load(f);std::cout<<(r.ok?"PANTHEON VALID: ":"PANTHEON REJECTED: ")<<r.message<<"\n";for(auto&x:r.values)std::cout<<x.first<<" = "<<x.second<<"\n";return r.ok?0:1;}
static std::string clean(std::string s){for(char& c:s) if(c=='\t'||c=='\n'||c=='\r') c=' '; return s;}
int main(int argc,char**argv){
 if(argc<2){usage();return 2;}std::string cmd=argv[1];
 if(cmd=="validate"&&argc==3)return validate(argv[2]);
 if(cmd=="watch"&&(argc==3||argc==4)){
   int sec=argc==4?std::max(1,std::atoi(argv[3])):2;std::error_code ec;
   auto last=std::filesystem::last_write_time(argv[2],ec);if(ec){std::cerr<<"Cannot stat configuration\n";return 1;}
   int status=validate(argv[2]);std::cout<<"LIVE WATCH: valid configurations replace active policy; invalid edits are rejected.\n";
   while(true){std::this_thread::sleep_for(std::chrono::seconds(sec));auto now=std::filesystem::last_write_time(argv[2],ec);if(!ec&&now!=last){last=now;std::cout<<"--- configuration change detected ---\n";status=validate(argv[2]);std::cout<<(status==0?"ACTIVE CONFIGURATION ACCEPTED":"ACTIVE CONFIGURATION PRESERVED")<<"\n";}}
 }
 if(cmd=="knowledge-add"&&argc==5){std::ofstream o(argv[2],std::ios::app);if(!o){std::cerr<<"Cannot open ledger\n";return 1;}std::time_t t=std::time(nullptr);o<<t<<"\t"<<clean(argv[3])<<"\t"<<clean(argv[4])<<"\tUNREVIEWED\n";std::cout<<"Knowledge observation appended; status UNREVIEWED.\n";return 0;}
 if(cmd=="knowledge-list"&&argc==3){std::ifstream i(argv[2]);if(!i){std::cout<<"No knowledge ledger yet.\n";return 0;}std::string l;while(std::getline(i,l))std::cout<<l<<"\n";return 0;}
 if(cmd=="gamma"){std::cout<<"Ɣ / GAMMA: semantic event stream enabled as a namespace; source lineage and human review required.\n";return 0;}
 usage();return 2;
}
