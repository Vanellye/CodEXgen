# Ɣ Protocol v2 — reference draft

Adds adaptive exact-decimal arithmetic, direction metadata, Ed25519-signed provenance, portable Kotlin/JVM and C++ decoders, and an English↔binary dictionary.

## Numeric model
A value is `coefficient × 10^(-scale)`. For example `(1111111, 6)` is exactly `1.111111`. Supported operations are ADD, SUBTRACT, MULTIPLY and DIVIDE. Addition/subtraction align scales; multiplication adds scales; division chooses the smallest exact result scale from 0 through 18. Division that cannot be represented exactly is rejected; there is no implicit rounding. The adaptive flag (bit 0) says the encoder selected an exact result scale. Direction (`FORWARD`/`REVERSE`) is metadata and never silently reverses an operation.

## Binary record v2
All variable integers are unsigned LEB128; signed coefficients are ZigZag-encoded. Fixed byte fields are in listed order:

1. `GY` magic (47 59)
2. version `02`
3. direction `01` forward / `02` reverse
4. operation `01` add / `02` subtract / `03` multiply / `04` divide
5. flags (bit 0 adaptive; all other bits reserved)
6. sequence ULEB128
7. left coefficient (ZigZag ULEB128), left scale ULEB128
8. right coefficient, right scale
9. result coefficient, result scale
10. provenance byte length ULEB128 + UTF-8 provenance
11. Ed25519 raw public key (32 bytes)
12. Ed25519 signature (64 bytes) over all preceding record bytes, including public key

The reference decoders constrain coefficient values to signed 64-bit and scale to 0..18. Reject malformed input and trailing bytes.

## Signed provenance and trust
A valid signature establishes that the private key corresponding to the embedded public key signed these exact bytes. It does **not** establish the truth of the provenance claim or the real-world identity/authority of the signer. Applications must pin or otherwise validate trusted public keys out-of-band. The private key in `keys/` is a throwaway test key: never use it for production.

## “Never prints 0”
`.gya` armor is URL-safe Base64 without padding; digit `0` is represented as `~A`. The no-zero guarantee applies only to this printable armor. Raw binary and signatures may contain `00` bytes. Armor is transport formatting, not a change to the binary protocol.

## Build and test
Python reference: `python -m pip install cryptography`, then `python src/gamma_v2.py samples/add.gya`.

C++17 decoder (OpenSSL 3 + Boost headers): `g++ -std=c++17 src/gamma_decode.cpp -lcrypto -o gamma-decode`; run `./gamma-decode samples/add.gya`.

Kotlin/JVM decoder: `kotlinc src/GammaDecoder.kt -include-runtime -d gamma-decoder.jar`; run `java -jar gamma-decoder.jar samples/add.gya`. Requires a JDK/provider with Ed25519 support. Android API/provider availability varies; validate on the target API and use a vetted provider on older devices.

Samples are synthetic arithmetic demonstrations, not financial transactions, physical measurements, or evidence of external events.
