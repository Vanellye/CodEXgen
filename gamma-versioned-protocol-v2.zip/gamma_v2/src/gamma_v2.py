#!/usr/bin/env python3
"""Ɣ v2 reference decoder. Requires cryptography."""
import sys,base64,json
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
OPS={1:'ADD',2:'SUBTRACT',3:'MULTIPLY',4:'DIVIDE'}
def unarmor(s):
 s=s.replace('~A','0');return base64.urlsafe_b64decode(s+'='*((4-len(s)%4)%4))
def u(d,i):
 n=0;shift=0
 while True:
  if i>=len(d) or shift>=64:raise ValueError('invalid ULEB128')
  b=d[i];i+=1;n|=(b&127)<<shift
  if not b&128:return n,i
  shift+=7
def v(d,i):
 z,i=u(d,i);s,i=u(d,i);c=(z>>1)^-(z&1)
 if not -(1<<63)<=c<(1<<63) or s>18:raise ValueError('numeric range')
 return (c,s),i
def norm(c,s):
 while s and c and c%10==0:c//=10;s-=1
 if not -(1<<63)<=c<(1<<63):raise ValueError('result overflow')
 return c,s
def calc(op,a,b):
 x,s=a;y,t=b
 if op in (1,2):
  q=max(s,t);return norm(x*10**(q-s)+(1 if op==1 else -1)*y*10**(q-t),q)
 if op==3:return norm(x*y,s+t)
 if op==4:
  if y==0:raise ValueError('division by zero')
  for q in range(19):
   n=x*10**(t+q);den=y*10**s
   if n%den==0:return norm(n//den,q)
  raise ValueError('inexact division')
 raise ValueError('unknown opcode')
def dec(v):
 c,s=v;n=str(abs(c))
 if s:
  n=n.zfill(s+1);n=n[:-s]+'.'+n[-s:];n=n.rstrip('0').rstrip('.')
 return ('-' if c<0 else '')+n
def decode(d):
 if len(d)<102 or d[:3]!=b'GY\x02':raise ValueError('magic/version/short record')
 direction,op,flags=d[3:6]
 if direction not in (1,2) or op not in OPS or flags&~1:raise ValueError('invalid header')
 i=6;seq,i=u(d,i);a,i=v(d,i);b,i=v(d,i);r,i=v(d,i);ln,i=u(d,i)
 if ln>len(d)-i:raise ValueError('provenance length')
 prov=d[i:i+ln].decode('utf-8');i+=ln
 if i+96!=len(d):raise ValueError('record length/trailing bytes')
 pub,sig=d[i:i+32],d[i+32:i+96]
 Ed25519PublicKey.from_public_bytes(pub).verify(sig,d[:i+32])
 if calc(op,a,b)!=r:raise ValueError('arithmetic mismatch')
 return {'version':2,'direction':('FORWARD' if direction==1 else 'REVERSE'),'operation':OPS[op],'sequence':seq,'left':dec(a),'right':dec(b),'result':dec(r),'provenance':prov,'signature':'VALID; signer identity/trust not established'}
if __name__=='__main__':
 p=Path(sys.argv[1]);raw=unarmor(p.read_text().strip()) if p.suffix=='.gya' else p.read_bytes();print(json.dumps(decode(raw),indent=2))
