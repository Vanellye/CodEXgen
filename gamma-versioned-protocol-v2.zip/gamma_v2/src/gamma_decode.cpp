#include <openssl/evp.h>
#include <boost/multiprecision/cpp_int.hpp>
#include <fstream>
#include <iostream>
#include <vector>
#include <string>
#include <stdexcept>
#include <cstdint>
using namespace std;using boost::multiprecision::cpp_int;
uint64_t u(const vector<unsigned char>&d,size_t&i){uint64_t n=0;int sh=0;for(;;){if(i>=d.size()||sh>=64)throw runtime_error("bad ULEB");int b=d[i++];n|=uint64_t(b&127)<<sh;if(!(b&128))return n;sh+=7;}}
int64_t zz(uint64_t z){return int64_t((z>>1)^uint64_t(-int64_t(z&1)));}
struct V{int64_t c;uint64_t s;};V rdv(const vector<unsigned char>&d,size_t&i){V v{zz(u(d,i)),u(d,i)};if(v.s>18)throw runtime_error("scale range");return v;}
cpp_int p10(uint64_t n){cpp_int x=1;while(n--)x*=10;return x;}
V norm(cpp_int x,uint64_t s){while(s&&x!=0&&x%10==0){x/=10;--s;}if(x<INT64_MIN||x>INT64_MAX)throw runtime_error("coefficient overflow");return{x.convert_to<int64_t>(),s};}
V calc(int op,V a,V b){if(op==1||op==2){auto s=max(a.s,b.s);cpp_int x=cpp_int(a.c)*p10(s-a.s),y=cpp_int(b.c)*p10(s-b.s);cpp_int z=x;if(op==1)z+=y;else z-=y;return norm(z,s);}if(op==3)return norm(cpp_int(a.c)*b.c,a.s+b.s);if(op==4){if(!b.c)throw runtime_error("division by zero");for(int s=0;s<=18;s++){cpp_int n=cpp_int(a.c)*p10(b.s+s),den=cpp_int(b.c)*p10(a.s);if(n%den==0)return norm(n/den,s);}throw runtime_error("inexact division");}throw runtime_error("opcode");}
string dec(V v){cpp_int n=v.c;bool neg=n<0;if(neg)n=-n;string s=n.convert_to<string>();if(v.s){if(s.size()<=v.s)s=string(v.s+1-s.size(),'0')+s;s.insert(s.size()-v.s,1,'.');while(s.back()=='0')s.pop_back();if(s.back()=='.')s.pop_back();}return(neg?"-":"")+s;}
vector<unsigned char> armor(string s){string t;for(size_t i=0;i<s.size();){if(s[i]=='\n'||s[i]=='\r'||s[i]==' '||s[i]=='\t'){++i;continue;}if(s.compare(i,2,"~A")==0){t+='0';i+=2;}else{char c=s[i++];if(c=='-')c='+';if(c=='_')c='/';t+=c;}}while(t.size()%4)t+='=';vector<unsigned char>o(t.size()*3/4+4);int n=EVP_DecodeBlock(o.data(),(const unsigned char*)t.data(),t.size());if(n<0)throw runtime_error("bad armor");while(!t.empty()&&t.back()=='='){--n;t.pop_back();}o.resize(n);return o;}
bool verify(const unsigned char*m,size_t n,const unsigned char*pub,const unsigned char*sig){EVP_PKEY*k=EVP_PKEY_new_raw_public_key(EVP_PKEY_ED25519,nullptr,pub,32);EVP_MD_CTX*c=EVP_MD_CTX_new();bool ok=k&&c&&EVP_DigestVerifyInit(c,nullptr,nullptr,nullptr,k)==1&&EVP_DigestVerify(c,sig,64,m,n)==1;EVP_MD_CTX_free(c);EVP_PKEY_free(k);return ok;}
int main(int ac,char**av){try{if(ac!=2)throw runtime_error("usage: gamma-decode FILE");ifstream f(av[1],ios::binary);if(!f)throw runtime_error("open failed");string s((istreambuf_iterator<char>(f)),{});vector<unsigned char>d;if(string(av[1]).size()>=4&&string(av[1]).substr(string(av[1]).size()-4)==".gya")d=armor(s);else d.assign(s.begin(),s.end());if(d.size()<102||d[0]!='G'||d[1]!='Y'||d[2]!=2)throw runtime_error("magic/version/short record");int dir=d[3],op=d[4],flags=d[5];if((dir!=1&&dir!=2)||op<1||op>4||(flags&~1))throw runtime_error("header");size_t i=6;auto seq=u(d,i);V a=rdv(d,i),b=rdv(d,i),r=rdv(d,i);auto len=u(d,i);if(len>d.size()-i)throw runtime_error("provenance length");string prov(d.begin()+i,d.begin()+i+len);i+=len;if(i+96!=d.size())throw runtime_error("record length");if(!verify(d.data(),i+32,d.data()+i,d.data()+i+32))throw runtime_error("signature invalid");V q=calc(op,a,b);if(q.c!=r.c||q.s!=r.s)throw runtime_error("arithmetic mismatch");cout<<"v2 "<<(dir==1?"FORWARD":"REVERSE")<<" "<<vector<string>{"","ADD","SUBTRACT","MULTIPLY","DIVIDE"}[op]<<" #"<<seq<<"\n"<<dec(a)<<" ; "<<dec(b)<<" => "<<dec(r)<<"\nprovenance: "<<prov<<"\nsignature: valid (key trust not established)\n";}catch(exception&e){cerr<<"ERROR: "<<e.what()<<"\n";return 1;}}
