#!/usr/bin/env sh
set -eu
python src/gamma_v2.py samples/add.gya >/dev/null
python src/gamma_v2.py samples/divide.gya >/dev/null
./gamma-decode samples/add.gya >/dev/null
./gamma-decode samples/divide.gya >/dev/null
java -jar gamma-decoder.jar samples/add.gya >/dev/null
java -jar gamma-decoder.jar samples/divide.gya >/dev/null
! grep -q '0' samples/*.gya
printf 'All sample decoder and armor tests passed.\n'
