# PANTHEON ∞ / Ɣ / ASH — v0.4

Pantheon is the creation and intelligence layer above ASH. Ɣ (Gamma) is the semantic/event namespace for meaning-bearing events and lineage. PA (`.pa`) remains declarative: it describes policy and capabilities; it does not execute arbitrary native code.

## This milestone adds
- **Live configuration watch:** `pantheon watch` monitors a PA file. A valid edit is accepted; an invalid edit is rejected and the previously accepted configuration remains active. This is configuration hot-reload, not native-code hot-loading.
- **Persistent knowledge journal:** append and list observations. Entries are explicitly marked `UNREVIEWED`; the journal is not a verified knowledge base and is not tamper-proof.
- **Signed module tooling:** OpenSSL detached-signature scripts for module files. Trust-key provisioning, revocation, sandboxing, and approval remain operator responsibilities.
- **Federation security contract:** a protocol design for verified domains, signed envelopes, E2EE, replay prevention, quotas, and opt-in trust. No network federation transport is implemented yet.
- **ASH bridge contract:** typed request fields, default-deny authorization expectations, and audit requirements. No production ASH service connection is included.
- **Ɣ namespace:** identifies semantic events while retaining provenance.

## Build and test (Termux)
```sh
pkg update -y
pkg install clang make openssl unzip -y
unzip PANTHEON-ASH-GAMMA-v0.4.zip
cd PANTHEON-ASH-GAMMA-v0.4
make
make check
```

## Ɣ command registry
The supplied Termux command/package list is catalogued in Ɣ using the ơɣ language. It retains repository provenance and duplicate command candidates. Run `./pantheon gamma commands`, `./pantheon gamma command nc`, or `./pantheon gamma packages`. This is a registry, not an execution wrapper: it does not install packages or execute shell commands. See `language/ơɣ-language.md` and `language/termux.og`.

## Commands
```sh
./pantheon validate examples/ash-freedom.pa
./pantheon watch examples/ash-freedom.pa 2
./pantheon knowledge-add data/knowledge.tsv https://source.example 'A sourced observation'
./pantheon knowledge-list data/knowledge.tsv
./pantheon gamma
./pantheon gamma commands
./pantheon gamma command nc
./pantheon gamma packages
```
Stop watch mode with Ctrl-C. The knowledge journal creates its parent directory only if it already exists; create `data/` first with `mkdir -p data`.

## Detached module signatures
Generate a key pair (keep the private key offline):
```sh
openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:3072 -out module-private.pem
openssl pkey -in module-private.pem -pubout -out module-public.pem
./distribution/sign-module.sh examples/ash-freedom.pa module-private.pem ash-freedom.sig
./distribution/verify-module.sh examples/ash-freedom.pa module-public.pem ash-freedom.sig
```
Do not ship private keys with modules. A valid signature proves possession of the corresponding signing key; it does not prove the module is safe or truthful.

## Ɣ architecture
- Pantheon: creates and reasons over configurations, modules, and knowledge.
- Ɣ: semantic events, source lineage, and meaning-preserving exchange.
- ASH: banking and communication service boundary.
- PONS: authorization, consent, provenance, and accountable human review.

## Important boundaries
`payment_execution = UNLOCKED` is preserved as requested in PA. This runtime does not initiate or execute bank transfers. A configuration value cannot grant bank-provider permissions, verify identity, create legal authority, or override account-owner consent. Provider-specific authorization and compliance remain mandatory. No payment execution endpoint is implemented.

## Honest implementation status
Implemented: PA parsing/validation, file-watch configuration reload, append-only local observation journal, detached signature scripts, federation design contract, ASH bridge contract, Gamma command.

Not implemented: native plugin hot-loading, sandboxed module runtime, trusted-key registry/revocation, remote knowledge connectors, distributed federation transport, end-to-end encryption, production ASH bridge, provider credentials, or production deployment. No claim of omniscience or autonomous self-modification is made.
