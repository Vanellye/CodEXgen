# ơɣ — Ɣ package and capability language

`ơɣ` is the declarative adaptation layer for Termux command discovery. It preserves the distinction between a command token, its package provider, and its repository.

## Grammar sketch

```text
ơɣ {
  registry "termux";
  map "nc" => package("busybox") from repo("main");
  map "nc" => package("netcat-openbsd") from repo("main");
  map "nc" => package("nmap") from repo("main");
  capability "network.inspect" requires human_approval;
  execute = NEVER_IMPLICIT;
}
```

- `map` declares a candidate mapping; duplicate command names are valid and remain distinct.
- `package(...)` identifies the Termux package to inspect or install.
- `repo(...)` retains repository provenance (`main`, `x11-repo`, or `root-repo`).
- `capability` describes a permission boundary, not an automatic grant.
- `execute = NEVER_IMPLICIT` means registry discovery never launches commands.

## Runtime commands

- `./pantheon gamma commands` — list every command mapping.
- `./pantheon gamma command nc` — show all providers for `nc`.
- `./pantheon gamma packages` — list unique package names and source repositories.

This version compiles the supplied mapping set into the C++ registry. The `.og` file below is the human-readable ơɣ source manifest; the runtime does not yet parse arbitrary `.og` files.
