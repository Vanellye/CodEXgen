#!/bin/sh
set -eu
./pantheon validate examples/ash-freedom.pa >/dev/null
./pantheon knowledge-add /tmp/pantheon-test-ledger.tsv test-source 'test claim' >/dev/null
grep -q UNREVIEWED /tmp/pantheon-test-ledger.tsv
./pantheon knowledge-list /tmp/pantheon-test-ledger.tsv | grep -q 'test claim'
rm -f /tmp/pantheon-test-ledger.tsv
echo 'PANTHEON TESTS PASSED'
