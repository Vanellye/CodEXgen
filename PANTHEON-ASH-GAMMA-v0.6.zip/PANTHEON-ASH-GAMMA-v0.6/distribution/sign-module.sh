#!/bin/sh
set -eu
[ "$#" -eq 3 ] || { echo 'Usage: sign-module.sh <module.pa> <private-key.pem> <signature.out>'; exit 2; }
command -v openssl >/dev/null || { echo 'Install openssl first'; exit 1; }
openssl dgst -sha256 -sign "$2" -out "$3" "$1"
echo 'Module signed. Distribute the module, signature, and trusted public key separately.'
