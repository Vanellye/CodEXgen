#!/bin/sh
set -eu
[ "$#" -eq 3 ] || { echo 'Usage: verify-module.sh <module.pa> <public-key.pem> <signature>'; exit 2; }
command -v openssl >/dev/null || { echo 'Install openssl first'; exit 1; }
openssl dgst -sha256 -verify "$2" -signature "$3" "$1"
