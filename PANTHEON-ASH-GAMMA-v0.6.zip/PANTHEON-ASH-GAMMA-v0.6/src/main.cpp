#include "pantheon/runtime.hpp"
#include <iostream>
#include <fstream>
#include <thread>
#include <chrono>
#include <filesystem>
#include <ctime>
#include <algorithm>
#include <cstdlib>
#include <set>
#include <vector>
struct CommandMap { const char* token; const char* package; const char* repo; };
static const CommandMap commandMaps[] = {
 {"ab","apache2","main"},
 {"at","at","main"},
 {"bc","bc","main"},
 {"as","binutils","main"},
 {"bk","bk","main"},
 {"nc","busybox","main"},
 {"cc","clang","main"},
 {"[","coreutils","main"},
 {"lp","cups","main"},
 {"d8","d8","main"},
 {"sh","dash","main"},
 {"dx","dx","main"},
 {"ed","ed","main"},
 {"ef","electric-fence","main"},
 {"et","et","main"},
 {"fd","fd","main"},
 {"fm","fm","main"},
 {"fx","fx","main"},
 {"dl","gatling","main"},
 {"gh","gh","main"},
 {"gs","ghostscript","main"},
 {"gn","gn","main"},
 {"go","golang","main"},
 {"gm","graphicsmagick","main"},
 {"gc","graphviz","main"},
 {"gw","gw","x11-repo"},
 {"hx","helix","main"},
 {"hh","hstr","main"},
 {"hz","hz","main"},
 {"i3","i3","x11-repo"},
 {"ip","iproute2","main"},
 {"iw","iw","root-repo"},
 {"jo","jo","main"},
 {"jq","jq","main"},
 {"k","kona","main"},
 {"lf","lf","main"},
 {"pl","libgnustep-base","main"},
 {"h3","libuber-h3","main"},
 {"ld","lld","main"},
 {"ar","llvm","main"},
 {"lr","lr","main"},
 {"lx","lux-cli","main"},
 {"m4","m4","main"},
 {"mc","mc","main"},
 {"ml","mercury","main"},
 {"mg","mg","main"},
 {"al","mono","main"},
 {"ts","moreutils","main"},
 {"lz","mtools","main"},
 {"mu","mu","main"},
 {"mr","myrepos","main"},
 {"sc","n-t-roff-sc","main"},
 {"ne","ne","main"},
 {"ex","neovim","main"},
 {"nc","netcat-openbsd","main"},
 {"nc","nmap","main"},
 {"pp","nss-utils","main"},
 {"nu","nushell","main"},
 {"nx","nxengine","x11-repo"},
 {"ol","ol","main"},
 {"iv","openimageio","x11-repo"},
 {"o","orbiton","main"},
 {"7z","p7zip","main"},
 {"gp","pari","main"},
 {"pb","pb","main"},
 {"ps","procps","main"},
 {"pd","proot-distro","main"},
 {"pv","pv","main"},
 {"q","q-dns-client","main"},
 {"qs","quickshell","x11-repo"},
 {"r2","radare2","main"},
 {"rc","rc","main"},
 {"ci","rcs","main"},
 {"rg","ripgrep","main"},
 {"rq","rq","main"},
 {"ri","ruby-ri","main"},
 {"sv","runit","main"},
 {"sd","sd","main"},
 {"ag","silversearcher-ag","main"},
 {"sl","sl","main"},
 {"st","st","x11-repo"},
 {"sr","surfraw","main"},
 {"pt","tcllib","main"},
 {"am","termux-am","main"},
 {"df","termux-tools","main"},
 {"ht","texlive-bin","main"},
 {"sn","tin-summer","main"},
 {"tf","tinyfugue","main"},
 {"ty","ty","main"},
 {"ug","ugrep","main"},
 {"up","up","main"},
 {"ul","util-linux","main"},
 {"cu","uucp","main"},
 {"uv","uv","main"},
 {"ex","vim","main"},
 {"ex","vim-gtk","x11-repo"},
 {"vt","virustotal-cli","main"},
 {"vi","vis","main"},
 {"wg","wireguard-tools","main"},
 {"xh","xh","main"},
 {"X","xorg-server","x11-repo"},
 {"xz","xz-utils","main"},
 {"ya","yazi","main"},
 {"yq","yq","main"},
 {"z3","z3","main"},
 {"zk","zk","main"}
};
static void usage(){std::cout<<"Pantheon ∞ / Ɣ runtime\n"
"  pantheon validate <file.pa>\n  pantheon watch <file.pa> [seconds]\n"
"  pantheon knowledge-add <ledger> <source> <claim>\n  pantheon knowledge-list <ledger>\n"
"  pantheon gamma [commands|command <token>]\n";}
static int validate(const std::string& f){pantheon::Runtime rt;auto r=rt.load(f);std::cout<<(r.ok?"PANTHEON VALID: ":"PANTHEON REJECTED: ")<<r.message<<"\n";for(auto&x:r.values)std::cout<<x.first<<" = "<<x.second<<"\n";return r.ok?0:1;}
static std::string clean(std::string s){for(char& c:s) if(c=='\t'||c=='\n'||c=='\r') c=' '; return s;}
static void gammaBanner(){std::cout<<"Ɣ / GAMMA: ơɣ package-language registry active; provenance retained; no shell commands executed.\n";}
static int gammaCommands(){
 gammaBanner();
 for(const auto&m:commandMaps)std::cout<<"ơɣ::"<<m.token<<"  package="<<m.package<<"  repo="<<m.repo<<"\n";
 std::cout<<"Registry mappings: "<<(sizeof(commandMaps)/sizeof(commandMaps[0]))<<". Duplicate command names retain all package candidates.\n";
 return 0;
}
static int gammaCommand(const std::string& token){
 bool found=false;
 for(const auto&m:commandMaps)if(token==m.token){found=true;std::cout<<"ơɣ::"<<m.token<<" -> pkg.install("<<m.package<<") [repo="<<m.repo<<"]\n";}
 if(!found){std::cerr<<"Unknown ơɣ token: "<<token<<"\n";return 1;}
 std::cout<<"Mappings only; package installation and command execution require separate user authorization.\n";return 0;
}
static int gammaPackages(){
 gammaBanner();std::set<std::string> seen;
 for(const auto&m:commandMaps)if(seen.insert(m.package).second)std::cout<<m.package<<" ["<<m.repo<<"]\n";
 return 0;
}
int main(int argc,char**argv){
 if(argc<2){usage();return 2;}std::string cmd=argv[1];
 if(cmd=="validate"&&argc==3)return validate(argv[2]);
 if(cmd=="watch"&&(argc==3||argc==4)){
   int sec=argc==4?std::max(1,std::atoi(argv[3])):2;std::error_code ec;
   auto last=std::filesystem::last_write_time(argv[2],ec);if(ec){std::cerr<<"Cannot stat configuration\n";return 1;}
   int status=validate(argv[2]);std::cout<<"LIVE WATCH: valid configurations replace active policy; invalid edits are rejected.\n";
   while(true){std::this_thread::sleep_for(std::chrono::seconds(sec));auto now=std::filesystem::last_write_time(argv[2],ec);if(!ec&&now!=last){last=now;std::cout<<"--- configuration change detected ---\n";status=validate(argv[2]);std::cout<<(status==0?"ACTIVE CONFIGURATION ACCEPTED":"ACTIVE CONFIGURATION PRESERVED")<<"\n";}}
 }
 if(cmd=="knowledge-add"&&argc==5){std::ofstream o(argv[2],std::ios::app);if(!o){std::cerr<<"Cannot open ledger\n";return 1;}std::time_t t=std::time(nullptr);o<<t<<"\t"<<clean(argv[3])<<"\t"<<clean(argv[4])<<"\tUNREVIEWED\n";std::cout<<"Knowledge observation appended; status UNREVIEWED.\n";return 0;}
 if(cmd=="knowledge-list"&&argc==3){std::ifstream i(argv[2]);if(!i){std::cout<<"No knowledge ledger yet.\n";return 0;}std::string l;while(std::getline(i,l))std::cout<<l<<"\n";return 0;}
 if(cmd=="gamma"&&argc==2){gammaBanner();return 0;}
 if(cmd=="gamma"&&argc==3&&std::string(argv[2])=="commands")return gammaCommands();
 if(cmd=="gamma"&&argc==3&&std::string(argv[2])=="packages")return gammaPackages();
 if(cmd=="gamma"&&argc==4&&std::string(argv[2])=="command")return gammaCommand(argv[3]);
 usage();return 2;
}
