# Ɣ / ơɣ Termux registry

The supplied package suggestions are represented in `data/gamma-command-registry.tsv` and `language/termux.og`. Each mapping retains command token, package name, and repository. Duplicate command tokens intentionally remain ambiguous: `nc` maps to busybox, netcat-openbsd, and nmap; `ex` maps to neovim, vim, and vim-gtk.

Use:
- `./pantheon gamma commands`
- `./pantheon gamma command nc`
- `./pantheon gamma packages`

These mappings come from the user's supplied Termux command list; they are not a live repository query. A package name is not proof that its executable is currently installed or that the executable name is identical. Confirm locally with `pkg show <package>` and `command -v <command>`.

The registry only describes candidates. It does not run commands, install packages, grant network access, or elevate privileges. In particular, network tools such as `iw`, `wg`, `nc`, `nmap`, and `xh` remain subject to normal Android/Termux permissions and user authorization.
