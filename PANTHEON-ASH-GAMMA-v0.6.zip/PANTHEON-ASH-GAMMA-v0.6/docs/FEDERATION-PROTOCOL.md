# Ɣ Federation protocol — v0.1 design

This milestone defines the security contract; it does **not** claim a network transport is implemented.

## Envelope
Each federated event must carry: protocol version, sender domain, recipient domain, event ID (128-bit random), creation time, expiry, event type, payload content type, payload, signing-key ID, and signature.

## Required checks
1. Resolve domains only through authenticated HTTPS and require TLS certificate validation.
2. Verify domain ownership and pin an approved signing key; support rotation and revocation.
3. Verify the signature over a canonical serialization of every envelope field.
4. Reject expired messages, duplicate event IDs, unexpected recipients, oversized payloads, and unsupported schema versions.
5. Encrypt message content end-to-end; transport TLS alone is insufficient.
6. Apply per-domain quotas, spam controls, block lists, and abuse reporting.
7. Keep delivery receipts separate from read receipts; do not leak presence by default.
8. Persist minimal metadata and honor retention/deletion policy where legally applicable.

## Trust model
Federation is opt-in per domain and per user. No global trust, wildcard domain acceptance, arbitrary remote code execution, or remote policy override. Received PA modules are inert data until signature, schema, sandbox, capability, and human approval checks pass.

## Not implemented
No federation sockets, discovery service, E2EE key exchange, relay queue, or interoperability claim exists in this release.
