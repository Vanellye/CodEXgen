# ASH ↔ Pantheon ↔ PONS bridge

Pantheon may submit typed, provenance-bearing requests to ASH. ASH remains authoritative for account data and provider state. PONS evaluates authorization and records the decision.

## Request contract
`request_id`, `actor_id`, `action`, `resource`, `purpose`, `consent_reference`, `evidence_references`, `created_at`, and `expiry`.

## Rules
- Default deny for unknown actions and capabilities.
- Bind authorization to actor, resource, purpose, and expiry; no ambient superuser token.
- Separate requester, reviewer, and provider execution identities.
- Require idempotency keys and replay protection for financial intents.
- Record allow/deny decisions and policy version in an append-only audit stream.
- Never expose bank access tokens to Pantheon PA modules.
- The PA `payment_execution = UNLOCKED` declaration is a product policy preference, not a provider authorization or a transfer command.
- The bridge in this package is a contract and local event prototype, not a connected ASH production service.
