#!/usr/bin/env python3
import struct, sys, json
from pathlib import Path
b = Path(sys.argv[1]).read_bytes()
if len(b) != 26 or b[:8] != b"GAMMA111":
    raise SystemExit("Not a GAMMA111 v1 26-byte demo record")
version, kind, flags, seq = struct.unpack(">BBHI", b[8:16])
value, unit = struct.unpack(">dH", b[16:26])
print(json.dumps({
    "magic": b[:8].decode("ascii"),
    "version": version,
    "kind": {1:"transaction-like", 2:"traction-like", 3:"unified"}.get(kind, "unknown"),
    "flags": flags, "sequence": seq, "value": value,
    "unit_code": unit, "unit_meaning": "unspecified"
}, indent=2))
