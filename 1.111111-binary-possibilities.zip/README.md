# 1.111111 — Binary possibilities

This bundle represents the scalar `1.111111` in several binary and textual encodings,
and defines three small illustrative records.

## Included
- `transaction_1.111111.bin` — transaction-shaped demonstration record
- `traction_1.111111.bin` — traction-shaped demonstration record
- `unified_1.111111.bin` — general combined record
- `value_ieee754_be.bin` / `_le.bin` — 64-bit IEEE-754 floating point
- `value_fixed6_signed_be.bin` / `_le.bin` — signed integer 1,111,111 with scale 10^6
- `value_decimal_utf8.bin` — UTF-8 characters `1.111111`
- `value_binary_text_utf8.bin` — base-2 digits of integer 1,111,111 as text
- `manifest.json` — schema, assumptions, and checksums
- `decode_record.py` — decoder for the three 26-byte records

## Record layout (26 bytes)
8-byte magic `GAMMA111` | 1-byte version | 1-byte kind | 2-byte flags |
4-byte sequence | 8-byte IEEE-754 double (big-endian) | 2-byte unit code

Kinds: 1 transaction-like, 2 traction-like, 3 unified.
Unit code 0 means unspecified.

## Important
These are designed examples, not actual transactions, payment instructions, measured
forces, or proof of a real event. A bit sequence has no unique English meaning without
a declared schema. This bundle provides a transparent schema for reproducible decoding.
