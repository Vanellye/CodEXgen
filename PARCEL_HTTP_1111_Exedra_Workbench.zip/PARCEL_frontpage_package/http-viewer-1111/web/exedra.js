let record=null;const $=id=>document.getElementById(id);
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
async function load(){const r=await fetch("/api/exedra");if(!r.ok)throw Error("HTTP "+r.status);record=await r.json();
$("dimensions").innerHTML=record.dimensions.map(x=>`<article class="card"><span class="tag">${esc(x.id)}</span><h3>${esc(x.label)}</h3><p>${esc(x.purpose)}</p><small>${esc(x.rule)}</small></article>`).join("");
$("prompts").innerHTML=record.prompt_replays.map(x=>`<article class="card"><span class="tag">${esc(x.id)}</span><h3>${esc(x.title)}</h3><p class="prompt">${esc(x.prompt)}</p><p>${esc(x.result)}</p><small class="good">${esc(x.replay_status)} · ${esc(x.evidence_class)}</small><p class="muted">Next: ${esc(x.next_check)}</p></article>`).join("");
$("implementations").innerHTML=record.implementation_inventory.map(x=>`<article class="card"><span class="tag">${esc(x.id)}</span><h3>${esc(x.name)}</h3><p>${esc(x.evidence)}</p><p class="warn">${esc(x.status)}</p><small>${esc(x.execution)}</small></article>`).join("");
$("results").innerHTML=Object.entries(record.rerun_results).map(([k,v])=>`<article class="card"><h3>${esc(k.toUpperCase())}</h3><p class="${v.status==="PASSED"?"good":"warn"}">${esc(v.status)}</p><pre>${esc(JSON.stringify(v,null,2))}</pre></article>`).join("");
$("ethics").innerHTML=record.ethics.map(x=>`<li>${esc(x)}</li>`).join("");
$("scope").innerHTML=`<p>${esc(record.scope.sources_reviewed.join(" · "))}</p><p class="warn">${esc(record.scope.not_claimed.join(" · "))}</p>`;
$("raw").textContent=JSON.stringify(record,null,2);
}
$("reload").onclick=()=>load().catch(e=>alert(e.message));
$("export").onclick=()=>{const b=new Blob([JSON.stringify(record,null,2)],{type:"application/json"});const a=document.createElement("a");a.href=URL.createObjectURL(b);a.download="exedra-workbench.json";a.click();URL.revokeObjectURL(a.href)};
load().catch(e=>{$("raw").textContent=e.message});
