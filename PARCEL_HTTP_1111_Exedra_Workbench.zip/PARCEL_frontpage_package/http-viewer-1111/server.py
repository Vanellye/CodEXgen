#!/usr/bin/env python3
"""Read-only local HTTP viewer for staged PARCEL records. Default port: 1111."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse, parse_qs, unquote
import json, mimetypes, os

BASE = Path(__file__).resolve().parent
WEB = BASE / "web"
DATA = BASE / "data"
PORT = int(os.environ.get("PORT", "1111"))

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(WEB), **kwargs)

    def send_json(self, payload, status=200):
        body = json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/api/records":
            files = sorted(DATA.glob("*.json"))
            self.send_json({"records": [{"name": p.name, "bytes": p.stat().st_size} for p in files]})
            return
        if parsed.path == "/api/exedra":
            target = DATA / "exedra-workbench.json"
            try:
                payload = json.loads(target.read_text(encoding="utf-8"))
            except (OSError, UnicodeDecodeError, json.JSONDecodeError):
                self.send_json({"error": "Exedra record unavailable or invalid"}, 422)
                return
            self.send_json(payload)
            return
        if parsed.path == "/api/record":
            name = parse_qs(parsed.query).get("name", ["movement-semantics.json"])[0]
            # Only allow simple JSON filenames from the dedicated data directory.
            if Path(name).name != name or not name.endswith(".json"):
                self.send_json({"error": "Invalid record name"}, 400)
                return
            target = DATA / name
            if not target.is_file():
                self.send_json({"error": "Record not found"}, 404)
                return
            try:
                payload = json.loads(target.read_text(encoding="utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError):
                self.send_json({"error": "Record is not valid UTF-8 JSON"}, 422)
                return
            self.send_json(payload)
            return
        if parsed.path == "/exedra":
            self.path = "/exedra.html"
            return super().do_GET()
        if parsed.path.startswith("/api/"):
            self.send_json({"error": "Unknown API endpoint"}, 404)
            return
        return super().do_GET()

    def do_POST(self):
        self.send_json({"error": "Read-only server: writes are disabled"}, 405)

    def log_message(self, fmt, *args):
        print("[HTTP]", self.address_string(), "-", fmt % args)

if __name__ == "__main__":
    print(f"PARCEL Frontpage viewer: http://127.0.0.1:{PORT}")
    print("Read-only local server. Ctrl+C to stop.")
    ThreadingHTTPServer(("0.0.0.0", PORT), Handler).serve_forever()
