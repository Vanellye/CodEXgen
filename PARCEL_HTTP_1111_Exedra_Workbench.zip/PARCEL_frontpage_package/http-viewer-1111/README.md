# HTTP 1111 · PARCEL + Exedra Workbench

## Run on Android / Termux

```sh
pkg install python unzip -y
unzip PARCEL_HTTP_1111_Exedra_Workbench.zip
cd PARCEL_frontpage_package/http-viewer-1111
python server.py
```

Open:
- Movement viewer: `http://127.0.0.1:1111/`
- Exedra workbench: `http://127.0.0.1:1111/exedra`

## Read-only API
- `GET /api/records`
- `GET /api/record?name=movement-semantics.json`
- `GET /api/exedra`

POST requests are rejected. The server exposes only bundled web assets and JSON records. It does not execute prompts, imported code, shell commands, or repository actions.

## Scope
The Exedra register records prompt replays reviewed in the current ChatGPT conversation, discovered code references, and local test reruns. It does not claim exhaustive access to all historical chats, all repository branches, or hosted AI services. `PromptOptimizationReport.kt` was discovered through repository code search but was not fetched, compiled, or rerun. Oprozal runtime integration remains unverified.

The word “consciousness” is treated as a human research/reflection topic. Software faculties are not represented as independently conscious. Excedra remains the unknown/boundary category in the PARCEL taxonomy.
