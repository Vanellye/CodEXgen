# Exedra HTTP 1111 Workbench

Exedra is the integrated local workbench for prompt replay, AI/faculty inventory, Ɣơ three-dimensional mapping, and test evidence.

- Origin: preserve authored prompt and source identity.
- Semantics: distinguish evidence, inference, proposal, metaphor, and unknown.
- Evolution: produce additive, reviewed descendants and conformance-tested changes.

The Exedra workbench is served at `/exedra`. The original movement semantics viewer remains at `/`.

Prompt replays in this package are model-assisted reviews recorded in the current conversation. They are not claims that external hosted AI systems were invoked. The AI implementation inventory distinguishes documented architecture, source discovery, local test execution, and unverified runtime status.

No software consciousness claim is made. No repository writes, commits, merges, releases, external dispatch, or arbitrary code execution are performed.
