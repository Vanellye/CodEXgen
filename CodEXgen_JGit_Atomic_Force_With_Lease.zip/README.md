# CodEXgen JGit Stride 9 — PR workflow + Prompt Optimization Report

Target: `Vanellye/CodEXgen`, branch `main-11-of-38`

## Included
- Full JGit Android bridge integration from the previous package.
- Workspace folder import into app-private clone.
- Selected-file commit and normal feature-branch push.
- Pull request creation targeting the configured base branch; PR is never merged automatically.
- Atomic lease-protected feature-branch force update using JGit RemoteRefUpdate.expectedOldObjectId.
- Prompt Optimization Report: transparent heuristic scoring for goal, context, constraints, output, validation, and safety/uncertainty; generates an editable prompt structure.

## Important force-update limitation
JGit's API here does not provide the same atomic server-side `git push --force-with-lease` guarantee as Git CLI. The advanced button fetches the remote feature tip, checks that it exists, and then requests a forced ref update. A race remains between the preflight and remote update. Use ordinary push by default. This advanced operation is strictly feature-branch-only; it never targets the configured base branch. It is not enabled for `main` or the configured base branch.

## Pull request permissions
Fine-grained token should be scoped to `Vanelly/CodEXgen` with:
- Metadata: Read
- Contents: Read and write
- Pull requests: Read and write

PR creation opens a review request only. It does not merge, approve, or change branch protection.

## Prompt report boundaries
The prompt report is deterministic, text-only heuristic analysis. It does not inspect hidden reasoning, access private model internals, change model weights, autonomously rewrite project files, or claim to improve biological or physical systems. The user reviews and chooses whether to use the suggested prompt structure.

## Apply and test
Copy all files in `app/` over the corresponding paths in the repository, then run:
`./gradlew :app:assembleDebug`
Test on a device with a disposable feature branch and a test repository before production use.

## Status
This is a source integration package, not an APK. No Android build or device test was run here. No remote GitHub branch or pull request was created from this session. The previous connected GitHub write integration returned HTTP 403.
