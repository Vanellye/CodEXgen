# PONS execution boundary — v0.9.0

`gamma run` is an explicitly requested local process launcher, not a remote executor.
It resolves the command against the `.og` registry, requires a unique candidate or
an explicitly selected registered package, verifies the package in dpkg and the
executable on PATH, and refuses non-interactive invocation. Before launch it prints
the selected command and arguments and requires the exact interactive confirmation
`PONS APPROVE <command>`.

The child is launched with `execvp` and an argv vector. No shell is invoked and no
command string is interpolated. Arguments after `--` are passed literally to the
program. This prevents shell metacharacters from becoming shell instructions, but
does not make the selected program harmless: it may still delete files, access the
network, or change device state. Review the command and arguments before approving.

This is a local human-approval gate called PONS; it is NOT cryptographic PONS
verification, hardware-backed signing, independent security review, or tamper-proof
audit anchoring. The TSV ledger is local and editable. Package installation through
`gamma prepare` may modify the device and consume storage/network data. Never use
this launcher for financial transfers or privileged actions without a separately
implemented provider authorization and independent security review.
