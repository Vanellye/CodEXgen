# PANTHEON / ASH / GAMMA v0.9.0

C++17 Termux runtime with a CMake build, Makefile compatibility, `.og` command
registry, package discovery/preparation, and a PONS human-approved local dispatcher.

## Build with CMake (Termux)

```bash
pkg install clang cmake make -y
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build
./build/pantheon --version
```

Or use the existing Makefile:

```bash
make
make check
```

## Registry and package commands

```bash
./build/pantheon gamma commands
./build/pantheon gamma packages
./build/pantheon gamma resolve nc
./build/pantheon gamma discover
./build/pantheon gamma inspect nc
./build/pantheon gamma prepare nc netcat-openbsd
./build/pantheon gamma ledger
```

## PONS-authorized mapped command execution

For an unambiguous mapping:

```bash
./build/pantheon gamma run <command>
```

For an ambiguous mapping, choose one registered package:

```bash
./build/pantheon gamma run nc --package netcat-openbsd -- -h
```

The dispatcher requires a real interactive terminal, verifies the selected package
is installed and the mapped executable exists on PATH, displays the command and
arguments, then waits for the exact phrase:

```text
PONS APPROVE nc
```

Declining or entering anything else blocks execution. Arguments after `--` are passed
literally; no shell is used. Read `SECURITY.md` before approving commands.

## Important limits

The approval gate is a local human confirmation mechanism, not cryptographic PONS,
hardware signing, remote authorization, or an immutable ledger. The selected program
can still perform its normal effects. This release does not authorize or implement
bank, Bitcoin, Ethereum, or other financial transfers.
