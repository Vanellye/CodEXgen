#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <map>
#include <regex>
#include <set>
#include <sstream>
#include <string>
#include <vector>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <cerrno>

namespace fs = std::filesystem;
struct Mapping { std::string command, package, repo; };

static std::string trim(std::string s) {
    auto a=s.find_first_not_of(" \t\r\n");
    if(a==std::string::npos) return "";
    auto b=s.find_last_not_of(" \t\r\n");
    return s.substr(a,b-a+1);
}
static std::string timestamp() {
    std::time_t t=std::time(nullptr); char b[32]{};
    std::strftime(b,sizeof(b),"%Y-%m-%dT%H:%M:%SZ",std::gmtime(&t)); return b;
}
static void ledger(const std::string& event, const std::string& detail) {
    std::ofstream f("data/gamma-ledger.tsv", std::ios::app);
    f << timestamp() << "\t" << event << "\t" << detail << "\n";
}
static bool safe_token(const std::string& s) {
    return !s.empty() && std::regex_match(s, std::regex("[A-Za-z0-9_+.-]+"));
}
static std::vector<Mapping> load_registry(const std::string& path) {
    std::ifstream f(path);
    std::vector<Mapping> out;
    if(!f) return out;
    std::regex rx(R"rx(map\s+"([A-Za-z0-9_\[\].+-]+)"\s*=>\s*package\("([A-Za-z0-9_+.-]+)"\)\s+from\s+repo\("([A-Za-z0-9_-]+)"\)\s*;)rx");
    std::string line; std::smatch m;
    while(std::getline(f,line)) if(std::regex_search(line,m,rx))
        out.push_back({m[1],m[2],m[3]});
    return out;
}
static std::set<std::string> installed_packages() {
    std::set<std::string> out;
    // Fixed, read-only package query; no user-supplied text enters the shell.
    FILE* p=popen("dpkg-query -W -f='${binary:Package}\\n' 2>/dev/null","r");
    if(!p) return out;
    char buf[512];
    while(fgets(buf,sizeof(buf),p)) { auto s=trim(buf); if(!s.empty()) out.insert(s); }
    pclose(p); return out;
}
static bool executable_exists(const std::string& name) {
    if(!safe_token(name)) return false;
    std::string cmd = "command -v " + name + " >/dev/null 2>&1";
    return std::system(cmd.c_str()) == 0;
}

static int install_package(const std::string& package) {
    if(!safe_token(package)) return 2;
    std::cout << "Installing missing package: " << package << "\n";
    pid_t pid = fork();
    if(pid < 0) { perror("fork"); return 2; }
    if(pid == 0) {
        execlp("pkg", "pkg", "install", "-y", package.c_str(), (char*)nullptr);
        perror("pkg");
        _exit(127);
    }
    int status = 0;
    if(waitpid(pid, &status, 0) < 0) { perror("waitpid"); return 2; }
    if(WIFEXITED(status)) return WEXITSTATUS(status);
    return 128;
}
static void help() {
    std::cout <<
    "PANTHEON / ASH / GAMMA v0.9.0\n"
    "  ./pantheon gamma commands [file]\n"
    "  ./pantheon gamma packages [file]\n"
    "  ./pantheon gamma resolve <command> [file]\n"
    "  ./pantheon gamma discover [file]\n"
    "  ./pantheon gamma inspect <command> [file]\n"
    "  ./pantheon gamma prepare <command> [package] [file]\n"
    "  ./pantheon gamma ledger\n"
    "\nơɣ prepares dependencies by installing missing packages; it NEVER executes mapped commands.\n";
}
int main(int argc,char** argv) {
    if(argc<2) { help(); return 0; }
    std::string area=argv[1];
    if(area=="--version" || area=="version") { std::cout<<"0.9.0\n"; return 0; }
    if(area!="gamma" || argc<3) { help(); return area=="gamma"?1:0; }
    std::string action=argv[2];
    if(action=="ledger") {
        std::ifstream f("data/gamma-ledger.tsv"); std::string line;
        if(!f) { std::cout<<"No ledger entries yet.\n"; return 0; }
        while(std::getline(f,line)) std::cout<<line<<"\n";
        return 0;
    }
    int argi=3;
    std::string target;
    if(action=="resolve" || action=="inspect" || action=="prepare" || action=="run") {
        if(argc<=argi) { std::cerr<<"Missing command token.\n"; return 2; }
        target=argv[argi++];
        if(!safe_token(target)) { std::cerr<<"Invalid command token.\n"; return 2; }
    }
    // In prepare, the first optional argument is the package selector.
    // The registry path follows the selector; otherwise use the default.
    std::string path = "language/termux.og";
    if(action=="prepare") {
        if(argc > argi + 1) path = argv[argi + 1];
    } else if(action!="run" && argc > argi) {
        path = argv[argi];
    }
    auto maps=load_registry(path);
    if(maps.empty()) { std::cerr<<"No mappings parsed from "<<path<<". Check .og syntax/path.\n"; return 3; }
    auto installed=installed_packages();

    if(action=="prepare") {
        std::string requested_package;
        // Optional package argument selects a candidate for ambiguous aliases.
        if(argc > argi) requested_package = argv[argi++];
        std::vector<Mapping> hits;
        for(auto&m:maps) if(m.command==target) hits.push_back(m);
        if(hits.empty()) {
            std::cerr << "No mapping for command: " << target << "\n";
            ledger("PREPARE_REJECTED", target+" no_mapping");
            return 4;
        }
        Mapping chosen{};
        if(!requested_package.empty()) {
            if(!safe_token(requested_package)) {
                std::cerr << "Invalid package token.\n"; return 2;
            }
            bool found=false;
            for(auto&m:hits) if(m.package==requested_package) { chosen=m; found=true; break; }
            if(!found) {
                std::cerr << "Package is not a registered candidate for " << target << ".\n";
                ledger("PREPARE_REJECTED", target+" invalid_candidate="+requested_package);
                return 5;
            }
        } else {
            std::set<std::string> candidates;
            for(auto&m:hits) candidates.insert(m.package);
            if(candidates.size()!=1) {
                std::cerr << "AMBIGUOUS: choose one registered package candidate explicitly.\n";
                for(auto&c:candidates) std::cerr << "  " << c << "\n";
                ledger("PREPARE_BLOCKED", target+" ambiguous");
                return 6;
            }
            chosen=hits.front();
        }
        auto current=installed_packages();
        if(current.count(chosen.package)) {
            std::cout << "Package already installed: " << chosen.package << "\n";
            ledger("PREPARE_READY", target+" package="+chosen.package+" already_installed");
            std::cout << "Dependency flow complete. Mapped command was NOT executed.\n";
            return 0;
        }
        ledger("INSTALL_REQUESTED", target+" package="+chosen.package+" repo="+chosen.repo);
        int rc=install_package(chosen.package);
        if(rc!=0) {
            std::cerr << "Package installation failed with exit code " << rc << ".\n";
            ledger("INSTALL_FAILED", chosen.package+" exit="+std::to_string(rc));
            return rc;
        }
        auto after=installed_packages();
        if(!after.count(chosen.package)) {
            std::cerr << "Installer returned success, but package is not present in dpkg status.\n";
            ledger("INSTALL_UNVERIFIED", chosen.package);
            return 7;
        }
        ledger("PREPARE_READY", target+" package="+chosen.package+" installed");
        std::cout << "Dependency flow complete. Package verified installed.\n";
        std::cout << "Mapped command was NOT executed.\n";
        return 0;
    }
    if(action=="run") {
        // Syntax: gamma run <command> [--package <candidate>] [-- <arguments...>]
        // Execution uses execvp directly: no shell, interpolation, or command string.
        if(!isatty(STDIN_FILENO) || !isatty(STDOUT_FILENO)) {
            std::cerr << "PONS_BLOCKED: gamma run requires an interactive terminal for human approval.\n";
            ledger("RUN_BLOCKED", target+" non_interactive");
            return 20;
        }
        std::string selected_package;
        std::vector<std::string> child_args;
        int i=argi;
        while(i<argc) {
            std::string a=argv[i++];
            if(a=="--package") {
                if(i>=argc || !selected_package.empty()) {
                    std::cerr << "Usage: gamma run <command> [--package <package>] [-- <args...>]\n";
                    return 2;
                }
                selected_package=argv[i++];
                if(!safe_token(selected_package)) { std::cerr<<"Invalid package token.\n"; return 2; }
            } else if(a=="--") {
                while(i<argc) child_args.emplace_back(argv[i++]);
                break;
            } else {
                std::cerr << "Unexpected argument: " << a << "\nUse -- before command arguments.\n";
                return 2;
            }
        }
        std::vector<Mapping> hits;
        for(auto&m:maps) if(m.command==target) hits.push_back(m);
        if(hits.empty()) {
            std::cerr<<"No mapping for command: "<<target<<"\n";
            ledger("RUN_REJECTED",target+" no_mapping"); return 4;
        }
        std::set<std::string> candidates;
        for(auto&m:hits) candidates.insert(m.package);
        Mapping chosen{};
        if(selected_package.empty()) {
            if(candidates.size()!=1) {
                std::cerr<<"PONS_BLOCKED: ambiguous command; select a registered candidate with --package.\n";
                for(auto&c:candidates) std::cerr<<"  "<<c<<"\n";
                ledger("RUN_BLOCKED",target+" ambiguous"); return 6;
            }
            chosen=hits.front();
        } else {
            bool found=false;
            for(auto&m:hits) if(m.package==selected_package) { chosen=m; found=true; break; }
            if(!found) {
                std::cerr<<"PONS_BLOCKED: package is not a registered candidate.\n";
                ledger("RUN_REJECTED",target+" invalid_candidate="+selected_package); return 5;
            }
        }
        auto current=installed_packages();
        if(!current.count(chosen.package)) {
            std::cerr<<"PONS_BLOCKED: package is not installed. Run gamma prepare first.\n";
            ledger("RUN_BLOCKED",target+" package_missing="+chosen.package); return 7;
        }
        if(!executable_exists(target)) {
            std::cerr<<"PONS_BLOCKED: mapped executable is not on PATH: "<<target<<"\n";
            ledger("RUN_BLOCKED",target+" executable_missing"); return 8;
        }
        std::cout<<"PONS ACTION REVIEW\n"
                 <<"  command: "<<target<<"\n"
                 <<"  package: "<<chosen.package<<" ("<<chosen.repo<<")\n"
                 <<"  arguments:";
        if(child_args.empty()) std::cout<<" (none)";
        for(auto&a:child_args) std::cout<<" ["<<a<<"]";
        std::cout<<"\n  execution: direct process launch; no shell\n"
                 <<"  effect: the selected program may modify files, data, or device state.\n"
                 <<"Type exactly: PONS APPROVE "<<target<<"\n> "<<std::flush;
        std::string approval;
        if(!std::getline(std::cin,approval) || approval!="PONS APPROVE "+target) {
            std::cout<<"PONS_DENIED: no exact human approval received.\n";
            ledger("RUN_DENIED",target+" human_approval_missing"); return 21;
        }
        ledger("RUN_APPROVED",target+" package="+chosen.package);
        std::vector<char*> exec_args;
        exec_args.push_back(const_cast<char*>(target.c_str()));
        for(auto& a:child_args) exec_args.push_back(const_cast<char*>(a.c_str()));
        exec_args.push_back(nullptr);
        std::cout<<"PONS_APPROVED: launching mapped command.\n"<<std::flush;
        pid_t pid=fork();
        if(pid<0) { perror("fork"); ledger("RUN_FAILED",target+" fork"); return 22; }
        if(pid==0) {
            execvp(target.c_str(),exec_args.data());
            perror("execvp");
            _exit(errno==ENOENT?127:126);
        }
        int status=0;
        if(waitpid(pid,&status,0)<0) { perror("waitpid"); ledger("RUN_FAILED",target+" waitpid"); return 22; }
        int rc=WIFEXITED(status)?WEXITSTATUS(status):(WIFSIGNALED(status)?128+WTERMSIG(status):125);
        ledger("RUN_FINISHED",target+" exit="+std::to_string(rc));
        return rc;
    }
    if(action=="commands") {
        std::set<std::string> s; for(auto&m:maps)s.insert(m.command);
        for(auto&x:s) std::cout<<x<<"\n";
        std::cout<<"Parsed "<<maps.size()<<" mappings from "<<path<<"\n";
    } else if(action=="packages") {
        std::set<std::string> s; for(auto&m:maps)s.insert(m.package);
        for(auto&x:s) std::cout<<x<<"\n";
        std::cout<<"Unique packages: "<<s.size()<<"\n";
    } else if(action=="discover") {
        size_t found=0;
        for(auto&m:maps) if(installed.count(m.package)) ++found;
        std::cout<<"Registry mappings: "<<maps.size()<<"\n"
                 <<"Installed package matches: "<<found<<"\n"
                 <<"Discovery is read-only; it does not install or execute anything.\n";
        ledger("DISCOVER",std::to_string(found)+"/"+std::to_string(maps.size()));
    } else if(action=="resolve" || action=="inspect" || action=="prepare" || action=="run") {
        std::vector<Mapping> hits;
        for(auto&m:maps) if(m.command==target) hits.push_back(m);
        if(hits.empty()) { std::cout<<"No mapping for command: "<<target<<"\n"; return 4; }
        std::cout<<"Command: "<<target<<"\n";
        for(auto&m:hits) {
            bool pkg=installed.count(m.package)>0;
            bool bin=executable_exists(target);
            std::cout<<"- package="<<m.package<<" repo="<<m.repo
                     <<" installed="<<(pkg?"yes":"no")
                     <<" executable_on_PATH="<<(bin?"yes":"no")<<"\n";
        }
        if(hits.size()>1) std::cout<<"AMBIGUOUS: multiple package candidates; choose explicitly before any future action.\n";
        if(action=="inspect") ledger("INSPECT",target+" candidates="+std::to_string(hits.size()));
        else ledger("RESOLVE",target+" candidates="+std::to_string(hits.size()));
    } else { help(); return 2; }
    return 0;
}
