PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS schema_migrations (
  version INTEGER PRIMARY KEY,
  applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS repositories (
  repository_id TEXT PRIMARY KEY,
  provider TEXT NOT NULL,
  owner TEXT NOT NULL,
  name TEXT NOT NULL,
  remote_url TEXT NOT NULL,
  indexed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(provider, owner, name)
);

CREATE TABLE IF NOT EXISTS source_objects (
  sha256 TEXT PRIMARY KEY CHECK(length(sha256) = 64),
  byte_length INTEGER NOT NULL CHECK(byte_length >= 0),
  object_path TEXT NOT NULL UNIQUE,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS transformations (
  transformation_id TEXT PRIMARY KEY,
  source_sha256 TEXT NOT NULL REFERENCES source_objects(sha256),
  output_sha256 TEXT,
  source_language TEXT NOT NULL,
  target_language TEXT NOT NULL,
  adapter_version TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('planned','validated','rejected')),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS basespace_events (
  event_id TEXT PRIMARY KEY,
  event_type TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  event_sha256 TEXT NOT NULL UNIQUE,
  previous_event_sha256 TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS validation_evidence (
  evidence_id TEXT PRIMARY KEY,
  subject_sha256 TEXT NOT NULL,
  validator_id TEXT NOT NULL,
  result TEXT NOT NULL CHECK(result IN ('pass','fail','inconclusive')),
  evidence_sha256 TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS pons_approvals (
  approval_id TEXT PRIMARY KEY,
  request_sha256 TEXT NOT NULL,
  reviewer_id TEXT NOT NULL,
  signature TEXT NOT NULL,
  scope_json TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  revoked INTEGER NOT NULL DEFAULT 0 CHECK(revoked IN (0,1)),
  verified INTEGER NOT NULL DEFAULT 0 CHECK(verified IN (0,1))
);

INSERT OR IGNORE INTO schema_migrations(version) VALUES (1);
