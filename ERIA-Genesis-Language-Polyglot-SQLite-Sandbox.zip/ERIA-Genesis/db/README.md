# SQLite store

SQLite is the local metadata index. Keep original bytes in immutable SHA-256-addressed files. Every connection must enable `PRAGMA foreign_keys=ON`. Sandbox mode does not consume or mint PONS approvals and has no repository-write adapter.
