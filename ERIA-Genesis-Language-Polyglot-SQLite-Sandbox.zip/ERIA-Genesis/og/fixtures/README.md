# Shared fixtures

Each adapter must add positive, negative, and unsupported-feature fixtures. Expected results are compared through canonical IR; no fixture is executed as generated code.
