# Genesis Implementation Specification

## Configuration
`target=language`, `implementation=polyglot`, `database=sqlite`, `governance=sandbox`.

## Architecture
- `gho-core`: language-neutral IR, type model, source spans, provenance.
- `og-schema`: versioned package contract and validation.
- `og-adapters`: declarative source/target adapter definitions.
- `og-generator`: deterministic templates and output planning.
- `ashhsa`: content hashes and canonical package manifest.
- `basespace`: append-only local event journal.
- `pons-client`: read-only authorization contract in this phase.
- `avs`: validation evidence and reproducibility checks.
- `sqlite-store`: local metadata and event index.
- `sandbox-runner`: isolated, non-networked validation; never deploys or writes repositories.

## Adapter contract
Each adapter declares:
- adapter ID and version;
- source and target language;
- accepted IR version;
- supported feature set;
- unsupported feature behavior (`reject`, never silently approximate);
- deterministic generator entrypoint;
- fixture set and validation command;
- dependency constraints.

## Canonical IR
IR is JSON-compatible and versioned. It records:
- stable node IDs;
- node kind and typed attributes;
- ordered child nodes;
- source language, file path, byte range, and source digest;
- transformation lineage;
- semantic confidence and unsupported constructs.

IR serialization uses UTF-8, LF newlines, sorted object keys, no insignificant whitespace, and explicit schema version. Original source is separately stored byte-for-byte; canonicalization never rewrites source.

## .og package contents
- `ir/`: canonical IR schema and examples.
- `adapters/`: Kotlin, C++, Java, JavaScript, Bash contracts.
- `mappings/`: source/target capability matrices.
- `templates/`: reusable deterministic templates.
- `dependencies/`: lock-style manifest with versions and digests.
- `history/`: transformation event schema and examples.
- `fixtures/`: shared inputs, expected IR, expected outputs, negative cases.
- `.Ashhsa/hashes.hashes`: SHA-256 artifact manifest.

## SQLite
SQLite stores metadata, not the only copy of source or evidence. Enable foreign keys, WAL where supported, and explicit transactions. Hash-addressed blobs remain immutable files in the sandbox object store.

## Governance
Sandbox allows local parsing, generation planning, fixture tests, and local artifacts only. It forbids GitHub writes, merges, releases, deployment, privileged execution, and credential access. A later write-capable mode must verify reviewer identity, signature, exact scope, expiry, revocation status, user confirmation, and AVS evidence. Missing or unverifiable evidence denies the operation.

## Acceptance criteria
- identical inputs and toolchain versions produce identical IR and generation hashes;
- all source bytes remain recoverable;
- unsupported constructs fail closed;
- all five adapter contracts validate;
- SQLite schema migrates from version 0 to 1;
- hash manifest verifies and detects tampering;
- no network or repository write is performed by tests;
- no `.py` backend or runtime dependency is introduced.
