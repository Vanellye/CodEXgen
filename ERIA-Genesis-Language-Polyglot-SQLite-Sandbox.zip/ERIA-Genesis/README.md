# ERIA Genesis — Language Foundation

Configuration
- Target: language
- Implementation: polyglot
- Database: SQLite
- Governance: sandbox
- Repository writes: prohibited until independent PONS approval is verified

This scaffold is additive and local. It does not modify GitHub repositories, branches, tags, commits, or existing files.

## Scope
1. Ɣơ canonical intermediate representation (IR).
2. Declarative `.og` adapter contracts for Kotlin, C++, Java, JavaScript, and Bash.
3. Source/target language mappings.
4. Reusable templates and dependency manifests.
5. Transformation history and provenance.
6. Cross-language fixtures.
7. `.Ashhsa/hashes.hashes` SHA-256 manifest.
8. SQLite metadata store.
9. Sandbox-only validation; no generated code execution and no repository writes.

## Safety
- Original source bytes are preserved as immutable input objects.
- Generated output is written only to a caller-selected local sandbox directory.
- Parsing and validation never execute input.
- Sandbox mode does not grant GitHub write permissions.
- A future write adapter must require a verified, independent, scoped, fresh, unrevoked PONS approval immediately before each write.
