#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
MANIFEST="$ROOT/og/.Ashhsa/hashes.hashes"
test -f "$MANIFEST"
while IFS=$'\t' read -r path size digest; do
  [[ -z "${path:-}" || "$path" == \#* ]] && continue
  file="$ROOT/og/$path"
  test -f "$file"
  actual_size="$(wc -c < "$file" | tr -d ' ')"
  actual_hash="$(sha256sum "$file" | awk '{print $1}')"
  [[ "$actual_size" == "$size" ]]
  [[ "$actual_hash" == "$digest" ]]
done < "$MANIFEST"
echo "Ashhsa manifest verified."
