package org.eria.genesis

import java.io.File
import java.security.MessageDigest

object HashManifest {
    private fun sha256(bytes: ByteArray) =
        MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }

    fun generate(root: File, output: File): List<String> {
        require(root.isDirectory) { "Package root must be a directory" }
        val entries = root.walkTopDown().filter { it.isFile && it != output }
            .sortedBy { it.relativeTo(root).invariantSeparatorsPath }
            .map { file ->
                val rel = file.relativeTo(root).invariantSeparatorsPath
                "$rel\t${file.length()}\t${sha256(file.readBytes())}"
            }.toList()
        output.parentFile?.mkdirs()
        output.writeText(
            "# ERIA .Ashhsa SHA-256 manifest v1\n" +
            "# path<TAB>byte_length<TAB>sha256\n" +
            entries.joinToString("\n") + "\n"
        )
        return entries
    }
}
