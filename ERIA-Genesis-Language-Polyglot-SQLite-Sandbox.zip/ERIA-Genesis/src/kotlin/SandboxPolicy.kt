package org.eria.genesis

/**
 * This phase has no repository-write capability.
 * A future writer must be a separate component and fail closed unless PONS
 * independently verifies reviewer identity, signature, scope, freshness,
 * revocation, user confirmation, and AVS evidence immediately before use.
 */
object SandboxPolicy {
    fun mayWriteRepository(): Boolean = false
    fun mayExecuteGeneratedCode(): Boolean = false
}
