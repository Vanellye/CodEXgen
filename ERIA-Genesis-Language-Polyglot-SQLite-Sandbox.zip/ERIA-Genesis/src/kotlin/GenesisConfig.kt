package org.eria.genesis

enum class GovernanceMode { SANDBOX }
enum class StorageMode { SQLITE }

data class GenesisConfig(
    val target: String = "language",
    val implementation: String = "polyglot",
    val database: StorageMode = StorageMode.SQLITE,
    val governance: GovernanceMode = GovernanceMode.SANDBOX,
    val repositoryWritesEnabled: Boolean = false
) {
    init {
        require(target == "language")
        require(implementation == "polyglot")
        require(!repositoryWritesEnabled) {
            "Repository writes are disabled in Genesis sandbox."
        }
    }
}
