# ERIA `.og` Package Contract 0.2

## Package identity

- Format identifier: `ERIA-OG/1`
- Language profile: `Ɣơ`
- Canonical extension: `.og`
- Runtime: Kotlin/JVM
- Hash algorithm: SHA-256

## Required package components

1. Canonical intermediate representation.
2. Declarative source-language adapter profiles.
3. Explicit source/target language mappings.
4. Reusable generation templates.
5. Dependency manifest and version constraints.
6. Append-only transformation history.
7. Immutable shared test fixtures.
8. Deterministic generation policy.
9. `.Ashhsa/hashes.hashes` integrity manifest.

## `.og` descriptor syntax

Descriptors use UTF-8 line-oriented `key=value` records. The first non-comment line is `ERIA-OG/1`. Keys are unique. Repeated keys, unknown format versions, missing required keys, and invalid values are rejected. Lists use comma-separated values with no implicit trimming of payload data.

## Safety

Parsing is read-only. IR construction does not execute source. Cross-language code generation is denied unless a mapping explicitly names a validated backend and the backend has passing fixtures for the declared feature set. A lexical adapter profile is not a compiler.

## Provenance

Every IR document records source language, source byte length, source SHA-256, and exact token offsets. Each token carries a Base64URL representation of its original UTF-8 lexeme. Concatenating decoded lexemes must reconstruct the exact source text.
