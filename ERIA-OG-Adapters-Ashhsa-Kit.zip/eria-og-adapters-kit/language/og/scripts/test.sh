#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
command -v kotlinc >/dev/null || { echo "kotlinc is required" >&2; exit 2; }
mapfile -t SOURCES < <(find "$ROOT/runtime/src/main/kotlin" "$ROOT/runtime/src/test/kotlin" -type f -name '*.kt' | sort)
kotlinc "${SOURCES[@]}" -include-runtime -d "$TMP/og-tests.jar"
java -cp "$TMP/og-tests.jar" org.eria.og.OgRuntimeTestsKt "$ROOT"
java -cp "$TMP/og-tests.jar" org.eria.og.OgCliKt validate "$ROOT"
java -cp "$TMP/og-tests.jar" org.eria.og.OgCliKt hash "$ROOT" >/dev/null
