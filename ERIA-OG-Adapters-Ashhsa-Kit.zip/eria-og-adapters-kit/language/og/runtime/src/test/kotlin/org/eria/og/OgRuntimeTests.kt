package org.eria.og

import java.nio.file.Files
import java.nio.file.Path

fun main(args: Array<String>) {
    val root = Path.of(args.getOrElse(0) { "language/og" }).toAbsolutePath()
    val adapters = AdapterRegistry.validate(root)
    check(adapters.map { it.language }.toSet() == setOf("KOTLIN", "CPP", "JAVA", "JAVASCRIPT", "BASH"))

    val sample = "// Ɣơ zero-preserving\nval x = 0\nprintln(\"☆k\")\n"
    val ir = CanonicalIrBuilder.lexical(sample, "KOTLIN")
    check(ir.reconstruct() == sample) { "Canonical IR failed exact source reconstruction" }
    check(ir.sourceByteLength == sample.toByteArray(Charsets.UTF_8).size)
    check(ir.sourceSha256.length == 64)
    check(ir.atoms.any { it.kind == "TRIVIA" })
    check(ir.atoms.any { it.kind == "STRING_OR_QUOTED" })

    check(AdapterRegistry.plan(root, "KOTLIN", "KOTLIN").startsWith("IDENTITY_ONLY"))
    check(AdapterRegistry.plan(root, "KOTLIN", "CPP").startsWith("BLOCKED"))

    check(StarCodec.validateVectors(root.resolve("test-vectors/yoro-star-v2.tsv")) == 7)
    for (value in 0..255) {
        val bytes = byteArrayOf(value.toByte())
        check(StarCodec.decode(StarCodec.encode(bytes)).contentEquals(bytes)) { "Ɣơ/2 mismatch for $value" }
    }
    val leadingZeros = byteArrayOf(0, 0, 1, 0, -1)
    check(StarCodec.decode(StarCodec.encode(leadingZeros)).contentEquals(leadingZeros))
    check(StarCodec.decode("Ɣơ/2:").isEmpty())

    val zeroHash = java.security.MessageDigest.getInstance("SHA-256")
        .digest(byteArrayOf(0)).joinToString("") { "%02x".format(it) }
    check(zeroHash == "6e340b9cffb37a989ca544e6bb780a2c78901d3fb33738768511a30617afa01d")

    val first = AshhsaHashGenerator.generate(root)
    val second = AshhsaHashGenerator.generate(root)
    check(first == second) { ".Ashhsa manifest is not deterministic" }
    check(first.contains("self_excluded=true"))
    check(first.contains("algorithm=SHA-256"))
    val manifest = root.resolve(".Ashhsa/hashes.hashes")
    check(Files.isRegularFile(manifest))

    println("PASS: ${adapters.size} adapter descriptors")
    println("PASS: canonical IR exact reconstruction + UTF-8 source digest")
    println("PASS: explicit identity mapping and blocked cross-language generation")
    println("PASS: Ɣơ/2 shared vectors + exhaustive 256-byte round-trips + leading zeros")
    println("PASS: .Ashhsa SHA-256 manifest deterministic and self-excluding")
}
