package org.eria.og

import java.nio.charset.StandardCharsets
import java.nio.file.Files
import java.nio.file.Path
import java.security.MessageDigest
import java.util.Base64

private fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256")
    .digest(bytes).joinToString("") { "%02x".format(it) }

private fun sha256(text: String): String = sha256(text.toByteArray(StandardCharsets.UTF_8))

data class AdapterDescriptor(
    val id: String,
    val version: String,
    val language: String,
    val parser: String,
    val renderer: String,
    val status: String,
    val features: List<String>,
    val limitations: String
)

data class IrAtom(val index: Int, val kind: String, val start: Int, val end: Int, val lexeme: String) {
    fun encoded(): String = Base64.getUrlEncoder().withoutPadding()
        .encodeToString(lexeme.toByteArray(StandardCharsets.UTF_8))
}

data class CanonicalIr(
    val language: String,
    val sourceByteLength: Int,
    val sourceSha256: String,
    val atoms: List<IrAtom>
) {
    fun reconstruct(): String = atoms.joinToString("") { it.lexeme }

    fun serialize(): String = buildString {
        appendLine("ERIA-OG-IR/1")
        appendLine("language=$language")
        appendLine("source_byte_length=$sourceByteLength")
        appendLine("source_sha256=$sourceSha256")
        appendLine("atom_count=${atoms.size}")
        atoms.forEach { atom ->
            append("atom=").append(atom.index).append('|')
                .append(atom.kind).append('|').append(atom.start).append('|')
                .append(atom.end).append('|').append(atom.encoded()).append('\n')
        }
    }
}

object OgDescriptorReader {
    fun read(path: Path): Map<String, String> {
        val lines = Files.readAllLines(path, StandardCharsets.UTF_8)
        require(lines.firstOrNull() == "ERIA-OG/1") { "Unsupported .og descriptor: $path" }
        val values = linkedMapOf<String, String>()
        lines.drop(1).forEachIndexed { offset, raw ->
            val line = raw.trimEnd()
            if (line.isBlank() || line.startsWith("#")) return@forEachIndexed
            val split = line.indexOf('=')
            require(split > 0) { "Malformed .og key/value at $path:${offset + 2}" }
            val key = line.substring(0, split).trim()
            val value = line.substring(split + 1)
            require(key !in values) { "Duplicate .og key '$key' at $path:${offset + 2}" }
            values[key] = value
        }
        return values
    }
}

object AdapterRegistry {
    private val required = setOf("id", "version", "kind", "language", "parser", "renderer", "status", "features", "limitations")

    fun load(packageRoot: Path): List<AdapterDescriptor> {
        val dir = packageRoot.resolve("adapters")
        require(Files.isDirectory(dir)) { "Missing adapters directory: $dir" }
        Files.list(dir).use { stream ->
            return stream.filter { Files.isRegularFile(it) && it.fileName.toString().endsWith(".og") }
                .sorted().map { path ->
                    val v = OgDescriptorReader.read(path)
                    require(v.keys.containsAll(required)) { "Missing required keys in $path" }
                    require(v["kind"] == "LANGUAGE_ADAPTER") { "Not an adapter descriptor: $path" }
                    AdapterDescriptor(
                        id = v.getValue("id"), version = v.getValue("version"),
                        language = v.getValue("language"), parser = v.getValue("parser"),
                        renderer = v.getValue("renderer"), status = v.getValue("status"),
                        features = v.getValue("features").split(',').filter(String::isNotBlank),
                        limitations = v.getValue("limitations")
                    )
                }.toList()
        }
    }

    fun validate(packageRoot: Path): List<AdapterDescriptor> {
        val adapters = load(packageRoot)
        require(adapters.map { it.language }.distinct().size == adapters.size) { "Duplicate language adapter" }
        require(adapters.all { it.status == "LEXICAL_ONLY" || it.status == "VALIDATED_BACKEND" }) {
            "Unknown adapter status"
        }
        val mapping = packageRoot.resolve("mappings/source-target.og")
        require(Files.isRegularFile(mapping)) { "Missing source-target mapping policy" }
        val languages = adapters.map { it.language }.toSet()
        Files.readAllLines(mapping, StandardCharsets.UTF_8).filter { it.isNotBlank() && !it.startsWith("#") && !it.startsWith("ERIA-") && !it.startsWith("kind=") && !it.startsWith("version=") }
            .forEach { line ->
                val fields = line.split('|')
                require(fields.size == 4) { "Malformed source-target mapping: $line" }
                require(fields[0] in languages && fields[1] in languages) { "Mapping references unknown language: $line" }
                require(fields[2] in setOf("IDENTITY", "BLOCKED", "VALIDATED")) { "Unknown mapping mode: $line" }
            }
        return adapters
    }

    fun plan(packageRoot: Path, source: String, target: String): String {
        validate(packageRoot)
        val rows = Files.readAllLines(packageRoot.resolve("mappings/source-target.og"), StandardCharsets.UTF_8)
        val line = rows.firstOrNull { it.startsWith("$source|$target|") }
            ?: return "BLOCKED: no explicit source-target policy"
        val fields = line.split('|')
        return if (fields[2] == "IDENTITY" && source == target) "IDENTITY_ONLY: ${fields[3]}"
        else "BLOCKED: ${fields[3]}"
    }
}

object CanonicalIrBuilder {
    fun lexical(source: String, language: String): CanonicalIr {
        val atoms = mutableListOf<IrAtom>()
        var i = 0
        while (i < source.length) {
            val start = i
            val c = source[i]
            val kind: String
            when {
                c.isWhitespace() -> {
                    kind = "TRIVIA"
                    i++
                    while (i < source.length && source[i].isWhitespace()) i++
                }
                c == '"' || c == '\'' || c == '`' -> {
                    kind = "STRING_OR_QUOTED"
                    val quote = c
                    i++
                    var escaped = false
                    while (i < source.length) {
                        val next = source[i++]
                        if (escaped) escaped = false
                        else if (next == '\\') escaped = true
                        else if (next == quote) break
                    }
                }
                c == '_' || c == '$' || c.isLetter() -> {
                    kind = "IDENTIFIER"
                    i++
                    while (i < source.length && (source[i] == '_' || source[i] == '$' || source[i].isLetterOrDigit())) i++
                }
                c.isDigit() -> {
                    kind = "NUMBER_OR_DIGIT_SEQUENCE"
                    i++
                    while (i < source.length && (source[i].isLetterOrDigit() || source[i] == '_' || source[i] == '.')) i++
                }
                else -> {
                    kind = "SYMBOL"
                    i += Character.charCount(source.codePointAt(i))
                }
            }
            atoms += IrAtom(atoms.size, kind, start, i, source.substring(start, i))
        }
        val bytes = source.toByteArray(StandardCharsets.UTF_8)
        return CanonicalIr(language.uppercase(), bytes.size, sha256(bytes), atoms)
    }
}

object AshhsaHashGenerator {
    private const val MANIFEST = ".Ashhsa/hashes.hashes"

    data class Entry(val path: String, val size: Long, val digest: String)

    fun generate(packageRoot: Path): String {
        require(Files.isDirectory(packageRoot)) { "Package root does not exist: $packageRoot" }
        val manifestPath = packageRoot.resolve(MANIFEST)
        Files.createDirectories(manifestPath.parent)
        val entries = Files.walk(packageRoot).use { stream ->
            stream.filter { Files.isRegularFile(it) && it != manifestPath }
                .filter { !it.toString().replace('\\', '/').contains("/.git/") }
                .sorted()
                .map { path ->
                    val rel = packageRoot.relativize(path).toString().replace('\\', '/')
                    val bytes = Files.readAllBytes(path)
                    Entry(rel, bytes.size.toLong(), sha256(bytes))
                }.toList()
        }
        val canonical = entries.joinToString("\n", postfix = if (entries.isEmpty()) "" else "\n") {
            "${it.path}\t${it.size}\t${it.digest}"
        }
        val packageDigest = sha256(canonical)
        val body = buildString {
            appendLine("ASHHSA-HASHES/1")
            appendLine("algorithm=SHA-256")
            appendLine("entries=${entries.size}")
            appendLine("package_sha256=$packageDigest")
            appendLine("self_excluded=true")
            appendLine("# path<TAB>bytes<TAB>sha256")
            entries.forEach { append(it.path).append('\t').append(it.size).append('\t').append(it.digest).append('\n') }
        }
        Files.writeString(manifestPath, body, StandardCharsets.UTF_8)
        return body
    }
}
