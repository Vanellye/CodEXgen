package org.eria.og

import java.nio.file.Files
import java.nio.file.Path

fun main(args: Array<String>) {
    require(args.isNotEmpty()) { "Usage: validate|adapters|inspect|hash ..." }
    when (args[0]) {
        "validate" -> {
            val root = Path.of(args.getOrElse(1) { "language/og" })
            val adapters = AdapterRegistry.validate(root)
            println(".og package valid: ${adapters.size} lexical adapter profiles")
            println("Cross-language generation remains blocked until semantic backends are independently validated.")
        }
        "adapters" -> {
            val root = Path.of(args.getOrElse(1) { "language/og" })
            AdapterRegistry.validate(root).forEach { println("${it.language}\t${it.id}\t${it.status}") }
        }
        "inspect" -> {
            require(args.size == 3) { "Usage: inspect <language> <source-file>" }
            val source = Files.readString(Path.of(args[2]))
            print(CanonicalIrBuilder.lexical(source, args[1]).serialize())
        }
        "hash" -> {
            val root = Path.of(args.getOrElse(1) { "language/og" })
            print(AshhsaHashGenerator.generate(root))
        }
        else -> error("Unknown command: ${args[0]}")
    }
}
