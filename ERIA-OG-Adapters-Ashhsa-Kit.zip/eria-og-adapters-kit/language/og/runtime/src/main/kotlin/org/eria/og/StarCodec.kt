package org.eria.og

import java.nio.file.Files
import java.nio.file.Path

/** Reversible Ɣơ/2 byte envelope; not a replacement for binary storage. */
object StarCodec {
    private const val PREFIX = "Ɣơ/2:"
    fun encode(bytes: ByteArray): String = PREFIX + bytes.joinToString(".") { byte ->
        (7 downTo 0).joinToString("") { bit ->
            if ((((byte.toInt() and 0xff) ushr bit) and 1) == 1) "k" else "☆"
        }
    }
    fun decode(text: String): ByteArray {
        require(text.startsWith(PREFIX)) { "Unsupported Ɣơ profile" }
        val body = text.removePrefix(PREFIX)
        if (body.isEmpty()) return byteArrayOf()
        val groups = body.split(".")
        require(groups.all { it.length == 8 && it.all { c -> c == '☆' || c == 'k' } }) {
            "Each byte must contain exactly eight ☆/k symbols"
        }
        return groups.map { group ->
            var value = 0
            group.forEach { c -> value = (value shl 1) or if (c == 'k') 1 else 0 }
            value.toByte()
        }.toByteArray()
    }

    fun validateVectors(path: Path): Int {
        val rows = Files.readAllLines(path).filter { it.isNotBlank() && !it.startsWith("#") }
        rows.forEach { row ->
            val fields = row.split('|', limit = 3)
            require(fields.size == 3) { "Malformed Ɣơ/2 vector: $row" }
            val expected = if (fields[1].isEmpty()) byteArrayOf() else fields[1].chunked(2).map { it.toInt(16).toByte() }.toByteArray()
            require(encode(expected) == fields[2]) { "Ɣơ/2 encode mismatch: ${fields[0]}" }
            require(decode(fields[2]).contentEquals(expected)) { "Ɣơ/2 decode mismatch: ${fields[0]}" }
        }
        return rows.size
    }
}
