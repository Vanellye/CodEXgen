# ERIA Ɣơ / `.og` adapter package — implementation kit 0.2.0

This package makes language adapters declarative `.og` artifacts and supplies a Kotlin/JVM runtime for loading them, producing a lossless lexical canonical-IR snapshot, validating adapter metadata, and generating `.Ashhsa/hashes.hashes`.

## Scope and honesty boundary

- Implemented: `.og` descriptor loading, adapter registry, canonical lexical IR, exact source reconstruction, source digesting, compatibility-plan checks, deterministic SHA-256 manifest generation, and Kotlin Ɣơ/2 byte-codec parity tests.
- Not implemented: full parsers, type checkers, or semantically equivalent Kotlin/C++/Java/JavaScript/Bash source-to-source compilers. Cross-language generation is explicitly blocked until a backend and equivalence suite exist.
- No source is executed by the parser or generator.
- No Python runtime, Python backend, `.py` source, or Python-based test runner is included in this kit.

## Layout

- `language/og/adapters/*.og`: declarative language adapter profiles.
- `language/og/ir/canonical-ir.og`: canonical IR contract.
- `language/og/mappings/source-target.og`: explicit source/target policy.
- `language/og/templates/*.og`: reusable generation templates.
- `language/og/dependencies/manifest.og`: dependency contract.
- `language/og/history/transformations.og`: append-only transformation event examples.
- `language/og/fixtures/*.og`: shared adapter fixtures.
- `language/og/generation/generation-policy.og`: deterministic generation rules.
- `language/og/.Ashhsa/hashes.hashes`: generated package-integrity manifest.
- `language/og/runtime`: Kotlin/JVM implementation and tests.
- `migration/python-retirement.og`: inventory and staged retirement contract for the existing repository.

## Requirements

- JDK 17 or newer
- Kotlin compiler 2.x (`kotlinc`) on PATH

No third-party runtime dependencies are required.

## Test

```bash
bash language/og/scripts/test.sh
```

## CLI

After compiling with the test script, the CLI can be compiled separately or invoked from an IDE. Commands:

```text
validate <language/og package root>
adapters <language/og package root>
inspect <language> <source-file>
hash <language/og package root>
```

`inspect` writes a canonical lexical IR document to stdout. It preserves every source character and reports UTF-8 SHA-256 provenance. The IR is lexical, not a claim of semantic parsing.

## Hash manifest

The canonical output path is `language/og/.Ashhsa/hashes.hashes`. It contains SHA-256 digests for all package files except itself, plus a deterministic package digest over sorted `path<TAB>size<TAB>sha256` records. Regeneration is idempotent. The manifest does not hash itself recursively.

## Repository rollout boundary

This kit is an offline implementation candidate. It does not push commits, create branches, delete repository files, alter PRs, or modify `main`. The existing repository requires independent PONS authorization before remote writes. The Python retirement inventory is a migration plan, not a deletion operation.
