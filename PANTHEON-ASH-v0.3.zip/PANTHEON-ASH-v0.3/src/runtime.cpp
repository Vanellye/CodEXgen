#include "pantheon/runtime.hpp"
#include <fstream>
#include <sstream>
#include <algorithm>
#include <cctype>

namespace pantheon {
std::string trim(const std::string& s) { auto a=s.find_first_not_of(" \t\r\n"); if(a==std::string::npos)return {}; auto b=s.find_last_not_of(" \t\r\n"); return s.substr(a,b-a+1); }
Result Runtime::validate(const Module& m) const {
  Result r; r.ok=true; r.message="Configuration parsed; policy invariants checked.";
  static const std::set<std::string> required={"creation","knowledge","evolution","provenance","human_authority","payment_execution"};
  for(const auto& d:m.declarations) r.values[d.key]=d.value;
  for(const auto& k:required) if(!r.values.count(k)){r.ok=false;r.message="Missing required declaration: "+k;return r;}
  if(r.values["provenance"]!="REQUIRED" || r.values["human_authority"]!="REQUIRED") {r.ok=false;r.message="PONS invariant violation: provenance and human authority must remain REQUIRED.";return r;}
  if(r.values["payment_execution"]!="UNLOCKED") {r.ok=false;r.message="This build expects the explicitly requested UNLOCKED policy declaration.";return r;}
  return r;
}
Result Runtime::load(const std::string& path) {
  std::ifstream in(path); if(!in)return {false,"Cannot open PA configuration: "+path,{}};
  Module candidate; std::string line; int n=0; bool opened=false, closed=false;
  while(std::getline(in,line)){++n; auto t=trim(line); if(t.empty()||t[0]=='#')continue;
    if(t.rfind("PANTHEON",0)==0){opened=true; auto p=t.find(' '); candidate.name=p==std::string::npos?"PANTHEON":trim(t.substr(p)); continue;}
    if(t=="{"){continue;} if(t=="}"){closed=true;continue;}
    auto p=t.find('='); if(p==std::string::npos)return {false,"Expected key = VALUE at line "+std::to_string(n),{}};
    auto k=trim(t.substr(0,p)),v=trim(t.substr(p+1)); if(k.empty()||v.empty())return {false,"Empty key/value at line "+std::to_string(n),{}};
    if(v.back()==';') v.pop_back();
    v=trim(v);
    if(k.find_first_not_of("abcdefghijklmnopqrstuvwxyz_")!=std::string::npos)return {false,"Invalid key at line "+std::to_string(n),{}};
    candidate.declarations.push_back({k,v,n});
  }
  if(!opened||!closed)return {false,"Configuration must open PANTHEON and close with }",{}};
  auto check=validate(candidate); if(check.ok)current_=candidate; return check;
}
}
