#include "pantheon/runtime.hpp"
#include <iostream>
int main(int argc,char**argv){
  if(argc!=3 || std::string(argv[1])!="validate"){std::cerr<<"Pantheon PA runtime\nUsage: pantheon validate <file.pa>\n";return 2;}
  pantheon::Runtime rt; auto r=rt.load(argv[2]);
  std::cout<<(r.ok?"PANTHEON VALID":"PANTHEON REJECTED")<<"\n"<<r.message<<"\n";
  for(const auto& p:r.values)std::cout<<p.first<<" = "<<p.second<<"\n";
  return r.ok?0:1;
}
