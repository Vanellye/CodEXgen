#!/usr/bin/env sh
set -eu
make clean
make
./pantheon validate examples/ash-freedom.pa
if ./pantheon validate examples/missing.pa; then echo 'unexpected pass'; exit 1; fi
