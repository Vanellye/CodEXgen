# ASH integration boundary

Pantheon is the creation/configuration and intelligence layer above ASH. This v0.3 package provides a native PA configuration parser and policy validator. It does not yet replace the ASH HTTP banking server or connect a live provider.

`payment_execution = UNLOCKED` is the user's requested policy declaration. It means the configuration does not impose a Pantheon-level lock. It does **not** make a payment endpoint operational, grant bank-provider permissions, bypass provider authorization, or prove identity/compliance. ASH must still require authenticated user consent, provider-supported authorization, transaction limits, idempotency, fraud controls, and applicable compliance checks before any real transfer. No transfer code is included in this milestone.

Future integration contract: ASH reads a validated, signed, versioned PA policy; records the policy hash and author; rejects stale or unsigned policy; and keeps payment execution behind its independent provider and human-consent controls.
