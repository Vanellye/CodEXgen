#pragma once
#include <string>
#include <vector>
#include <map>
#include <set>

namespace pantheon {
struct Declaration { std::string key, value; int line; };
struct Module { std::string name; std::vector<Declaration> declarations; };
struct Result { bool ok=false; std::string message; std::map<std::string,std::string> values; };
class Runtime {
public:
  Result load(const std::string& path);
  Result validate(const Module& module) const;
  const Module& module() const { return current_; }
private:
  Module current_;
};
std::string trim(const std::string& s);
}
