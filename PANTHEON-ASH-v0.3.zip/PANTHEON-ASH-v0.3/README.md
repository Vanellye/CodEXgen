# PANTHEON ∞ / ASH — v0.3

Pantheon is positioned above ASH as its open-ended creation and intelligence layer. PA (`.pa`) is its native declarative configuration format. The initial runtime is native C++17 and has no Python dependency.

## What this milestone does
- Parses PA configurations.
- Validates required governance declarations.
- Allows open-ended creation, continuous discovery, and versioned evolution as declared policy values.
- Requires provenance and human authority as invariants.
- Accepts the explicit `payment_execution = UNLOCKED` declaration requested by the project owner.

## What it does not claim
This is a small, auditable v0.3 configuration runtime—not omniscient, self-modifying, or production banking software. `LIVE_VERSIONED` is a policy declaration, not a hot-reload service yet. Knowledge discovery, AI model connections, distributed federation, signatures, and live provider adapters are future modules. The PA parser does not execute arbitrary native code.

The UNLOCKED declaration expresses that Pantheon itself does not impose the requested lock. It cannot grant a bank's permission to move money or override identity, consent, provider rules, or law. This package contains no payment execution implementation and performs no transfers.

## Build on Termux
```sh
pkg update -y
pkg install clang make -y
unzip PANTHEON-ASH-v0.3.zip
cd PANTHEON-ASH-v0.3
make
make check
```

## Run
```sh
./pantheon validate examples/ash-freedom.pa
```

Expected result begins with `PANTHEON VALID` and prints the policy declarations.

## Create a configuration
Copy `examples/ash-freedom.pa`, edit values, then run the validator. Required declarations are `creation`, `knowledge`, `evolution`, `provenance`, `human_authority`, and `payment_execution`. The current validator accepts the explicit `UNLOCKED` value while retaining provenance and human-authority invariants.

## Roadmap
1. PA grammar, typed values, modules, imports, and schema validation.
2. Signed manifests, immutable version history, staged activation, and rollback.
3. Sandboxed extension API and capability-based permissions.
4. Evidence-backed knowledge adapters and uncertainty tracking.
5. ASH policy bridge and audited banking-provider adapters.
6. Secure federation and end-to-end encrypted messaging.

See `ash-bridge/POLICY.md` for the ASH/payment boundary.
