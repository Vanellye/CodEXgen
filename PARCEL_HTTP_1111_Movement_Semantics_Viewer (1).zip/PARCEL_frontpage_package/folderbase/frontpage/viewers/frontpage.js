const $=id=>document.getElementById(id);
const clone=x=>JSON.parse(JSON.stringify(x));
let record={
 schema:"tri-quannected-record/0.1",id:"example-001",title:"Tri-Quannected example",
 question:"How can related files be found, interpreted and reused without losing their origins?",
 tri_quannected:{origin:{status:"recorded",source:"folderbase/records/example.json"},semantics:{status:"proposed",concepts:["find","interpret","connect","reuse"]},evolution:{status:"proposed",transformations:[]}},
 views:{
  text:{content:"One canonical record can support multiple synchronized views."},
  audio_visual:{label:"3Ɛ",channels:["text","audio","visual"],audio:{status:"not_attached",src:null},visual:{status:"illustrative",description:"Three linked channels sharing one record identity."},timeline:[]},
  geometry:{mode:"conceptual",dimensions:["origin","meaning","evolution"],nodes:[{id:"origin",label:"Origin",x:0,y:0},{id:"semantics",label:"Semantics",x:1,y:0},{id:"evolution",label:"Evolution",x:.5,y:.866}],edges:[["origin","semantics"],["semantics","evolution"],["evolution","origin"]]},
  asymmetry:{left_label:"Source",right_label:"Proposed reuse",left:["original bytes","source hash","lineage"],right:["new view","semantic mapping","validation status"],comparison:"Unequal sides remain visible; no forced equivalence."},
  excedra:{unknowns:["Actual audio attachment","Measured spatial coordinates","Cross-platform parity result"],boundaries:["No inference of missing data","No execution of decoded content"],evidence_status:"incomplete"}
 },
 provenance:{source_path:"folderbase/records/example.json",source_hash:null,original_preserved:true,transformations_reversible:true}
};
let active="text";
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function sync(){ $("recordTitle").textContent=record.title||"Untitled record";$("question").value=record.question||"";$("recordId").textContent="ID: "+(record.id||"unassigned");$("provenance").textContent="Source: "+(record.provenance?.source_path||"not recorded");$("jsonOutput").textContent=JSON.stringify(record,null,2);}
function card(title,body){return `<article class="card"><h3>${esc(title)}</h3>${body}</article>`}
function render(){
 document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b.dataset.view===active));
 const v=record.views||{};let out="";
 if(active==="text"){out=`<div class="eyebrow">TEXT VIEWER</div><h2>Editable semantic text</h2><textarea id="textContent" rows="6">${esc(v.text?.content||"")}</textarea><p class="hint">Text edits update the shared JSON record, not an independent duplicate file.</p>`;}
 if(active==="audio_visual"){let a=v.audio_visual||{};out=`<div class="eyebrow">3Ɛ · THREE LINKED CHANNELS</div><h2>Text · Audio · Visual</h2><div class="cards">${card("Text",`<p>${esc(v.text?.content||"No text content")}</p>`)}${card("Audio",`<p>Status: ${esc(a.audio?.status||"unknown")}</p><p class="muted">No audio file is attached. The viewer does not invent playback content.</p>`)}${card("Visual",`<p>${esc(a.visual?.description||"No visual description")}</p>`)}</div><p class="hint">3Ɛ is treated here as a provisional three-channel alignment label. It is metadata, not a media codec.</p>`;}
 if(active==="geometry"){let g=v.geometry||{},nodes=g.nodes||[];out=`<div class="eyebrow">VIRTUAL GEOMETRY · CONCEPTUAL</div><h2>Relationship space</h2><svg class="geometry" viewBox="0 0 440 300" role="img" aria-label="Conceptual triangle connecting origin, semantics and evolution"><line class="edge" x1="95" y1="220" x2="345" y2="220"/><line class="edge" x1="345" y1="220" x2="220" y2="45"/><line class="edge" x1="220" y1="45" x2="95" y2="220"/><circle class="node" cx="95" cy="220" r="39"/><circle class="node" cx="345" cy="220" r="39"/><circle class="node" cx="220" cy="45" r="39"/><text class="nodeText" x="95" y="224">Origin</text><text class="nodeText" x="345" y="224">Semantics</text><text class="nodeText" x="220" y="49">Evolution</text></svg><p class="hint">Conceptual geometry only. Coordinates and edges do not claim physical measurement.</p><p>Dimensions: ${esc((g.dimensions||[]).join(" · "))}</p>`;}
 if(active==="asymmetry"){let a=v.asymmetry||{};out=`<div class="eyebrow">ASYMMETRICAL VIEWER</div><h2>Compare without forcing equivalence</h2><div class="cards">${card(a.left_label||"Source",`<ul>${(a.left||[]).map(x=>`<li>${esc(x)}</li>`).join("")}</ul>`)}${card(a.right_label||"Proposed reuse",`<ul>${(a.right||[]).map(x=>`<li>${esc(x)}</li>`).join("")}</ul>`)}</div><p>${esc(a.comparison||"Comparison not defined.")}</p>`;}
 if(active==="excedra"){let e=v.excedra||{};out=`<div class="eyebrow">EXCEDRA · BOUNDARIES & UNKNOWNS</div><h2>What remains unresolved</h2><div class="cards">${card("Unknowns",(e.unknowns||[]).map(x=>`<div class="unknown">${esc(x)}</div>`).join("")||"<p>None recorded.</p>")}${card("Boundaries",(e.boundaries||[]).map(x=>`<p>• ${esc(x)}</p>`).join("")||"<p>None recorded.</p>")}</div><p>Evidence status: <strong>${esc(e.evidence_status||"unspecified")}</strong></p>`;}
 if(active==="folderbase"){out=`<div class="eyebrow">REPOSITORY FRONTpage</div><h2>Folderbase navigation model</h2><div class="filetree"><div class="folder">📁 folderbase/</div><div>　<span class="folder">📁 frontpage/</span></div><div>　　<span class="folder">📁 viewers/</span></div><div>　　　<span class="file">📄 index.html</span></div><div>　　　<span class="file">📄 frontpage.css</span></div><div>　　　<span class="file">📄 frontpage.js</span></div><div>　<span class="folder">📁 schemas/</span></div><div>　　<span class="file">📄 tri-quannected-record.schema.json</span></div><div>　<span class="folder">📁 records/</span></div><div>　　<span class="file">📄 example.json</span></div></div><p class="hint">Illustrative package tree. Loading this viewer does not browse or mutate a remote repository.</p>`;}
 $("view").innerHTML=out;
 if(active==="text")$("textContent").addEventListener("input",e=>{record.views.text.content=e.target.value;sync();});
 sync();
}
document.querySelectorAll(".tab").forEach(b=>b.addEventListener("click",()=>{active=b.dataset.view;render()}));
$("question").addEventListener("input",e=>{record.question=e.target.value;sync()});
$("previewReplace").addEventListener("click",()=>{
 const needle=$("findText").value,repl=$("replaceText").value,caseSensitive=$("caseSensitive").checked;
 if(!needle){$("replaceResult").textContent="Enter a search term first.";return}
 const hay=JSON.stringify(record,null,2),source=caseSensitive?hay:hay.toLowerCase(),term=caseSensitive?needle:needle.toLowerCase();
 let count=0,pos=0;while((pos=source.indexOf(term,pos))!==-1){count++;pos+=term.length}
 $("replaceResult").textContent=`${count} exact text occurrence(s) found in the current JSON representation.\nProposed replacement: ${repl||"(not supplied)"}\nNo file was changed. Review context before treating matches as semantically equivalent.`;
});
$("copyBtn").addEventListener("click",async()=>{try{await navigator.clipboard.writeText(JSON.stringify(record,null,2));$("status").textContent="JSON copied."}catch{$("status").textContent="Clipboard unavailable; select the JSON text to copy."}});
$("downloadBtn").addEventListener("click",()=>{const blob=new Blob([JSON.stringify(record,null,2)],{type:"application/json"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=(record.id||"record")+".json";a.click();URL.revokeObjectURL(a.href);});
$("loadBtn").addEventListener("click",()=>$("fileInput").click());
$("fileInput").addEventListener("change",async e=>{const f=e.target.files?.[0];if(!f)return;try{const parsed=JSON.parse(await f.text());if(!parsed||typeof parsed!=="object"||!parsed.views||!parsed.provenance)throw Error("Not a compatible Tri-Quannected record");record=parsed;$("sourceStatus").textContent="Loaded local JSON";render();$("status").textContent="Loaded one shared JSON record."}catch(err){$("status").textContent="Could not load: "+err.message}});
render();
