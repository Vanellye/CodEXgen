# Tri-Quannected Frontpage Viewers (prototype)

This extends the PARCEL mobile fixture with a folderbase-backed viewer system.

## Open
Open `folderbase/frontpage/viewers/index.html` in a modern browser. It is a local static prototype.

## Shared-record principle
The viewers consume one canonical JSON record (`folderbase/records/example.json`) and one schema (`folderbase/schemas/tri-quannected-record.schema.json`). Views are projections of that record, not copied independent datasets.

## Viewers
- Text: editable semantic text.
- 3Ɛ audio-visual: aligned text/audio/visual channel metadata. `3Ɛ` is provisional and currently means three linked channels; no audio file is fabricated.
- Virtual geometry: conceptual relationship diagram, not physical measurement.
- Asymmetrical: compares unequal source and reuse structures without forcing equivalence.
- Excedra: keeps unknowns, evidence gaps and boundaries visible.
- Folderbase: shows the package's folder navigation model.

## Find / replace / reuse
The workbench previews exact text occurrences in the current JSON representation. It does not apply replacements. Semantic replacements require contextual review, source anchoring, reversible patches, validation and authorization.

## Safety and limitations
- No network, telemetry, shell execution, or repository writes.
- JSON loading is local and parsed as data; it is never evaluated as code.
- Audio playback is not implemented until a real, user-supplied or authorized audio asset is attached.
- Geometry is illustrative, not a simulation or physical coordinate system.
- This is a viewer prototype, not a production cross-platform repository client.
