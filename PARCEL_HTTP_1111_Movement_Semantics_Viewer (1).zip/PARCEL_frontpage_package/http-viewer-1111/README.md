# PARCEL HTTP Frontpage Viewer — port 1111

## Start
From this directory run:

```sh
python3 server.py
```

Then open `http://127.0.0.1:1111` on the same device. To choose another port, set `PORT`, e.g. `PORT=1112 python3 server.py`.

## What it does
- Serves a local read-only HTTP interface on port 1111.
- Lists JSON records from this package's `data/` directory.
- Displays movement labels as origin-preserving semantic mappings.
- Separates the stage sequence: reduction, breakdown, overview, birth, build, expansion, evolution, adapt, edify, transendance.
- Exposes past, present, future, below, above, beyond and Excedra views.
- Shows the same canonical JSON record in a structured view and permits copy/export.

## Movement mapping policy
The labels running, jumping, squatting, walking and crawling remain intact as origin labels. Proposed flow labels and temporal/spatial interpretations are additive semantic mappings. These are illustrative classifications, not biomechanical measurements or claims of physical equivalence.

## HTTP/API
- `GET /api/records` — list bundled JSON record names and sizes.
- `GET /api/record?name=movement-semantics.json` — retrieve one JSON record.
- Other API paths return 404.
- POST requests return 405. The server is read-only and rejects writes.

## Placement status
This is a local staged prototype. It does not create repository branches, commits, frontpages or remote files. Repository placement requires a separately authorized GitHub operation and successful verification.
