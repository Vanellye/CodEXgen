let data=null, selected=0, axis="present";
const $=id=>document.getElementById(id);
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const axes=["past","present","future","below","above","beyond","excedra"];
async function getJSON(url){const r=await fetch(url);if(!r.ok)throw Error(`HTTP ${r.status}`);return r.json()}
async function init(){try{const listing=await getJSON("/api/records");$("recordSelect").innerHTML=listing.records.map(x=>`<option>${esc(x.name)}</option>`).join("");$("files").innerHTML=listing.records.map(x=>`<span class="file">▣ ${esc(x.name)} · ${x.bytes} bytes</span>`).join("");await load()}catch(e){$("status").textContent=e.message}}
async function load(){try{const name=$("recordSelect").value||"movement-semantics.json";data=await getJSON("/api/record?name="+encodeURIComponent(name));selected=0;render();$("status").textContent="Loaded "+name}catch(e){$("status").textContent=e.message}}
function render(){if(!data)return;
 $("stages").innerHTML=data.stages.map((s,i)=>`<div class="stage"><b>${String(i+1).padStart(2,"0")} · ${esc(s.label)}</b><small>${esc(s.dimension)} · ${esc(s.output)}</small><div>${esc(s.question)}</div></div>`).join("");
 $("movements").innerHTML=data.movement_mappings.map((m,i)=>`<button class="movement ${i===selected?"active":""}" data-i="${i}"><b>${esc(m.origin_label)}</b><br><small>${esc(m.flow_label)}</small></button>`).join("");
 document.querySelectorAll(".movement").forEach(b=>b.onclick=()=>{selected=+b.dataset.i;render()});
 $("axisTabs").innerHTML=axes.map(a=>`<button class="${a===axis?"active":""}" data-axis="${a}">${a}</button>`).join("");
 document.querySelectorAll("[data-axis]").forEach(b=>b.onclick=()=>{axis=b.dataset.axis;render()});
 const m=data.movement_mappings[selected];$("axisTitle").textContent=m.origin_label+" · "+axis+" perspective";
 const val=m[axis];const items=Array.isArray(val)?val:[val];
 $("axisView").innerHTML=`<div class="flow-grid">${items.map((v,i)=>`<div class="tile"><h3>${esc(axis.toUpperCase())} ${items.length>1?i+1:""}</h3>${esc(v)}</div>`).join("")}</div>`;
 $("detail").innerHTML=`<h3>${esc(m.origin_label)}</h3><p><b>Original label:</b> ${esc(m.origin_label)}</p><p><b>Proposed flow:</b> ${esc(m.flow_label)}</p><p><b>Status:</b> ${esc(m.mapping_status)}</p><p><b>Origin:</b> ${esc(data.origin.preservation_rule)}</p>`;
 $("jsonTree").textContent=JSON.stringify(data,null,2);
}
$("reload").onclick=load;$("recordSelect").onchange=load;
$("download").onclick=()=>{const blob=new Blob([JSON.stringify(data,null,2)],{type:"application/json"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=(data.id||"parcel-record")+".json";a.click();URL.revokeObjectURL(a.href)};
$("copy").onclick=async()=>{try{await navigator.clipboard.writeText(JSON.stringify(data,null,2));$("status").textContent="JSON copied"}catch{$("status").textContent="Clipboard unavailable"}};
init();