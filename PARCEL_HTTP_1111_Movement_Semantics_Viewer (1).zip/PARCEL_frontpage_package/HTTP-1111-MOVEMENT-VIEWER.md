# HTTP 1111 Movement Viewer

A local read-only HTTP viewer is staged in `http-viewer-1111/`.

It presents a staged conversation from reduction through transendance, keeps the supplied movement labels intact, and provides time/position/boundary views (past, present, future, below, above, beyond, Excedra). The JSON record and schema are viewable in the browser.

Run `python3 http-viewer-1111/server.py`, then open `http://127.0.0.1:1111`.

This is local staging only. No remote repository placement is claimed.
