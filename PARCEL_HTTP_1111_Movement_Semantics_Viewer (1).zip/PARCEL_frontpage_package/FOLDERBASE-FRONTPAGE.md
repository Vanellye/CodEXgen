# Repository Frontpage / folderbase

The Frontpage is the navigable folder-system interface backed by the repository's actual `folderbase`, not a landing-page document.

The Tri-Quannected viewer prototype lives at `folderbase/frontpage/viewers/`. It presents one canonical JSON record through text, 3Ɛ audio-visual, conceptual geometry, asymmetrical comparison, Excedra, and folderbase views.

Shared schemas and records live in `folderbase/schemas/` and `folderbase/records/`. Avoid duplicating the same facts into per-viewer JSON files. Preserve source provenance and treat viewer-specific representations as projections of the shared record.

The `3Ɛ` label is provisional: this prototype uses it for three linked channels (text, audio, visual). It does not imply that an audio asset exists or that a media codec has been implemented.
