# Ɣ Foundation — Version 0.1

## 1. Independence

Ɣ is its own language with its own grammar, type model, semantics, module system, and evolution process. ERIA may later host a Ɣ implementation, but ERIA does not define Ɣ and Ɣ does not depend on ERIA.

## 2. Meaning before representation

A source program begins as structured meaning. A value is not restricted to a Boolean or a machine word. The initial semantic domains are:

- **Scalar** — a discrete value such as text, integer, decimal, or symbol.
- **Set** — a collection of possible values.
- **Spectrum** — a graded or uncertain value with an explicit scale and evidence.
- **Relation** — a named connection between entities.
- **Process** — a described transformation or sequence.
- **Event** — an immutable occurrence with source and time.
- **Constraint** — a condition that must be considered by an evaluator.
- **Unknown** — an explicit absence of sufficient evidence, not false.
- **Conflict** — two or more incompatible claims retained with provenance.

These are language-level semantic types. A runtime may encode them in many ways.

## 3. Multi-valued truth

Ɣ does not collapse every evaluation into true/false. Its initial assessment values are:

- `affirmed`
- `denied`
- `uncertain`
- `unknown`
- `conflicted`
- `not_applicable`

An evaluator must preserve the evidence and rule that produced an assessment. An assessment is not an authorization.

## 4. Provenance

Every declared fact may carry:
- origin
- timestamp or temporal scope
- evidence reference
- confidence or uncertainty expression
- transformation lineage

The language must not silently convert an inference into an observed fact.

## 5. Change and adaptability

Change is represented as events and state transitions. Adaptation proposes a new state or model; it does not silently grant authority to apply it.

## 6. Authority boundary

Ɣ can describe policies, permissions, proposals, and decisions. Describing an action is not executing it. Any privileged effect must cross an explicit host-authority boundary controlled by the local administrator or another explicitly configured authority.

## 7. Beyond binary — precise interpretation

Ɣ is "beyond binary" at the level of meaning, composition, and evaluation:
- values can be graded, relational, plural, uncertain, or unresolved;
- expressions can preserve multiple interpretations;
- evaluation can return evidence-bearing assessments rather than a single bit.

The physical implementation may still use binary processors and storage. Ɣ does not claim otherwise.
