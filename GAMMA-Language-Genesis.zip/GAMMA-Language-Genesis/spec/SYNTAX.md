# Ɣ Syntax — Version 0.1

The initial syntax is deliberately readable and line-oriented.

## Declarations
```gamma
language Ɣ
domain Adaptability

concept Signal
concept Capability

value readiness: spectrum = 0.82 on scale "0..1"
value status: assessment = uncertain
```

## Relations
```gamma
relation Signal influences Capability
relation Capability belongs_to Domain
```

## Evidence and assessments
```gamma
evidence E1 from "local-observation" observed_at "2026-11-18T00:00:00Z"
claim readiness is 0.82 supported_by E1
assess readiness as affirmed when evidence E1 is_valid
```

## Events
```gamma
event CapabilityDiscovered
  source "gamma.adaptability"
  kind "adaptability.capability.discovered"
  payload { name: "stream-analysis", state: "available" }
end
```

## Transitions
```gamma
transition CapabilityState
  from unknown
  propose available
  when evidence E1 is_valid
end
```

## Constraints
```gamma
constraint HumanAuthority
  privileged_effect requires local_administrator
  observer cannot authorize
end
```

## Composition
```gamma
flow Discovery
  observe Signal
  derive Capability
  emit CapabilityDiscovered
end
```

The prototype checker currently validates the document envelope, declaration forms, block pairing, and basic structural errors. The complete semantic rules above are design commitments, not all implemented features.
