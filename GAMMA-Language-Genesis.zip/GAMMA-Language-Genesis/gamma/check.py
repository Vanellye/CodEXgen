#!/usr/bin/env python3
"""Minimal structural checker for Ɣ v0.1 source files. No execution."""
from pathlib import Path
import re, sys

TOP_LEVEL = (
    "language ", "domain ", "concept ", "value ", "relation ",
    "evidence ", "claim ", "assess ", "event ", "transition ",
    "constraint ", "flow "
)
BLOCK_START = ("event ", "transition ", "constraint ", "flow ")

def check(path: Path):
    errors, warnings = [], []
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        return [f"cannot read file: {exc}"], []
    stack = []
    saw_language = False
    for n, raw in enumerate(lines, 1):
        line = raw.strip()
        if not line or line.startswith("#") or line.startswith("(*"):
            continue
        if line == "language Ɣ":
            if saw_language:
                errors.append(f"{n}: duplicate language declaration")
            saw_language = True
            continue
        if line == "end":
            if not stack:
                errors.append(f"{n}: 'end' without an open block")
            else:
                stack.pop()
            continue
        if line.startswith(BLOCK_START):
            if not re.match(r"^(event|transition|constraint|flow)\s+[A-Za-z_][\w-]*$", line):
                errors.append(f"{n}: malformed block declaration")
            else:
                stack.append((line.split()[0], n))
            continue
        if line.startswith(TOP_LEVEL):
            if stack:
                warnings.append(f"{n}: top-level declaration inside {stack[-1][0]} block")
            continue
        if stack:
            # Block bodies are intentionally permissive in this seed parser.
            continue
        errors.append(f"{n}: unrecognized top-level statement: {line[:72]}")
    if not saw_language:
        errors.append("missing 'language Ɣ' declaration")
    for kind, n in reversed(stack):
        errors.append(f"{n}: unclosed {kind} block (missing 'end')")
    return errors, warnings

def main():
    if len(sys.argv) != 2:
        print("Usage: python gamma/check.py FILE.gamma")
        return 2
    path = Path(sys.argv[1])
    errors, warnings = check(path)
    for item in warnings:
        print("WARNING:", item)
    for item in errors:
        print("ERROR:", item)
    if errors:
        print(f"Ɣ check failed: {len(errors)} error(s), {len(warnings)} warning(s)")
        return 1
    print(f"Ɣ check passed: {path} ({len(warnings)} warning(s))")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
