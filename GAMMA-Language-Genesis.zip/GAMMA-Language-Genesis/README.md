# Ɣ (Gamma) — Language Genesis

Ɣ is an independent language project. It is not an ERIA subsystem and does not require ERIA to define, parse, validate, or evolve its source language.

Its founding idea is **meaning before representation**:
- express relations, uncertainty, change, intent, and constraints as first-class structures;
- do not force every concept into a Boolean true/false choice at the language level;
- preserve provenance and make interpretation inspectable;
- connect to binary machines only through explicit, replaceable execution backends.

"Beyond binary" describes the semantic model, not a claim that physical computers stop using binary electronics. A Ɣ implementation may ultimately run on binary hardware while preserving richer meaning above that boundary.

## Package contents
- `spec/FOUNDATION.md` — principles and semantic model
- `spec/SYNTAX.md` — initial notation
- `spec/GRAMMAR.ebnf` — compact grammar sketch
- `spec/ARCHITECTURE.md` — independent language stack and backend boundary
- `gamma/check.py` — small standard-library syntax/structure checker
- `examples/genesis.gamma` — sample Ɣ source
- `examples/adaptability.gamma` — event and relation example

## Try the prototype
Python 3.10+:
```bash
python gamma/check.py examples/genesis.gamma
python gamma/check.py examples/adaptability.gamma
```

This is a language seed and structural checker, not yet a full compiler or runtime. It does not execute commands, access networks, write repositories, or grant permissions.
