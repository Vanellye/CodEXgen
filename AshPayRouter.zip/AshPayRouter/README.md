# AshPayRouter

A provider-independent, **simulation-only** Kotlin routing module for comparing BTC→USD quotes.

## Safety boundary
- No live exchange adapters, API credentials, wallet signing, BTC transfer, sale, or bank payout.
- The router only ranks quotes and returns a recommendation.
- A recommendation is not payment authorization.
- No silent route changes after a quote has been selected.
- Unknown, expired, unhealthy, ineligible, or out-of-limit quotes are excluded.

## Run tests
Requires JDK 17+ and Gradle 8+:
```bash
gradle test
```

## Design
`ExchangeProvider` is the provider contract. `MockExchangeProvider` supplies deterministic fixtures.
`AshPayRouter` requests quotes, validates eligibility, computes net USD, and selects the highest net payout.
Tie-breaks are deterministic: shorter estimated settlement, then provider ID.

All monetary arithmetic uses `BigDecimal`; BTC is represented in satoshis (`Long`) to avoid floating-point precision errors.

## Integration boundary
A future live adapter must be separately reviewed and must not add execution methods to this routing module.
A separate transaction coordinator must require explicit user confirmation, independently verified PONS authorization, provider-side order idempotency, and settlement reconciliation before any real transaction.
