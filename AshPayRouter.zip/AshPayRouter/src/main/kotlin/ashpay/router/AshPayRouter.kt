package ashpay.router

import java.math.BigDecimal

class AshPayRouter(
    private val providers: List<ExchangeProvider>,
    private val maximumQuoteAgeSeconds: Long = 120
) {
    init {
        require(maximumQuoteAgeSeconds > 0) { "maximumQuoteAgeSeconds must be positive" }
        require(providers.map { it.providerId }.distinct().size == providers.size) {
            "Provider IDs must be unique"
        }
    }

    fun selectBestRoute(request: RoutingRequest): RoutingDecision {
        require(request.amountSats > 0) { "amountSats must be positive" }
        require(request.maximumSettlementSeconds >= 0) { "maximumSettlementSeconds cannot be negative" }

        val evaluations = mutableListOf<ProviderEvaluation>()
        val eligible = mutableListOf<ExchangeQuote>()

        for (provider in providers.sortedBy { it.providerId }) {
            val caps = runCatching { provider.capabilities() }.getOrNull()
            if (caps == null) {
                evaluations += ProviderEvaluation(provider.providerId, null, false, null, "CAPABILITIES_UNAVAILABLE")
                continue
            }
            val failure = when {
                !caps.supportsBtcUsd -> "PAIR_UNSUPPORTED"
                !caps.supportsBankPayout -> "BANK_PAYOUT_UNSUPPORTED"
                !caps.accountVerified -> "ACCOUNT_NOT_VERIFIED"
                !caps.healthy -> "PROVIDER_UNHEALTHY"
                else -> null
            }
            if (failure != null) {
                evaluations += ProviderEvaluation(provider.providerId, null, false, null, failure)
                continue
            }

            val quote = runCatching { provider.quoteBtcToUsd(request.amountSats, request.now) }.getOrNull()
            if (quote == null) {
                evaluations += ProviderEvaluation(provider.providerId, null, false, null, "QUOTE_UNAVAILABLE")
                continue
            }

            val net = runCatching { quote.netUsd() }.getOrNull()
            val reason = when {
                quote.providerId != provider.providerId -> "PROVIDER_ID_MISMATCH"
                quote.amountSats != request.amountSats -> "AMOUNT_MISMATCH"
                quote.quoteId.isBlank() -> "INVALID_QUOTE_ID"
                quote.grossUsd < BigDecimal.ZERO ||
                    quote.tradingFeeUsd < BigDecimal.ZERO ||
                    quote.withdrawalFeeUsd < BigDecimal.ZERO ||
                    quote.otherFeeUsd < BigDecimal.ZERO -> "INVALID_NEGATIVE_AMOUNT"
                net == null || net < BigDecimal.ZERO -> "NEGATIVE_NET_PAYOUT"
                !quote.expiresAt.isAfter(request.now) -> "QUOTE_EXPIRED"
                quote.expiresAt.epochSecond - request.now.epochSecond > maximumQuoteAgeSeconds -> "QUOTE_EXPIRY_TOO_FAR"
                quote.estimatedSettlementSeconds < 0 -> "INVALID_SETTLEMENT_ESTIMATE"
                quote.estimatedSettlementSeconds > request.maximumSettlementSeconds -> "SETTLEMENT_TOO_SLOW"
                net < request.minimumNetUsd -> "BELOW_MINIMUM_NET_PAYOUT"
                else -> null
            }

            if (reason == null) {
                eligible += quote
                evaluations += ProviderEvaluation(provider.providerId, quote.quoteId, true, net, "ELIGIBLE")
            } else {
                evaluations += ProviderEvaluation(provider.providerId, quote.quoteId, false, net, reason)
            }
        }

        val selected = eligible.sortedWith(
            compareByDescending<ExchangeQuote> { it.netUsd() }
                .thenBy { it.estimatedSettlementSeconds }
                .thenBy { it.providerId }
        ).firstOrNull()

        return RoutingDecision(selected, evaluations)
    }
}
