package ashpay.router

import java.time.Instant

class MockExchangeProvider(
    override val providerId: String,
    private val caps: ProviderCapabilities,
    private val quoteFactory: (Long, Instant) -> ExchangeQuote
) : ExchangeProvider {
    override fun capabilities() = caps
    override fun quoteBtcToUsd(amountSats: Long, now: Instant) = quoteFactory(amountSats, now)
}
