package ashpay.router

import java.math.BigDecimal
import java.time.Instant
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull
import kotlin.test.assertTrue

class AshPayRouterTest {
    private val now = Instant.parse("2026-11-18T12:00:00Z")
    private val caps = ProviderCapabilities(true, true, true, true)
    private fun quote(id: String, provider: String, gross: String, fee: String = "0",
                      expirySeconds: Long = 60, settlement: Long = 300,
                      amount: Long = 100_000_000) = ExchangeQuote(
        id, provider, amount, BigDecimal(gross), BigDecimal(fee),
        BigDecimal.ZERO, BigDecimal.ZERO, settlement, now.plusSeconds(expirySeconds)
    )

    @Test fun selectsHighestNetPayoutAfterFees() {
        val router = AshPayRouter(listOf(
            MockExchangeProvider("A", caps) { a, _ -> quote("qa", "A", "60000", "20", amount = a) },
            MockExchangeProvider("B", caps) { a, _ -> quote("qb", "B", "60030", "10", amount = a) }
        ))
        val decision = router.selectBestRoute(RoutingRequest(100_000_000, now))
        assertEquals("B", decision.selectedProviderId)
        assertEquals(BigDecimal("60020"), decision.selectedQuote!!.netUsd())
    }

    @Test fun excludesExpiredQuotes() {
        val router = AshPayRouter(listOf(
            MockExchangeProvider("A", caps) { a, _ -> quote("qa", "A", "60000", expirySeconds = 0, amount = a) }
        ))
        val decision = router.selectBestRoute(RoutingRequest(100_000_000, now))
        assertNull(decision.selectedQuote)
        assertEquals("QUOTE_EXPIRED", decision.evaluations.single().reason)
    }

    @Test fun excludesUnverifiedAndUnhealthyProviders() {
        val router = AshPayRouter(listOf(
            MockExchangeProvider("A", caps.copy(accountVerified = false)) { a, _ -> quote("qa", "A", "60000", amount = a) },
            MockExchangeProvider("B", caps.copy(healthy = false)) { a, _ -> quote("qb", "B", "61000", amount = a) }
        ))
        val decision = router.selectBestRoute(RoutingRequest(100_000_000, now))
        assertNull(decision.selectedQuote)
        assertTrue(decision.evaluations.all { !it.eligible })
    }

    @Test fun rejectsMismatchedAmountAndNegativeFees() {
        val router = AshPayRouter(listOf(
            MockExchangeProvider("A", caps) { _, _ -> quote("qa", "A", "60000", amount = 50_000_000) },
            MockExchangeProvider("B", caps) { a, _ -> quote("qb", "B", "60000", "-1", amount = a) }
        ))
        val decision = router.selectBestRoute(RoutingRequest(100_000_000, now))
        assertNull(decision.selectedQuote)
        assertEquals(setOf("AMOUNT_MISMATCH", "INVALID_NEGATIVE_AMOUNT"),
            decision.evaluations.map { it.reason }.toSet())
    }

    @Test fun deterministicTieBreakUsesSettlementThenProviderId() {
        val router = AshPayRouter(listOf(
            MockExchangeProvider("B", caps) { a, _ -> quote("qb", "B", "60000", settlement = 400, amount = a) },
            MockExchangeProvider("A", caps) { a, _ -> quote("qa", "A", "60000", settlement = 200, amount = a) }
        ))
        assertEquals("A", router.selectBestRoute(RoutingRequest(100_000_000, now)).selectedProviderId)
    }

    @Test fun rejectsQuoteWithExpiryOutsideConfiguredFreshnessWindow() {
        val router = AshPayRouter(
            listOf(MockExchangeProvider("A", caps) { a, _ -> quote("qa", "A", "60000", expirySeconds = 500, amount = a) }),
            maximumQuoteAgeSeconds = 120
        )
        assertEquals("QUOTE_EXPIRY_TOO_FAR",
            router.selectBestRoute(RoutingRequest(100_000_000, now)).evaluations.single().reason)
    }

    @Test fun providerExceptionFailsClosed() {
        val broken = object : ExchangeProvider {
            override val providerId = "BROKEN"
            override fun capabilities(): ProviderCapabilities = throw IllegalStateException("offline")
            override fun quoteBtcToUsd(amountSats: Long, now: Instant): ExchangeQuote =
                error("must not request quote")
        }
        val decision = AshPayRouter(listOf(broken)).selectBestRoute(RoutingRequest(100_000_000, now))
        assertNull(decision.selectedQuote)
        assertEquals("CAPABILITIES_UNAVAILABLE", decision.evaluations.single().reason)
    }
}
