# ERIA Mockingbird — Kotlin + Cloudflare Worker

Dual implementation of a synthetic prompt generator.

## Safety
All output is labelled synthetic. It is never a real user message, approval, signature, or authorization. No execution, repository, payment, wallet, deployment, or external-communication capability is included.

## Kotlin
Pure Kotlin core, adaptable to an Android/ERIA module:
```bash
kotlinc kotlin/src/main/kotlin/eria/mockingbird/Mockingbird.kt -d mockingbird.jar
```

## Cloudflare Worker
```bash
cd worker
npm install
npx wrangler secret put MOCKINGBIRD_API_TOKEN
npx wrangler dev
```

Endpoints:
- `GET /health`
- `POST /mockingbird/generate`
- `POST /mockingbird/stress`

Generation requires `Authorization: Bearer <token>`.
