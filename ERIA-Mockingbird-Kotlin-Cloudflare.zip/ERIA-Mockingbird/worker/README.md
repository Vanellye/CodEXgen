# Worker usage

Set the API token:
```bash
npx wrangler secret put MOCKINGBIRD_API_TOKEN
```

Example:
```bash
curl -X POST http://localhost:8787/mockingbird/generate \
  -H "Authorization: Bearer $MOCKINGBIRD_API_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"task":"Design dimensional traversal entry points","context":["ERIA"],"constraints":["simulation first","preserve provenance"],"detail":"high"}'
```
