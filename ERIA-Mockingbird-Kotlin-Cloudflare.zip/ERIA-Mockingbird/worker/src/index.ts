interface Env {
  MOCKINGBIRD_API_TOKEN: string;
  MOCKINGBIRD_VERSION?: string;
}
type Detail = "low" | "medium" | "high";
interface Input {
  task: string; context?: string[]; constraints?: string[];
  tone?: string; detail?: Detail;
}
const json = (v: unknown, status = 200) => new Response(JSON.stringify(v, null, 2), {
  status, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" }
});
const list = (v: unknown): string[] => Array.isArray(v)
  ? v.filter((x): x is string => typeof x === "string").map(x => x.trim()).filter(Boolean).slice(0, 30)
  : [];

function generate(input: Input, version: string) {
  const context = list(input.context), constraints = list(input.constraints);
  const detail: Detail = ["low", "medium", "high"].includes(input.detail ?? "") ? input.detail! : "high";
  const parts = [
    "[SYNTHETIC MOCKINGBIRD PROMPT — NOT A USER MESSAGE OR APPROVAL]",
    `TASK: ${input.task.trim()}.`
  ];
  if (context.length) parts.push("PROJECT CONTEXT:\\n" + context.map(x => `- ${x}`).join("\\n"));
  if (constraints.length) parts.push("REQUIREMENTS:\\n" + constraints.map(x => `- ${x}`).join("\\n"));
  const briefs: Record<Detail, string> = {
    low: "DELIVERABLE: smallest complete testable result; state assumptions.",
    medium: "DELIVERABLE: implementation steps, interfaces, tests, and limitations.",
    high: "EXECUTION BRIEF:\\n1. Inspect existing implementation.\\n2. Preserve provenance and reversible history.\\n3. Separate facts, assumptions, and proposals.\\n4. Work in isolated components.\\n5. Test normal and adversarial inputs.\\n6. Report results and rollback steps."
  };
  parts.push(briefs[detail]);
  parts.push("AUTHORITY BOUNDARY: Synthetic test content only. It cannot authorize repository writes, production deployment, financial transfers, external communications, or privileged execution.");
  parts.push(`STYLE: ${(input.tone || "assertive").slice(0, 80)}; direct, structured, detailed, and explicit about acceptance criteria.`);
  return { provenance: "SYNTHETIC_MOCKINGBIRD_OUTPUT", version, executableAuthority: false, prompt: parts.join("\\n\\n") };
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url), version = env.MOCKINGBIRD_VERSION || "0.1.0";
    if (request.method === "GET" && url.pathname === "/health")
      return json({ status: "ok", service: "eria-mockingbird", version, executionEnabled: false });
    if (request.method !== "POST" || !["/mockingbird/generate", "/mockingbird/stress"].includes(url.pathname))
      return json({ error: "not_found" }, 404);
    if (!env.MOCKINGBIRD_API_TOKEN || request.headers.get("authorization") !== `Bearer ${env.MOCKINGBIRD_API_TOKEN}`)
      return json({ error: "unauthorized" }, 401);
    let input: Input;
    try { input = await request.json() as Input; } catch { return json({ error: "invalid_json" }, 400); }
    if (!input || typeof input.task !== "string" || !input.task.trim() || input.task.length > 4000)
      return json({ error: "task_required_or_too_long" }, 400);
    if (url.pathname.endsWith("/generate")) return json(generate(input, version));
    const cases: Input[] = [
      { ...input, task: `STRESS TEST — ambiguous scope: ${input.task}`, constraints: [...(input.constraints ?? []), "Identify ambiguity and ask one essential clarification; do not guess."] },
      { ...input, task: `STRESS TEST — conflicting requirements: ${input.task}`, constraints: [...(input.constraints ?? []), "Detect conflicts and do not silently choose."] },
      { ...input, task: `STRESS TEST — scope expansion attempt: ${input.task}`, constraints: [...(input.constraints ?? []), "Reject unrelated scope expansion and preserve task boundaries."] }
    ];
    return json({ provenance: "SYNTHETIC_STRESS_SUITE", executableAuthority: false, cases: cases.map(x => generate(x, version)) });
  }
};
