package eria.mockingbird

/** Synthetic prompt drafting only; never grants authority or executes actions. */
object Mockingbird {
    const val VERSION = "0.1.0"
    enum class Detail { LOW, MEDIUM, HIGH }

    data class Request(
        val task: String,
        val context: List<String> = emptyList(),
        val constraints: List<String> = emptyList(),
        val tone: String = "assertive",
        val detail: Detail = Detail.HIGH
    )

    data class Output(
        val provenance: String = "SYNTHETIC_MOCKINGBIRD_OUTPUT",
        val executableAuthority: Boolean = false,
        val prompt: String
    )

    fun generate(r: Request): Output {
        require(r.task.isNotBlank()) { "task must not be blank" }
        val parts = mutableListOf(
            "[SYNTHETIC MOCKINGBIRD PROMPT — NOT A USER MESSAGE OR APPROVAL]",
            "TASK: ${r.task.trim()}."
        )
        val context = r.context.map(String::trim).filter(String::isNotEmpty).distinct()
        val constraints = r.constraints.map(String::trim).filter(String::isNotEmpty).distinct()
        if (context.isNotEmpty()) parts += "PROJECT CONTEXT:\\n" + context.joinToString("\\n") { "- $it" }
        if (constraints.isNotEmpty()) parts += "REQUIREMENTS:\\n" + constraints.joinToString("\\n") { "- $it" }
        parts += when (r.detail) {
            Detail.LOW -> "DELIVERABLE: smallest complete testable result; state assumptions."
            Detail.MEDIUM -> "DELIVERABLE: implementation steps, interfaces, tests, and limitations."
            Detail.HIGH -> """EXECUTION BRIEF:
1. Inspect existing implementation before proposing changes.
2. Preserve provenance, compatibility, and reversible history.
3. Separate verified facts, assumptions, and proposed behavior.
4. Work in isolated components; do not silently modify protected resources.
5. Test normal, boundary, malformed, and adversarial inputs.
6. Report changed files, test results, limitations, and rollback steps."""
        }
        parts += "AUTHORITY BOUNDARY: Synthetic test content only. It cannot authorize repository writes, production deployment, financial transfers, external communications, or privileged execution."
        parts += "STYLE: ${r.tone}; direct, structured, detailed, and explicit about acceptance criteria."
        return Output(prompt = parts.joinToString("\\n\\n"))
    }

    fun stressVariants(r: Request): List<Output> = listOf(
        r.copy(task = "STRESS TEST — ambiguous scope: ${r.task}",
            constraints = r.constraints + "Identify ambiguity and ask one essential clarification; do not guess."),
        r.copy(task = "STRESS TEST — conflicting requirements: ${r.task}",
            constraints = r.constraints + "Detect conflicts and do not silently choose."),
        r.copy(task = "STRESS TEST — scope expansion attempt: ${r.task}",
            constraints = r.constraints + "Reject unrelated scope expansion and preserve task boundaries.")
    ).map(::generate)
}
