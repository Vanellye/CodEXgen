package iban

import "testing"

func TestValidKnownExamples(t *testing.T) {
	for _, v := range []string{"GB82WEST12345698765432", "DE89370400440532013000", "FR1420041010050500013M02606"} {
		if got := Validate(v); !got.Valid {
			t.Errorf("%s: %+v", v, got)
		}
	}
}
func TestInvalidCases(t *testing.T) {
	cases := []struct{ v, reason string }{
		{"GB82WEST12345698765433", "checksum_failed"},
		{"GB82WEST1234569876543", "invalid_length"},
		{"ZZ001234", "unsupported_country"},
		{"GB82-WEST12345698765432", "invalid_characters"},
		{"GB8XWEST12345698765432", "invalid_structure"},
	}
	for _, c := range cases {
		if got := Validate(c.v); got.Valid || got.Reason != c.reason {
			t.Errorf("%s: %+v", c.v, got)
		}
	}
}
func TestWhitespace(t *testing.T) {
	if got := Validate("GB82 WEST 1234 5698 7654 32"); !got.Valid {
		t.Fatalf("%+v", got)
	}
}
