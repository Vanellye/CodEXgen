package iban

import (
	"errors"
	"strings"
	"unicode"
)

var lengths = map[string]int{
	"AL": 28, "AD": 24, "AT": 20, "AZ": 28, "BH": 22, "BE": 16, "BA": 20,
	"BR": 29, "BG": 22, "CR": 22, "HR": 21, "CY": 28, "CZ": 24, "DK": 18,
	"DO": 28, "EE": 20, "FO": 18, "FI": 18, "FR": 27, "GE": 22, "DE": 22,
	"GI": 23, "GR": 27, "GL": 18, "GT": 28, "HU": 28, "IS": 26, "IE": 22,
	"IL": 23, "IT": 27, "JO": 30, "KZ": 20, "KW": 30, "LV": 21, "LB": 28,
	"LI": 21, "LT": 20, "LU": 20, "MK": 19, "MT": 31, "MR": 27, "MU": 30,
	"MC": 27, "MD": 24, "ME": 22, "NL": 18, "NO": 15, "PK": 24, "PS": 29,
	"PL": 28, "PT": 25, "QA": 29, "RO": 24, "SM": 27, "SA": 24, "RS": 22,
	"SK": 24, "SI": 19, "ES": 24, "SE": 24, "CH": 21, "TN": 24, "TR": 26,
	"AE": 23, "GB": 22, "VG": 24, "XK": 20,
}

type Result struct {
	Valid   bool   `json:"valid"`
	Country string `json:"country,omitempty"`
	Reason  string `json:"reason"`
	Masked  string `json:"masked,omitempty"`
}

func Validate(input string) Result {
	// Accept ordinary visual spaces only; reject all other non-ASCII or punctuation.
	s := strings.ReplaceAll(input, " ", "")
	s = strings.ToUpper(s)
	for _, r := range s {
		if r > unicode.MaxASCII || !(r >= 'A' && r <= 'Z' || r >= '0' && r <= '9') {
			return Result{Valid: false, Reason: "invalid_characters"}
		}
	}
	if len(s) < 4 {
		return Result{Valid: false, Reason: "too_short"}
	}
	country := s[:2]
	expected, ok := lengths[country]
	if !ok {
		return Result{Valid: false, Country: country, Reason: "unsupported_country"}
	}
	if len(s) != expected {
		return Result{Valid: false, Country: country, Reason: "invalid_length"}
	}
	if s[0] < 'A' || s[0] > 'Z' || s[1] < 'A' || s[1] > 'Z' ||
		s[2] < '0' || s[2] > '9' || s[3] < '0' || s[3] > '9' {
		return Result{Valid: false, Country: country, Reason: "invalid_structure"}
	}
	rearranged := s[4:] + s[:4]
	rem := 0
	for _, c := range rearranged {
		if c >= '0' && c <= '9' {
			rem = (rem*10 + int(c-'0')) % 97
			continue
		}
		v := int(c-'A') + 10
		rem = (rem*100 + v) % 97
	}
	if rem != 1 {
		return Result{Valid: false, Country: country, Reason: "checksum_failed"}
	}
	return Result{Valid: true, Country: country, Reason: "checksum_valid", Masked: mask(s)}
}

func mask(s string) string {
	if len(s) <= 8 {
		return s[:2] + "••••"
	}
	return s[:4] + strings.Repeat("•", len(s)-8) + s[len(s)-4:]
}

var ErrEmpty = errors.New("iban is required")
