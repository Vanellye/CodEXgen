module eria.finance

go 1.23
