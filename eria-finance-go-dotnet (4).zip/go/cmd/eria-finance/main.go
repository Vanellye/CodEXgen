package main

import (
	"encoding/json"
	"log"
	"net/http"
	"os"
	"strings"

	"eria.finance/internal/iban"
)

func main() {
	token := os.Getenv("ERIA_FINANCE_API_TOKEN")
	mux := http.NewServeMux()
	mux.HandleFunc("GET /health", func(w http.ResponseWriter, r *http.Request) {
		write(w, 200, map[string]any{"ok": true, "service": "eria-finance-go"})
	})
	mux.HandleFunc("POST /v1/iban/validate", func(w http.ResponseWriter, r *http.Request) {
		if token == "" {
			write(w, 503, map[string]string{"error": "service_not_configured"})
			return
		}
		if r.Header.Get("Authorization") != "Bearer "+token {
			write(w, 401, map[string]string{"error": "unauthorized"})
			return
		}
		var body struct {
			IBAN string `json:"iban"`
		}
		if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 4096)).Decode(&body); err != nil {
			write(w, 400, map[string]string{"error": "invalid_json"})
			return
		}
		if strings.TrimSpace(body.IBAN) == "" {
			write(w, 400, map[string]string{"error": "iban_required"})
			return
		}
		write(w, 200, iban.Validate(body.IBAN))
	})
	log.Fatal(http.ListenAndServe(":8788", mux))
}
func write(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}
