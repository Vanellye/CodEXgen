using Eria.Finance.Api;
using Xunit;

public class IbanValidatorTests
{
    [Theory]
    [InlineData("GB82WEST12345698765432")]
    [InlineData("DE89370400440532013000")]
    [InlineData("FR1420041010050500013M02606")]
    public void AcceptsValidExamples(string iban) => Assert.True(IbanValidator.Validate(iban).Valid);

    [Theory]
    [InlineData("GB82WEST12345698765433", "checksum_failed")]
    [InlineData("GB82WEST1234569876543", "invalid_length")]
    [InlineData("ZZ001234", "unsupported_country")]
    [InlineData("GB82-WEST12345698765432", "invalid_characters")]
    [InlineData("GB8XWEST12345698765432", "invalid_structure")]
    public void RejectsInvalidExamples(string iban, string reason)
    {
        var result = IbanValidator.Validate(iban);
        Assert.False(result.Valid);
        Assert.Equal(reason, result.Reason);
    }

    [Fact]
    public void AcceptsVisualSpaces() => Assert.True(IbanValidator.Validate("GB82 WEST 1234 5698 7654 32").Valid);
}
