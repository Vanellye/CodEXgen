using System.Text.Json.Serialization;
using Eria.Finance.Api;

var builder = WebApplication.CreateBuilder(args);
builder.Services.ConfigureHttpJsonOptions(o => o.SerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull);
var app = builder.Build();
app.MapGet("/health", () => Results.Ok(new { ok = true, service = "eria-finance-dotnet" }));
app.MapPost("/v1/iban/validate", (HttpContext context, ValidateRequest request) =>
{
    var token = app.Configuration["ERIA_FINANCE_API_TOKEN"];
    if (string.IsNullOrWhiteSpace(token)) return Results.StatusCode(StatusCodes.Status503ServiceUnavailable);
    if (!string.Equals(context.Request.Headers.Authorization.ToString(), $"Bearer {token}", StringComparison.Ordinal))
        return Results.Unauthorized();
    if (string.IsNullOrWhiteSpace(request.Iban))
        return Results.BadRequest(new { error = "iban_required" });
    return Results.Ok(IbanValidator.Validate(request.Iban));
});
app.Run();

public sealed record ValidateRequest(string Iban);
