using System.Text;

namespace Eria.Finance.Api;

public sealed record ValidationResult(bool Valid, string? Country, string Reason, string? Masked);

public static class IbanValidator
{
    // Conservative starter subset. Synchronize with the current SWIFT IBAN Registry
    // before production; do not infer country lengths for unknown codes.
    private static readonly IReadOnlyDictionary<string,int> Lengths = new Dictionary<string,int>(StringComparer.Ordinal) {
        ["AL"]=28,["AD"]=24,["AT"]=20,["AZ"]=28,["BH"]=22,["BE"]=16,["BA"]=20,["BR"]=29,
        ["BG"]=22,["CR"]=22,["HR"]=21,["CY"]=28,["CZ"]=24,["DK"]=18,["DO"]=28,["EE"]=20,
        ["FO"]=18,["FI"]=18,["FR"]=27,["GE"]=22,["DE"]=22,["GI"]=23,["GR"]=27,["GL"]=18,
        ["GT"]=28,["HU"]=28,["IS"]=26,["IE"]=22,["IL"]=23,["IT"]=27,["JO"]=30,["KZ"]=20,
        ["KW"]=30,["LV"]=21,["LB"]=28,["LI"]=21,["LT"]=20,["LU"]=20,["MK"]=19,["MT"]=31,
        ["MR"]=27,["MU"]=30,["MC"]=27,["MD"]=24,["ME"]=22,["NL"]=18,["NO"]=15,["PK"]=24,
        ["PS"]=29,["PL"]=28,["PT"]=25,["QA"]=29,["RO"]=24,["SM"]=27,["SA"]=24,["RS"]=22,
        ["SK"]=24,["SI"]=19,["ES"]=24,["SE"]=24,["CH"]=21,["TN"]=24,["TR"]=26,["AE"]=23,
        ["GB"]=22,["VG"]=24,["XK"]=20
    };

    public static ValidationResult Validate(string input)
    {
        var s = input.Replace(" ", "", StringComparison.Ordinal).ToUpperInvariant();
        foreach (var c in s)
            if (!(c is >= 'A' and <= 'Z' or >= '0' and <= '9'))
                return new(false, null, "invalid_characters", null);
        if (s.Length < 4) return new(false, null, "too_short", null);
        var country = s[..2];
        if (!Lengths.TryGetValue(country, out var expected)) return new(false, country, "unsupported_country", null);
        if (s.Length != expected) return new(false, country, "invalid_length", null);
        if (s[2] is < '0' or > '9' || s[3] is < '0' or > '9')
            return new(false, country, "invalid_structure", null);

        var rearranged = s[4..] + s[..4];
        var remainder = 0;
        foreach (var c in rearranged)
        {
            if (c is >= '0' and <= '9') remainder = (remainder * 10 + c - '0') % 97;
            else remainder = (remainder * 100 + c - 'A' + 10) % 97;
        }
        if (remainder != 1) return new(false, country, "checksum_failed", null);
        return new(true, country, "checksum_valid", Mask(s));
    }

    private static string Mask(string s) =>
        s.Length <= 8 ? s[..2] + "••••" : s[..4] + new string('•', s.Length - 8) + s[^4..];
}
