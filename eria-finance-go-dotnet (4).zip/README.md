# ERIA Finance Services — Go + .NET 10

Two parallel HTTP services with the same API contract:
- `POST /v1/iban/validate` — validates ASCII alphanumeric syntax, a supported country code, the configured total IBAN length, and MOD-97 checksum.
- `GET /health` — health check.

**Known limitation:** this starter does not yet enforce every country-specific BBAN subfield pattern (for example, bank-code positions and numeric/alphabetic segment rules). The country table is a subset, not the complete registry. Do not use this as a production payment-routing validator until the complete SWIFT country structures are imported and covered by tests.

**Scope limitation:** checksum/format validation does not establish that an account exists, belongs to the submitter, is accessible, or can receive a transfer. These services do not connect to banks, store IBANs, or move money.

## Registry data
The included country-length table is a deliberately conservative starter subset. SWIFT is the ISO 13616 Registration Authority; the latest registry located for this build is Release 103 (Sep 2026). Before production use, import all country lengths and BBAN patterns from that registry, and record its release, source URL, retrieval date, and digest. Unknown country codes are rejected rather than guessed. Source: https://www.swift.com/sites/default/files/files/iban-registry_4.pdf

## Go
```sh
cd go
go test ./...
export ERIA_FINANCE_API_TOKEN="$(openssl rand -hex 32)"
go run ./cmd/eria-finance
```
Default port 8788. The validation route requires `ERIA_FINANCE_API_TOKEN` as a bearer token; `/health` remains public.

## .NET 10
```sh
cd dotnet
dotnet test
export ERIA_FINANCE_API_TOKEN="$(openssl rand -hex 32)"
dotnet run --project src/Eria.Finance.Api
```
Default port 8080. The validation route requires `ERIA_FINANCE_API_TOKEN` as a bearer token; `/health` remains public.

## Request
```sh
curl -sS -X POST http://localhost:8788/v1/iban/validate \
  -H 'Content-Type: application/json' \
  -d '{"iban":"GB82WEST12345698765432"}'
```
The API returns only validation status and a masked identifier. It never echoes the full IBAN. Add `-H "Authorization: Bearer $ERIA_FINANCE_API_TOKEN"` to the request.

## Fly.io configuration (not deployed)
The `go/fly.toml` and `dotnet/fly.toml` files define separate apps and health checks. Replace each placeholder app name with a globally unique name. Authenticate locally with `fly auth login`; then, from each service directory, create the app with `fly launch --no-deploy` if it does not exist. Set a separate runtime token per app using `fly secrets set ERIA_FINANCE_API_TOKEN="$(openssl rand -hex 32)"`. Do not paste tokens into chat or commit them. Deployment is intentionally not automated by this package.
