# AshPay sandbox adapters

Two provider adapters wired to the AshPay `ExchangeProvider` contract.

## Important environment differences
- **Coinbase Advanced Trade:** `CoinbaseAdvancedTradeSandboxAdapter` is pinned to `https://api-sandbox.coinbase.com`. Its `probeAccounts()` calls the static sandbox Accounts endpoint. Coinbase's Advanced Trade sandbox is a static response simulator, not a matching engine or realistic funded venue. Quote values in this package are explicitly injected deterministic fixtures; they are NOT market prices.
- **Kraken Spot:** Kraken does not provide a public Spot trading sandbox. `KrakenSpotSandboxAdapter` is therefore a local deterministic simulator and makes NO network calls. Kraken's demo environment is for Futures, not Spot, so this package does not mislabel Futures demo as a BTC/USD Spot sandbox.
- No order submission, sale, transfer, withdrawal, or bank payout methods exist in these adapters.
- No API keys or credentials are accepted or stored.

## Run
Requires JDK 17+ and Gradle 8+:
```bash
gradle test
```

## Coinbase sandbox probe
The optional `probeAccounts()` call reaches only the hard-coded Coinbase Advanced Trade sandbox host. It does not place orders. The test suite uses a fake transport and does not contact the internet.

## Production boundary
These are sandbox/test adapters only. Before any live integration, independently implement and review production authentication, provider-specific account permissions, quote freshness, order preview, idempotency, reconciliation, jurisdiction/product eligibility, explicit user confirmation, and separately verified authorization.


## Integrated routing tests
This project includes the AshPay router plus both sandbox adapters in one Gradle project.
The integration tests compare deterministic mock quotes through the real routing engine.
They also verify fail-closed behavior because sandbox accounts are not production-verified
and neither sandbox adapter claims bank-payout capability.

Run:
```bash
gradle test
```

Expected routing fixture:
- Coinbase net fixture: USD 60,024
- Kraken net fixture: USD 60,039
- Router's simulated recommendation: Kraken local Spot simulator

This is **not** a live market quote, an exchange recommendation for real funds, or permission
to trade. Both sandbox providers are intentionally ineligible for real bank payout.
