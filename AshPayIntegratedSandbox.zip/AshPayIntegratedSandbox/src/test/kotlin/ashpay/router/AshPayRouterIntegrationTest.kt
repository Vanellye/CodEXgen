package ashpay.router

import ashpay.router.sandbox.CoinbaseAdvancedTradeSandboxAdapter
import ashpay.router.sandbox.KrakenSpotSandboxAdapter
import ashpay.router.sandbox.SandboxHttpResponse
import ashpay.router.sandbox.SandboxTransport
import java.math.BigDecimal
import java.time.Instant
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull

class AshPayRouterIntegrationTest {
    private val now = Instant.parse("2026-11-18T12:00:00Z")

    private fun quote(
        id: String,
        provider: String,
        amount: Long,
        gross: String,
        tradingFee: String,
        withdrawalFee: String
    ) = ExchangeQuote(
        id, provider, amount,
        BigDecimal(gross), BigDecimal(tradingFee), BigDecimal(withdrawalFee),
        BigDecimal.ZERO, 600, now.plusSeconds(60)
    )

    @Test fun routerComparesCoinbaseAndKrakenNetPayoutFixtures() {
        val coinbase = CoinbaseAdvancedTradeSandboxAdapter(
            SandboxTransport { SandboxHttpResponse(200, "{}") }
        ) { amount, _ ->
            quote("cb-fixture", "coinbase-advanced-sandbox", amount, "60040", "12", "4")
        }

        val kraken = KrakenSpotSandboxAdapter { amount, _ ->
            quote("kraken-fixture", "kraken-spot-local-simulator", amount, "60050", "8", "3")
        }

        val decision = AshPayRouter(listOf(coinbase, kraken))
            .selectBestRoute(RoutingRequest(100_000_000, now))

        // Coinbase fixture net = 60024; Kraken fixture net = 60039.
        // Selection is an internal simulation only; both providers report unverified/no bank payout.
        assertEquals("kraken-spot-local-simulator", decision.selectedProviderId)
        assertEquals(BigDecimal("60039"), decision.selectedQuote!!.netUsd())
        assertEquals(2, decision.evaluations.size)
    }

    @Test fun routerFailsClosedWhenOnlySandboxProvidersAreUnverifiedForPayout() {
        // Router requires provider capabilities to be eligible for bank payout and verified account.
        val coinbase = CoinbaseAdvancedTradeSandboxAdapter(
            SandboxTransport { SandboxHttpResponse(200, "{}") }
        ) { amount, _ ->
            quote("cb-fixture", "coinbase-advanced-sandbox", amount, "60040", "12", "4")
        }
        val decision = AshPayRouter(listOf(coinbase))
            .selectBestRoute(RoutingRequest(100_000_000, now))
        assertNull(decision.selectedQuote)
        assertEquals("ACCOUNT_NOT_VERIFIED", decision.evaluations.single().reason)
    }
}
