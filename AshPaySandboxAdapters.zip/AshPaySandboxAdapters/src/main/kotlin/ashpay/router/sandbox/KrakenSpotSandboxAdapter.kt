package ashpay.router.sandbox

import ashpay.router.*

/**
 * Local-only Kraken Spot simulator.
 * Kraken has no public Spot trading sandbox; this adapter deliberately performs no network I/O.
 * Do not confuse Kraken Futures demo with a Spot BTC/USD sandbox.
 */
class KrakenSpotSandboxAdapter(
    private val fixture: (Long, java.time.Instant) -> ExchangeQuote
) : ExchangeProvider {
    override val providerId: String = "kraken-spot-local-simulator"

    override fun capabilities() = ProviderCapabilities(
        supportsBtcUsd = true,
        supportsBankPayout = false,
        accountVerified = false,
        healthy = true
    )

    override fun quoteBtcToUsd(amountSats: Long, now: java.time.Instant): ExchangeQuote {
        require(amountSats > 0)
        val q = fixture(amountSats, now)
        require(q.providerId == providerId) { "Fixture providerId must be $providerId" }
        require(q.amountSats == amountSats) { "Fixture amount mismatch" }
        return q
    }
}
