package ashpay.router.sandbox

import ashpay.router.*
import java.net.URI
import java.net.http.HttpClient
import java.net.http.HttpRequest
import java.net.http.HttpResponse

/**
 * Coinbase Advanced Trade static sandbox adapter.
 * The only network operation is a read-only GET /accounts probe against the fixed sandbox host.
 * Quote data is an injected fixture because the static sandbox is not a price/matching simulator.
 */
class CoinbaseAdvancedTradeSandboxAdapter(
    private val transport: SandboxTransport,
    private val fixture: (Long, java.time.Instant) -> ExchangeQuote
) : ExchangeProvider {
    override val providerId: String = "coinbase-advanced-sandbox"

    override fun capabilities() = ProviderCapabilities(
        supportsBtcUsd = true,
        supportsBankPayout = false,
        accountVerified = false,
        healthy = true
    )

    override fun quoteBtcToUsd(amountSats: Long, now: java.time.Instant): ExchangeQuote {
        require(amountSats > 0)
        val q = fixture(amountSats, now)
        require(q.providerId == providerId) { "Fixture providerId must be $providerId" }
        require(q.amountSats == amountSats) { "Fixture amount mismatch" }
        return q
    }

    fun probeAccounts(): SandboxHttpResponse =
        transport.get("/api/v3/brokerage/accounts")

    companion object {
        fun httpTransport(): SandboxTransport {
            val client = HttpClient.newHttpClient()
            return SandboxTransport { path ->
                require(path.startsWith("/") && !path.startsWith("//")) { "Invalid sandbox path" }
                val uri = URI.create("https://api-sandbox.coinbase.com$path")
                require(uri.host == "api-sandbox.coinbase.com") { "Sandbox host mismatch" }
                val request = HttpRequest.newBuilder(uri).GET().build()
                val response = client.send(request, HttpResponse.BodyHandlers.ofString())
                SandboxHttpResponse(response.statusCode(), response.body())
            }
        }
    }
}
