package ashpay.router.sandbox

fun interface SandboxTransport {
    fun get(path: String): SandboxHttpResponse
}

data class SandboxHttpResponse(val statusCode: Int, val body: String)
