package ashpay.router

import java.math.BigDecimal
import java.time.Instant

data class ProviderCapabilities(
    val supportsBtcUsd: Boolean,
    val supportsBankPayout: Boolean,
    val accountVerified: Boolean,
    val healthy: Boolean
)

data class ExchangeQuote(
    val quoteId: String,
    val providerId: String,
    val amountSats: Long,
    val grossUsd: BigDecimal,
    val tradingFeeUsd: BigDecimal,
    val withdrawalFeeUsd: BigDecimal,
    val otherFeeUsd: BigDecimal,
    val estimatedSettlementSeconds: Long,
    val expiresAt: Instant
) {
    fun netUsd(): BigDecimal =
        grossUsd.subtract(tradingFeeUsd).subtract(withdrawalFeeUsd).subtract(otherFeeUsd)
}

interface ExchangeProvider {
    val providerId: String
    fun capabilities(): ProviderCapabilities
    fun quoteBtcToUsd(amountSats: Long, now: Instant): ExchangeQuote
}
