package ashpay.router.sandbox

import ashpay.router.*
import java.math.BigDecimal
import java.time.Instant
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertFailsWith
import kotlin.test.assertTrue

class SandboxAdaptersTest {
    private val now = Instant.parse("2026-11-18T12:00:00Z")
    private fun quote(provider: String, amount: Long, gross: String) = ExchangeQuote(
        "fixture-$provider", provider, amount, BigDecimal(gross),
        BigDecimal("5"), BigDecimal.ZERO, BigDecimal.ZERO,
        600, now.plusSeconds(60)
    )

    @Test fun coinbaseIsPinnedToStaticSandboxAndOnlyProbesAccounts() {
        var requestedPath = ""
        val adapter = CoinbaseAdvancedTradeSandboxAdapter(
            SandboxTransport { path ->
                requestedPath = path
                SandboxHttpResponse(200, """{"accounts":[]}""")
            }
        ) { amount, _ -> quote("coinbase-advanced-sandbox", amount, "60000") }

        val response = adapter.probeAccounts()
        assertEquals(200, response.statusCode)
        assertEquals("/api/v3/brokerage/accounts", requestedPath)
        assertFalse(adapter.capabilities().accountVerified)
        assertFalse(adapter.capabilities().supportsBankPayout)
    }

    @Test fun coinbaseQuoteIsExplicitFixtureNotLivePrice() {
        val adapter = CoinbaseAdvancedTradeSandboxAdapter(
            SandboxTransport { SandboxHttpResponse(200, "{}") }
        ) { amount, _ -> quote("coinbase-advanced-sandbox", amount, "60000") }
        assertEquals(BigDecimal("59995"),
            adapter.quoteBtcToUsd(100_000_000, now).netUsd())
    }

    @Test fun krakenSpotAdapterIsLocalOnlyAndUnverified() {
        var invoked = false
        val adapter = KrakenSpotSandboxAdapter { amount, _ ->
            invoked = true
            quote("kraken-spot-local-simulator", amount, "60020")
        }
        val q = adapter.quoteBtcToUsd(100_000_000, now)
        assertTrue(invoked)
        assertEquals(BigDecimal("60015"), q.netUsd())
        assertFalse(adapter.capabilities().accountVerified)
        assertFalse(adapter.capabilities().supportsBankPayout)
    }

    @Test fun bothAdaptersRejectWrongFixtureProviderIdentity() {
        val cb = CoinbaseAdvancedTradeSandboxAdapter(
            SandboxTransport { SandboxHttpResponse(200, "{}") }
        ) { amount, _ -> quote("wrong-provider", amount, "60000") }
        assertFailsWith<IllegalArgumentException> { cb.quoteBtcToUsd(1, now) }

        val kraken = KrakenSpotSandboxAdapter { amount, _ ->
            quote("wrong-provider", amount, "60000")
        }
        assertFailsWith<IllegalArgumentException> { kraken.quoteBtcToUsd(1, now) }
    }

    @Test fun coinbaseRejectsAmountMismatch() {
        val cb = CoinbaseAdvancedTradeSandboxAdapter(
            SandboxTransport { SandboxHttpResponse(200, "{}") }
        ) { _, _ -> quote("coinbase-advanced-sandbox", 2, "60000") }
        assertFailsWith<IllegalArgumentException> { cb.quoteBtcToUsd(1, now) }
    }
}
