plugins {
    kotlin("jvm") version "2.1.20"
}
repositories { mavenCentral() }
dependencies {
    testImplementation(kotlin("test"))
    testImplementation("org.junit.jupiter:junit-jupiter:5.11.4")
}
tasks.test { useJUnitPlatform() }
kotlin { jvmToolchain(17) }
