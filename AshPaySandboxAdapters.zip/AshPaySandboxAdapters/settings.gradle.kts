rootProject.name = "AshPaySandboxAdapters"
