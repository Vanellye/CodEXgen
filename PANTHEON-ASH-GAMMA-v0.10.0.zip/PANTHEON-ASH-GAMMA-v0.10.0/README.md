# PANTHEON / ASH / GAMMA v0.10.0

C++17 Termux runtime. Adds CMake + OpenSSL Ed25519-signed, expiring, scope-bound,
bounded multi-use PONS authorization tokens. Each actual `gamma run` still requires
a fresh interactive human confirmation.

## Build (Termux)

```bash
pkg install clang cmake make openssl -y
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build
./build/pantheon --version
```

## Create an authorization keypair

```bash
mkdir -p keys
./build/pantheon pons keygen keys/pons-private.pem keys/pons-public.pem
chmod 600 keys/pons-private.pem
```

Keep `pons-private.pem` private/off-device where practical. Distribute only the public
key to runtime verifiers. Do not commit private keys or tokens to Git.

## Issue a bounded multi-use token

The token is bound to one exact command and one exact registered package. Expiry is
Unix time in seconds; max uses is bounded to 1..1,000,000. Example: expiry 30 minutes
from now, maximum 3 launches:

```bash
EXPIRY=$(( $(date +%s) + 1800 ))
./build/pantheon pons issue keys/pons-private.pem data/nc-approval.pons nc netcat-openbsd "$EXPIRY" 3
```

Issuance is an administrative signing action: protect access to the private key and
review command/package/scope/expiry/use count before issuing.

## Run with token + per-run human approval

```bash
./build/pantheon gamma run nc --package netcat-openbsd --token data/nc-approval.pons --public-key keys/pons-public.pem -- -h
```

Before launch, Pantheon checks the Ed25519 signature, expiry, command/package scope,
remaining use count, installed package, and executable. It then displays the action
and requires the exact interactive phrase:

```text
PONS APPROVE nc
```

A token allows up to its signed maximum number of separately confirmed launches.
The use counter is protected against ordinary concurrent use with a file lock.

## Other Gamma commands

```bash
./build/pantheon gamma commands
./build/pantheon gamma resolve nc
./build/pantheon gamma discover
./build/pantheon gamma prepare nc netcat-openbsd
./build/pantheon gamma ledger
```

## Security limits

- Ed25519 signatures authenticate the token contents; expiry and exact command/package
  scope are signed.
- Each invocation still requires a human confirmation. The multi-use count is a
  bounded allowance, not silent/background consent.
- The use counter is stored in `data/pons-token-uses.tsv`. It is local, not hardware
  protected or rollback-resistant. Restoring an old copy of that file can reset counts.
- The local event ledger is editable and not externally anchored.
- This is not independent security review, hardware-backed signing, secure boot,
  remote revocation, or a production authorization service.
- `gamma run` launches ordinary local programs; those programs may modify files,
  access networks, or change device state. No shell is used, but program behavior is
  still potentially destructive.
- This does not authorize or implement bank, Bitcoin, Ethereum, or other financial
  transfers.
