# ơɣ language — v0.7

The `.og` registry is now parsed at runtime. Each declaration has this form:

```text
map "nc" => package("busybox") from repo("main");
```

Supported runtime operations:
- `gamma commands [file]`: list parsed command tokens.
- `gamma packages [file]`: list unique package candidates.
- `gamma resolve <token> [file]`: show every package candidate and local installed status.
- `gamma inspect <token> [file]`: same inspection plus an audit-ledger event.
- `gamma discover [file]`: count registry packages found in the local dpkg database.
- `gamma ledger`: read the local append-only-by-convention TSV event log.

The runtime never installs packages or executes a mapped command. Ambiguous aliases are shown as multiple candidates, not guessed.
