# PONS authorization security model — v0.10.0

## Cryptographic token
Tokens use Ed25519 through OpenSSL EVP. The signed canonical payload contains:
version, exact command, exact package, Unix expiry, and maximum use count. Verification
uses a public PEM key. Token fields cannot be edited without invalidating the signature.

## Use policy
Tokens are command/package scoped, expire at a fixed timestamp, and have a signed
bounded use count (1..1,000,000). A successful invocation consumes one use under an
advisory file lock. Every invocation separately requires a live interactive terminal
and exact `PONS APPROVE <command>` confirmation. Token possession alone is insufficient.

## Key handling
Private key material should be generated and retained on a controlled device, protected
with restrictive filesystem permissions, excluded from source control, and backed up
securely. The verifier needs only the public key. This implementation does not provide
hardware key storage or encrypted private-key PEM support.

## Important limitations
The usage database and event ledger are local files. File locking protects normal
concurrent launches, but a privileged user can edit/restore the database; the counter
is not rollback-resistant. There is no remote revocation, trusted clock, hardware
monotonic counter, independent witness, or external ledger anchoring. System clock
rollback can affect expiry. OpenSSL/OS integrity is assumed. This is a development
authorization layer, not a production-grade financial signing boundary.
