# DOG → commitment → GOD governance boundary

- **DOG (deauthorization):** revoke or reject stale, missing, invalid, or out-of-scope capabilities. Default is deny.
- **Commitment processor:** create a reviewable change proposal containing repository, base ref, target branch, operation, exact file list, source digests, and proposed output digest.
- **GOD (governance decision):** accept only an independently verifiable, identity-authenticated, signed, scoped, unexpired, non-replayed approval plus explicit human review.

The imported PONS packages are development/test references, not a production authority. They are not connected to the GitHub write adapter. Their allow-listed repository names do not match `vanellyetm-ux/Ash`; the issuer uses `DEVELOPMENT_ONLY` while the separate verifier uses `TEST_ONLY`. No PONS approval was minted. The dashboard reports authorization as unavailable and writes remain disabled in automation.

Never treat a natural-language request, typed approver label, environment variable, demo signature, or authorization boolean passed through the Pantheon bridge as cryptographic authorization.
