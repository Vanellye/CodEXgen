# CAT / JAW / RAT / MOUSE language workstreams

These names were requested as language/runtime workstreams. The imported ZIPs do not contain implementations of these four languages, so this is a design boundary, not a claim that compilers exist.

| Workstream | Proposed responsibility | Current evidence |
|---|---|---|
| CAT | Lexer, tokens, source locations, diagnostics | Not present in imports |
| JAW | Grammar, parser, AST, type checking | Not present in imports |
| RAT | Deterministic interpreter/runtime and sandbox | Not present in imports |
| MOUSE | Developer tools, editor protocol, dashboard integration | Dashboard shell only; no language tooling imported |

Suggested contract: each compiler stage consumes immutable source plus a provenance manifest and emits a typed artifact with a digest. No language stage receives repository-write or deployment authority.

Recommended sequence: define syntax and versioning; write lexer/parser specs; add golden tests; add sandboxed interpreter; then bind editor/dashboard tooling. Keep compiler/runtime work separate from PONS authorization.
