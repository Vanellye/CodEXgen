const items=[
['Mockingbird','Kotlin + Cloudflare Worker','Synthetic prompt drafts only'],
['Pantheon ctypes bridge','Native NEW/FaCADE adapter','Needs external C99 sources'],
['Recovery Manager','Python quarantine/restore','Purge is blocked'],
['PONS Issuer','Ed25519 development issuer','Not production authorization'],
['PONS Signature Verifier','Ed25519 test verifier','TEST_ONLY demo scope'],
['Finance Go + .NET','IBAN syntax and MOD-97','No banking or transfer functions'],
['Forge Agent','Go plan-only agent','Repository writes disabled'],
['AIR GenUI renderer','Vendored static runtime bundle','Manifest verified; not wired']
];
document.getElementById('systems').innerHTML=items.map(([n,d,s])=>`<article><div><span>${n}</span><small>${d}</small></div><span class="chip neutral">${s}</span></article>`).join('');