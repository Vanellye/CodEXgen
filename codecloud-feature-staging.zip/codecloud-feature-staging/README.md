# îïịþŧţ Codecloud — feature/codecloud staging tree

This is a reviewable monorepo staging layout assembled from the uploaded ERIA/PONS ZIP packages. It is not a production release.

Open `dashboard/index.html` in a browser for the status console. Start with `docs/INTEGRATION.md`, `docs/GOVERNANCE.md`, and `provenance/zip-archives.json` before modifying components.

**Safety posture:** isolated branch only; `main` preserved; no deployment; PONS approval not established; repository commits remain gated. Several packages explicitly provide proposal-only or test-only behavior.
