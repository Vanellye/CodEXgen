# Repository Data Intelligence — Main Branch Directory Index

## Purpose
This archive provides a provenance-preserving index of repository paths and Git object IDs from the `main` branch snapshots.

## Included repositories
- `Vanellye/CodEXgen`
- `Vanellye/CodEXgen-2`
- `Vanellye/Ash`

## Files
- `repository_inventory.json` — machine-readable repository metadata and full indexed entries.
- `repository_inventory.csv` — one row per indexed file or directory, including path, object type, Git SHA, and size where available.
- `directory_tree.txt` — readable hierarchical listing.
- `INTELLIGENCE_INDEX.md` — high-level topical index and governance notes.
- `SHA256SUMS.txt` — checksums for the generated index files.

## Provenance and safety
The inventory records the `main` commit SHA, root tree SHA, and each returned Git blob/tree SHA. Git object SHAs are provenance identifiers, not SHA-256 checksums of the archive.
This operation was read-only. It did not modify any repository, branch, file, tag, pull request, or CI setting.
The archive is not an endorsement that every indexed implementation is correct, current, safe, or authorized for execution.

## Important scope note
This ZIP is an index bundle. It does not contain every repository source file or historical Git object. Use the recorded repository, branch, and path to retrieve a source file at the indexed revision.
