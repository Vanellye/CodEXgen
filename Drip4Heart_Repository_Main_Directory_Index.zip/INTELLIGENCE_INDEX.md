# Intelligence Index

## Repository-level themes observed from indexed paths

### Vanellye/CodEXgen
- Android/Kotlin application surface: `app/`, `compose/`, Gradle build files.
- Data and transmission contracts: `app/src/main/java/com/vanellye/eria/contracts/`.
- Pantheon runtime gate and native C modules: `pantheon/`.
- Governance, ethics, operating protocol, provenance, and architecture documents: `docs/`.
- Write-boundary controls and validation tooling: `security/red-write-only/`.
- CI and branch workflow definitions: `.github/workflows/`.
- Legacy or experimental Python and hypothetical files remain present in the indexed main snapshot; inventory alone does not imply they are active or approved.

### Vanellye/CodEXgen-2
- Focused write-boundary security policy and test-vector structure: `security/red-write-only/`.
- GitHub workflow boundary definition: `.github/workflows/`.
- The repository is private; inventory metadata is based on the connected authorized read.

### Vanellye/Ash
- Ethics attachment and approval-record schema: `governance/ethics/`.
- Human-approval and write-boundary workflow definitions: `.github/workflows/`.
- Shared write-boundary policy, test vectors, tests, and tools: `security/red-write-only/`.

## Cross-repository observations
- The same write-boundary workflow file SHA appears across all three repositories.
- The same `security/red-write-only` policy, test-vector, test, and tool object SHAs appear across the three repositories, indicating identical Git objects for those indexed paths at these snapshots.
- `Ash` includes explicit ethics and approval-record artifacts in addition to the shared write-boundary materials.
- `CodEXgen` contains the broadest indexed surface among these three snapshots.

## Governance invariants to preserve
1. Keep `main` and historical refs untouched during inventory and review.
2. Preserve source provenance and historical revisions; distinguish original, recovered, reconstructed, and generated material.
3. Treat missing, invalid, stale, revoked, or unverifiable independent approval as DENY/HOLD.
4. Require a real independent reviewer artifact with verified identity, signature, scope, freshness, and revocation status before privileged writes or execution.
5. Do not represent an index as a code audit, test pass, security certification, or authorization.
