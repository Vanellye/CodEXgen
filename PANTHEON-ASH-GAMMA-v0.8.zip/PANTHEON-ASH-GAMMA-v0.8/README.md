# PANTHEON / ASH / Ɣ — v0.8

## ơɣ dependency preparation

v0.8 changes the registry flow from inspection-only to install-if-missing:

- `gamma prepare <command>` installs the package when the command has exactly one registered package candidate.
- `gamma prepare <command> <package>` explicitly selects one candidate for an ambiguous command.
- If the selected package is already installed, preparation skips installation.
- After installation, the runtime verifies the package appears in the local dpkg database.
- **The mapped command is never executed.** Installation and execution remain separate operations.

## Termux commands

```sh
pkg install clang make grep coreutils unzip -y
unzip PANTHEON-ASH-GAMMA-v0.8.zip
cd PANTHEON-ASH-GAMMA-v0.8
make
make check

./pantheon gamma commands
./pantheon gamma discover
./pantheon gamma resolve nc
./pantheon gamma prepare gh
./pantheon gamma prepare nc busybox
./pantheon gamma ledger
```

`nc` has multiple candidates, so `prepare nc` intentionally refuses to guess. Choose a registered candidate, for example `prepare nc busybox`.

## Safety and provenance

- Package installation uses `pkg install -y` via direct process invocation (no shell command interpolation).
- Package names must match a registered candidate and pass a strict token allowlist.
- The installer is invoked only by the explicit `prepare` subcommand.
- No mapped executable is launched after installation.
- Local TSV ledger records install requests, failures, and verified preparation.
- The ledger is local and tamperable; it is not a cryptographically anchored audit service.
- The `payment_execution = UNLOCKED` policy value remains a declaration only; no banking provider or transfer capability is present.
