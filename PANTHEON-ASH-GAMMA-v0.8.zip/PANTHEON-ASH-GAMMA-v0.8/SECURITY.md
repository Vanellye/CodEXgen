# Security boundary — v0.8

`gamma prepare` may install a package from the configured Termux package sources after an explicit user-run command. It never executes the mapped command. It validates package candidates against the parsed registry and refuses ambiguous aliases unless a candidate is explicitly selected. Package installation can modify the device and consume storage/network data; review the package name before running `prepare`. Ledger entries are local and tamperable. PONS cryptographic authorization and independent audit anchoring are not yet implemented.
