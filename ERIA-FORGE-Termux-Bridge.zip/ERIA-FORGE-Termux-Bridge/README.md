# ERIA FORGE — Termux Local-Copy Bridge

Offline copy/paste bridge. Local Termux admin is authoritative; PONS approval is mandatory; GitHub is read-only.

## Install
```sh
pkg update
pkg install python git unzip -y
mkdir -p ~/eria && cd ~/eria
unzip ~/storage/downloads/ERIA-FORGE-Termux-Bridge.zip
cd ERIA-FORGE-Termux-Bridge
chmod +x install.sh
./install.sh
```

## Initialize
```sh
eria-forge init --repo "$HOME/path/to/your/repository"
```
Creates `~/.config/eria-forge/pons.key` with owner-only permissions. Never share or upload it.

## Copy/paste workflow
Save a ChatGPT proposal as `request.json` in the current Termux directory, then:
```sh
eria-forge import request.json
eria-forge review
eria-forge approve
eria-forge verify
eria-forge execute
```
`approve` requires typing `APPROVE-LOCAL-INSPECT` locally. Approval is HMAC-signed and bound to the request SHA-256, repository, Git HEAD, and working-tree fingerprint. Any change invalidates approval.

## Request format
```json
{
  "protocol": "PONS-LOCAL-1",
  "source": "chatgpt",
  "target": "termux-forge",
  "operation": "inspect",
  "repository": "/data/data/com.termux/files/home/path/to/repo",
  "base": "main",
  "target_branch": "feature/codecloud",
  "requires_local_approval": true,
  "requires_pons": true,
  "execute": false
}
```

## Safety limits
- Only `inspect` is accepted. It runs read-only Git status, diff checks, and recent log.
- No shell command execution from ChatGPT input.
- No branch creation/switching, commit, push, file mutation, GitHub API, or settings changes.
- GitHub stays read-only. This package does not grant GitHub permissions.
- This bootstrap HMAC gate is local to this package; it does not prove integration with any separate existing PONS deployment.
- No network listener; no automatic ChatGPT-to-phone connection.
