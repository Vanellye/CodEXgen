#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
PREFIX="${PREFIX:-/data/data/com.termux/files/usr}"
mkdir -p "$PREFIX/bin"
install -m 755 "$HERE/bin/eria-forge" "$PREFIX/bin/eria-forge"
install -m 644 "$HERE/bin/forge_bridge.py" "$PREFIX/bin/forge_bridge.py"
echo 'Installed. Run: eria-forge init --repo "$HOME/path/to/repository"'
