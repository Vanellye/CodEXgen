# PANTHEON / ASH / Ɣ — v0.7

## What's genuinely new
1. Runtime `.og` interpreter for command/package mappings (no longer compile-time-only).
2. Read-only discovery against the local Termux dpkg package database.
3. Candidate resolution that reports ambiguity rather than silently choosing a package.
4. Local TSV provenance events for discovery, resolution, and inspection.
5. Explicit non-execution boundary: this version does not install packages or run mapped commands.

## Termux
```sh
pkg install clang make grep coreutils -y
unzip PANTHEON-ASH-GAMMA-v0.7.zip
cd PANTHEON-ASH-GAMMA-v0.7
make
make check
./pantheon gamma commands
./pantheon gamma discover
./pantheon gamma resolve nc
./pantheon gamma inspect ex
./pantheon gamma ledger
```

## Trust and limits
- The catalogue is based on the previously supplied package suggestions; it is not a live repository index.
- `installed=yes` means the package name appears in the local dpkg database.
- `executable_on_PATH` checks whether the command token resolves on PATH; it does not prove which package owns it.
- Ledger is local and tamperable; it is not cryptographically anchored or an independent audit service.
- PONS approval, human review, ASH connectivity, banking rails, and payment execution are not implemented by this release.
- `payment_execution = UNLOCKED` remains a policy/configuration declaration only; it does not authorize or enable a real transfer.
