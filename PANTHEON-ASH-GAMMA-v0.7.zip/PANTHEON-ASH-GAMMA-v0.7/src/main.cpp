#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <map>
#include <regex>
#include <set>
#include <sstream>
#include <string>
#include <vector>

namespace fs = std::filesystem;
struct Mapping { std::string command, package, repo; };

static std::string trim(std::string s) {
    auto a=s.find_first_not_of(" \t\r\n");
    if(a==std::string::npos) return "";
    auto b=s.find_last_not_of(" \t\r\n");
    return s.substr(a,b-a+1);
}
static std::string timestamp() {
    std::time_t t=std::time(nullptr); char b[32]{};
    std::strftime(b,sizeof(b),"%Y-%m-%dT%H:%M:%SZ",std::gmtime(&t)); return b;
}
static void ledger(const std::string& event, const std::string& detail) {
    std::ofstream f("data/gamma-ledger.tsv", std::ios::app);
    f << timestamp() << "\t" << event << "\t" << detail << "\n";
}
static bool safe_token(const std::string& s) {
    return !s.empty() && std::regex_match(s, std::regex("[A-Za-z0-9_+.-]+"));
}
static std::vector<Mapping> load_registry(const std::string& path) {
    std::ifstream f(path);
    std::vector<Mapping> out;
    if(!f) return out;
    std::regex rx(R"rx(map\s+"([A-Za-z0-9_\[\].+-]+)"\s*=>\s*package\("([A-Za-z0-9_+.-]+)"\)\s+from\s+repo\("([A-Za-z0-9_-]+)"\)\s*;)rx");
    std::string line; std::smatch m;
    while(std::getline(f,line)) if(std::regex_search(line,m,rx))
        out.push_back({m[1],m[2],m[3]});
    return out;
}
static std::set<std::string> installed_packages() {
    std::set<std::string> out;
    // Fixed, read-only package query; no user-supplied text enters the shell.
    FILE* p=popen("dpkg-query -W -f='${binary:Package}\\n' 2>/dev/null","r");
    if(!p) return out;
    char buf[512];
    while(fgets(buf,sizeof(buf),p)) { auto s=trim(buf); if(!s.empty()) out.insert(s); }
    pclose(p); return out;
}
static bool executable_exists(const std::string& name) {
    if(!safe_token(name)) return false;
    std::string cmd = "command -v " + name + " >/dev/null 2>&1";
    return std::system(cmd.c_str()) == 0;
}
static void help() {
    std::cout <<
    "PANTHEON / ASH / GAMMA v0.7\n"
    "  ./pantheon gamma commands [file]\n"
    "  ./pantheon gamma packages [file]\n"
    "  ./pantheon gamma resolve <command> [file]\n"
    "  ./pantheon gamma discover [file]\n"
    "  ./pantheon gamma inspect <command> [file]\n"
    "  ./pantheon gamma ledger\n"
    "\nRead-only interpreter: parses .og mappings and inspects local Termux state.\n";
}
int main(int argc,char** argv) {
    if(argc<2) { help(); return 0; }
    std::string area=argv[1];
    if(area=="--version" || area=="version") { std::cout<<"0.7.0\n"; return 0; }
    if(area!="gamma" || argc<3) { help(); return area=="gamma"?1:0; }
    std::string action=argv[2];
    if(action=="ledger") {
        std::ifstream f("data/gamma-ledger.tsv"); std::string line;
        if(!f) { std::cout<<"No ledger entries yet.\n"; return 0; }
        while(std::getline(f,line)) std::cout<<line<<"\n";
        return 0;
    }
    int argi=3;
    std::string target;
    if(action=="resolve" || action=="inspect") {
        if(argc<=argi) { std::cerr<<"Missing command token.\n"; return 2; }
        target=argv[argi++];
        if(!safe_token(target)) { std::cerr<<"Invalid command token.\n"; return 2; }
    }
    std::string path=(argc>argi)?argv[argi]:"language/termux.og";
    auto maps=load_registry(path);
    if(maps.empty()) { std::cerr<<"No mappings parsed from "<<path<<". Check .og syntax/path.\n"; return 3; }
    auto installed=installed_packages();
    if(action=="commands") {
        std::set<std::string> s; for(auto&m:maps)s.insert(m.command);
        for(auto&x:s) std::cout<<x<<"\n";
        std::cout<<"Parsed "<<maps.size()<<" mappings from "<<path<<"\n";
    } else if(action=="packages") {
        std::set<std::string> s; for(auto&m:maps)s.insert(m.package);
        for(auto&x:s) std::cout<<x<<"\n";
        std::cout<<"Unique packages: "<<s.size()<<"\n";
    } else if(action=="discover") {
        size_t found=0;
        for(auto&m:maps) if(installed.count(m.package)) ++found;
        std::cout<<"Registry mappings: "<<maps.size()<<"\n"
                 <<"Installed package matches: "<<found<<"\n"
                 <<"Discovery is read-only; it does not install or execute anything.\n";
        ledger("DISCOVER",std::to_string(found)+"/"+std::to_string(maps.size()));
    } else if(action=="resolve" || action=="inspect") {
        std::vector<Mapping> hits;
        for(auto&m:maps) if(m.command==target) hits.push_back(m);
        if(hits.empty()) { std::cout<<"No mapping for command: "<<target<<"\n"; return 4; }
        std::cout<<"Command: "<<target<<"\n";
        for(auto&m:hits) {
            bool pkg=installed.count(m.package)>0;
            bool bin=executable_exists(target);
            std::cout<<"- package="<<m.package<<" repo="<<m.repo
                     <<" installed="<<(pkg?"yes":"no")
                     <<" executable_on_PATH="<<(bin?"yes":"no")<<"\n";
        }
        if(hits.size()>1) std::cout<<"AMBIGUOUS: multiple package candidates; choose explicitly before any future action.\n";
        if(action=="inspect") ledger("INSPECT",target+" candidates="+std::to_string(hits.size()));
        else ledger("RESOLVE",target+" candidates="+std::to_string(hits.size()));
    } else { help(); return 2; }
    return 0;
}
