# Ɣ Semantic & Bio-Optic / Electromagnetic Engine — Seed 0.3

Independent language prototype. No ERIA dependency.

## Included
- Lexer/parser for `.gamma` source
- Typed semantic graph with relation validation
- Evidence lineage and provenance references
- Multi-valued assessment evaluator
- Deterministic JSON Ɣ-IR exporter
- Passive sensor / transmitter / receiver model declarations
- Synthetic bioluminescence and electromagnetic simulation fixtures
- Unit tests

## Safe operating profile
This release is a software simulator and passive-data schema only. It does not drive physical transmitters, antennas, lasers, UV sources, RF amplifiers, ionizing-radiation sources, implanted devices, or biological stimulation equipment. It does not calculate biological exposure doses or optimize tissue stimulation. Transmit/receive examples are synthetic and bounded to abstract signal values.

Future physical measurement work must use appropriate certified equipment, qualified supervision, and applicable radio, optical, electrical, EMC, radiation, and biosafety requirements. This package is not a medical device.

## Run in Termux or desktop Python 3.10+
```bash
python gamma/cli.py check examples/bioluminescence.gamma
python gamma/cli.py graph examples/bioluminescence.gamma
python gamma/cli.py build-ir examples/bioluminescence.gamma --out build/bioluminescence.ir.json
python gamma/cli.py simulate examples/bioluminescence.gamma
python -m unittest discover -s tests -v
```

## Example
```gamma
language Ɣ
domain BioOptic

concept Organism
concept PhotonSignal
concept Photodetector

sensor PassivePhotonSensor
  modality optical
  role receive
  input simulated
  quantity photon_count_rate
  unit count_per_second
end

evidence E_light
  origin "synthetic_fixture"
  method "simulation"
  observation "photon_count_rate=120"
end

claim photon_flux is 120 supported_by E_light
assess photon_flux as uncertain
```

The parser deliberately implements a small documented subset; unknown constructs fail closed instead of being silently reinterpreted.
