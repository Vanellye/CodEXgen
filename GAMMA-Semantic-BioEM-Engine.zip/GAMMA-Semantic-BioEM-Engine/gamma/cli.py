#!/usr/bin/env python3
import argparse, json, sys
from pathlib import Path
from core import parse, validate, to_ir, simulate, GammaError

def load(path):
    p = parse(Path(path).read_text(encoding="utf-8"))
    errors = validate(p)
    if errors: raise GammaError("\n".join(errors))
    return p

def main():
    ap = argparse.ArgumentParser(prog="gamma")
    sub = ap.add_subparsers(dest="cmd", required=True)
    for cmd in ("check", "graph", "simulate"):
        x = sub.add_parser(cmd); x.add_argument("source")
    x = sub.add_parser("build-ir"); x.add_argument("source"); x.add_argument("--out", required=True)
    args = ap.parse_args()
    try:
        p = load(args.source)
        if args.cmd == "check":
            print(f"Ɣ check passed: {args.source}")
        elif args.cmd == "graph":
            print(json.dumps({"nodes": to_ir(p)["nodes"], "edges": to_ir(p)["edges"]}, ensure_ascii=False, indent=2))
        elif args.cmd == "simulate":
            print(json.dumps(simulate(p), ensure_ascii=False, indent=2))
        elif args.cmd == "build-ir":
            out = Path(args.out); out.parent.mkdir(parents=True, exist_ok=True)
            out.write_text(json.dumps(to_ir(p), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            print(f"Ɣ-IR written: {out}")
    except (OSError, GammaError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr); return 1
    return 0
if __name__ == "__main__":
    raise SystemExit(main())
