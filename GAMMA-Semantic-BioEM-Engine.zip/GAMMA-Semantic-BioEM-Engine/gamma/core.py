"""Ɣ v0.3: lexer, parser, typed graph, evidence lineage and evaluator.
No I/O beyond source reading/IR output in CLI; no hardware control."""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Any
import json, re

STATES = {"affirmed", "denied", "uncertain", "unknown", "conflicted", "not_applicable"}
BLOCK_TYPES = {"sensor", "transmitter", "receiver", "evidence"}

@dataclass
class Decl:
    kind: str
    name: str
    attrs: dict[str, Any] = field(default_factory=dict)
    line: int = 0

@dataclass
class Relation:
    subject: str
    predicate: str
    object: str
    line: int = 0

@dataclass
class Claim:
    name: str
    value: Any
    evidence_id: str
    line: int = 0

@dataclass
class Assessment:
    claim: str
    state: str
    line: int = 0

@dataclass
class Program:
    domain: str | None = None
    declarations: list[Decl] = field(default_factory=list)
    relations: list[Relation] = field(default_factory=list)
    claims: list[Claim] = field(default_factory=list)
    assessments: list[Assessment] = field(default_factory=list)

class GammaError(Exception):
    pass

def parse_atom(raw: str) -> Any:
    raw = raw.strip()
    if len(raw) >= 2 and raw[0] == raw[-1] == '"':
        return bytes(raw[1:-1], "utf-8").decode("unicode_escape")
    if raw in ("true", "false"):
        return raw == "true"
    if re.fullmatch(r"-?\d+", raw):
        return int(raw)
    if re.fullmatch(r"-?\d+\.\d+", raw):
        return float(raw)
    if re.fullmatch(r"[A-Za-z_][\w.-]*", raw):
        return raw
    raise GammaError(f"unsupported value syntax: {raw}")

def parse(source: str) -> Program:
    p = Program()
    lines = source.splitlines()
    saw_language = False
    i = 0
    while i < len(lines):
        raw = lines[i]
        s = raw.strip()
        n = i + 1
        i += 1
        if not s or s.startswith("#"):
            continue
        if s == "language Ɣ":
            if saw_language: raise GammaError(f"{n}: duplicate language declaration")
            saw_language = True
        elif s.startswith("domain "):
            p.domain = s[7:].strip()
            if not re.fullmatch(r"[A-Za-z_][\w.-]*", p.domain):
                raise GammaError(f"{n}: invalid domain name")
        elif s.startswith("concept "):
            name = s[8:].strip()
            if not re.fullmatch(r"[A-Za-z_][\w.-]*", name):
                raise GammaError(f"{n}: invalid concept name")
            p.declarations.append(Decl("concept", name, {}, n))
        elif s.startswith("relation "):
            bits = s.split()
            if len(bits) != 4:
                raise GammaError(f"{n}: relation syntax is 'relation SUBJECT PREDICATE OBJECT'")
            p.relations.append(Relation(bits[1], bits[2], bits[3], n))
        elif any(s.startswith(k + " ") for k in BLOCK_TYPES):
            kind, name = s.split(maxsplit=1)
            if not re.fullmatch(r"[A-Za-z_][\w.-]*", name):
                raise GammaError(f"{n}: invalid {kind} identifier")
            attrs = {}
            closed = False
            while i < len(lines):
                body = lines[i].strip()
                bn = i + 1
                i += 1
                if body == "end":
                    closed = True
                    break
                if not body or body.startswith("#"): continue
                m = re.fullmatch(r"([A-Za-z_][\w.-]*)\s+(.+)", body)
                if not m:
                    raise GammaError(f"{bn}: expected 'property value' or 'end'")
                key, val = m.groups()
                if key in attrs:
                    raise GammaError(f"{bn}: duplicate property '{key}'")
                attrs[key] = parse_atom(val)
            if not closed: raise GammaError(f"{n}: unclosed {kind} block")
            p.declarations.append(Decl(kind, name, attrs, n))
        elif s.startswith("claim "):
            m = re.fullmatch(r"claim\s+([A-Za-z_][\w.-]*)\s+is\s+(.+)\s+supported_by\s+([A-Za-z_][\w.-]*)", s)
            if not m: raise GammaError(f"{n}: malformed claim")
            name, val, ev = m.groups()
            p.claims.append(Claim(name, parse_atom(val), ev, n))
        elif s.startswith("assess "):
            m = re.fullmatch(r"assess\s+([A-Za-z_][\w.-]*)\s+as\s+([A-Za-z_][\w.-]*)", s)
            if not m: raise GammaError(f"{n}: malformed assessment")
            claim_name, state = m.groups()
            if state not in STATES: raise GammaError(f"{n}: invalid assessment state '{state}'")
            p.assessments.append(Assessment(claim_name, state, n))
        else:
            raise GammaError(f"{n}: unrecognized statement: {s}")
    if not saw_language: raise GammaError("missing 'language Ɣ' declaration")
    return p

def symbol_table(p: Program) -> dict[str, Decl]:
    table = {}
    for d in p.declarations:
        if d.name in table: raise GammaError(f"{d.line}: duplicate identifier '{d.name}'")
        table[d.name] = d
    return table

def validate(p: Program) -> list[str]:
    errors = []
    table = symbol_table(p)
    for r in p.relations:
        if r.subject not in table: errors.append(f"{r.line}: unknown relation subject '{r.subject}'")
        if r.object not in table: errors.append(f"{r.line}: unknown relation object '{r.object}'")
    evidence = {d.name for d in p.declarations if d.kind == "evidence"}
    claims = {c.name for c in p.claims}
    for c in p.claims:
        if c.evidence_id not in evidence:
            errors.append(f"{c.line}: claim '{c.name}' references missing evidence '{c.evidence_id}'")
    for a in p.assessments:
        if a.claim not in claims: errors.append(f"{a.line}: assessment references missing claim '{a.claim}'")
    for d in p.declarations:
        if d.kind in ("sensor", "transmitter", "receiver"):
            if "modality" not in d.attrs: errors.append(f"{d.line}: {d.kind} '{d.name}' requires modality")
            allowed = {"optical", "electromagnetic", "acoustic", "chemical", "thermal", "abstract"}
            if "modality" in d.attrs and d.attrs["modality"] not in allowed:
                errors.append(f"{d.line}: unsupported modality '{d.attrs['modality']}'")
            if d.kind == "sensor" and d.attrs.get("role") != "receive":
                errors.append(f"{d.line}: sensors must declare role receive")
            if d.kind == "receiver" and d.attrs.get("role") != "receive":
                errors.append(f"{d.line}: receivers must declare role receive")
            if d.kind == "transmitter" and d.attrs.get("role") != "transmit":
                errors.append(f"{d.line}: transmitters must declare role transmit")
            io_key = "input" if d.kind in ("sensor", "receiver") else "output"
            if d.attrs.get(io_key) != "simulated":
                errors.append(f"{d.line}: {d.kind} {io_key} must be 'simulated' in this prototype")
    return errors

def evaluate(p: Program) -> dict[str, str]:
    ev = {d.name: d for d in p.declarations if d.kind == "evidence"}
    results = {}
    for c in p.claims:
        evidence = ev.get(c.evidence_id)
        if evidence is None:
            results[c.name] = "unknown"
            continue
        observation = str(evidence.attrs.get("observation", "")).lower()
        if not observation:
            results[c.name] = "unknown"
        elif "conflict" in observation:
            results[c.name] = "conflicted"
        else:
            # Evidence exists, but this seed does not infer truth from an arbitrary
            # observation string; explicit source assessment remains authoritative.
            results[c.name] = "uncertain"
    for a in p.assessments:
        results[a.claim] = a.state
    return results

def to_ir(p: Program) -> dict[str, Any]:
    # Stable source-order arrays; sorted attribute keys for deterministic serialization.
    return {
        "ir": "GAMMA-IR-0.1",
        "language": "Ɣ",
        "domain": p.domain,
        "nodes": [
            {"id": d.name, "type": d.kind, "attributes": dict(sorted(d.attrs.items()))}
            for d in p.declarations
        ],
        "edges": [
            {"subject": r.subject, "predicate": r.predicate, "object": r.object}
            for r in p.relations
        ],
        "evidence": [
            {"id": d.name, "origin": d.attrs.get("origin"),
             "method": d.attrs.get("method"), "observation": d.attrs.get("observation")}
            for d in p.declarations if d.kind == "evidence"
        ],
        "claims": [asdict(c) for c in p.claims],
        "assessments": [asdict(a) for a in p.assessments],
        "evaluation": evaluate(p)
    }

def simulate(p: Program) -> dict[str, Any]:
    """Deterministic, synthetic signal fixtures only."""
    devices = [d for d in p.declarations if d.kind in ("sensor", "receiver", "transmitter")]
    return {
        "simulation_only": True,
        "physical_io": False,
        "channels": [
            {"id": d.name, "kind": d.kind, "modality": d.attrs.get("modality"),
             "role": d.attrs.get("role"), "input_or_output": d.attrs.get("input", d.attrs.get("output")),
             "sample": {"synthetic_level": 0.42, "unit": "normalized_arbitrary_unit"}}
            for d in devices
        ],
        "note": "Synthetic normalized samples; not exposure measurements or operating instructions."
    }
