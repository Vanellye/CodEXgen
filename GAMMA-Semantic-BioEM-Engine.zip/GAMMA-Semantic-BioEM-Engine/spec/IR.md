# Ɣ Intermediate Representation 0.1

The first IR is deterministic JSON:
```json
{
  "ir": "GAMMA-IR-0.1",
  "language": "Ɣ",
  "domain": "BioOptic",
  "nodes": [],
  "edges": [],
  "evidence": [],
  "claims": [],
  "assessments": []
}
```
Nodes carry stable source identifiers, semantic type, and attributes. Edges preserve direction, subject, predicate, and object. Claims retain evidence references. The IR is descriptive and has no executable opcodes in this release.
