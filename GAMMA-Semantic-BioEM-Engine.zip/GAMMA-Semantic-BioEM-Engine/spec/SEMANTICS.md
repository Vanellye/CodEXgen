# Ɣ Semantic Model 0.3

## Independence
Ɣ owns its grammar, types, relation semantics, evidence model, evaluator, and IR. ERIA integrations are optional adapters outside the language core.

## Typed values
`concept`, `value`, `sensor`, `transmitter`, `receiver`, `relation`, `evidence`, `claim`, `assess`, `event`, `transition`, and `constraint` are distinct semantic constructs.

## Relation graph
Relations are directed typed edges. The prototype validates referenced nodes and preserves predicate names. It does not infer causal relationships from correlation.

## Evidence lineage
Evidence nodes retain origin, method, observation, and optional timestamp. Claims point to evidence IDs. The IR preserves these links; missing evidence is not replaced by an inferred value.

## Assessment lattice
The evaluator uses:
- `affirmed`
- `denied`
- `uncertain`
- `unknown`
- `conflicted`
- `not_applicable`

The assessment is not a probability and not an authorization. `uncertain` is not the same as `unknown`: uncertain means some evidence exists but is insufficient or mixed; unknown means no usable evidence has been supplied; conflicted means evidence explicitly contradicts itself.

## Asymmetry
Asymmetry is represented explicitly as a relation/property between channels or observations, such as distinct source and receiver paths, unequal values, directional edges, or non-reciprocal mappings. The term does not imply a biological intervention or hidden physical mechanism.

## Sensor / transmitter / receiver
The source language can describe modality, role, data provenance, units, and abstract channels. Current implementation only simulates signals. Transmitter declarations are metadata in a model; they do not expose hardware output APIs.

## Radiation and electromagnetic domain
Ɣ can represent electromagnetic observations, spectrum labels, optical bands, passive receiver measurements, and synthetic field metadata. It does not specify exposure levels, biological dosing, or operational settings for radiation sources.

## Authority
A described action does not execute. Any physical or privileged effect belongs outside this prototype and requires explicit host-side authorization.
