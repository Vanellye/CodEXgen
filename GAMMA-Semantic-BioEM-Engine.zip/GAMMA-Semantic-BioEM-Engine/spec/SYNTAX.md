# Ɣ Syntax 0.3

All source files start with `language Ɣ`. Declarations are line-oriented.

```gamma
language Ɣ
domain BioOptic

concept Organism
concept PhotonSignal
concept Detector

relation PhotonSignal observed_by Detector

sensor OpticalReceiver
  modality optical
  role receive
  input simulated
  quantity photon_count_rate
  unit count_per_second
end

transmitter AbstractEmitter
  modality optical
  role transmit
  output simulated
  signal symbolic_photon_stream
end

receiver PassiveEMReceiver
  modality electromagnetic
  role receive
  input simulated
  quantity field_sample
  unit arbitrary_unit
end

evidence E1
  origin "synthetic_fixture"
  method "simulation"
  observation "photon_count_rate=120"
end

claim photon_flux is 120 supported_by E1
assess photon_flux as uncertain
```

Supported top-level statements:
- `language Ɣ`
- `domain NAME`
- `concept NAME`
- `relation SUBJECT PREDICATE OBJECT`
- `sensor NAME ... end`
- `transmitter NAME ... end`
- `receiver NAME ... end`
- `evidence NAME ... end`
- `claim NAME is VALUE supported_by EVIDENCE_ID`
- `assess CLAIM as STATE`

Block properties are `key value` pairs. Quoted strings are supported. Values may be quoted text, integers, decimals, booleans, or bare identifiers. This syntax is a seed, not a settled final grammar.
