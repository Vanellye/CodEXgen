import sys, unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "gamma"))
from core import parse, validate, to_ir, evaluate, GammaError

BASE = """language Ɣ
domain Test
concept A
concept B
relation A connects_to B
evidence E1
  origin "fixture"
  method "simulation"
  observation "sample=1"
end
claim x is 1 supported_by E1
assess x as uncertain
"""

class GammaTests(unittest.TestCase):
    def test_parse_and_validate(self):
        p = parse(BASE)
        self.assertEqual(validate(p), [])
        self.assertEqual(p.domain, "Test")

    def test_ir_keeps_lineage(self):
        ir = to_ir(parse(BASE))
        self.assertEqual(ir["claims"][0]["evidence_id"], "E1")
        self.assertEqual(ir["evidence"][0]["id"], "E1")
        self.assertEqual(ir["edges"][0]["subject"], "A")

    def test_assessment(self):
        self.assertEqual(evaluate(parse(BASE))["x"], "uncertain")

    def test_missing_evidence_rejected(self):
        src = BASE.replace("supported_by E1", "supported_by Missing")
        self.assertTrue(any("missing evidence" in e for e in validate(parse(src))))

    def test_binary_out_of_domain_rejected(self):
        src = BASE.replace("assess x as uncertain", "assess x as maybe")
        with self.assertRaises(GammaError):
            parse(src)

    def test_hardware_io_fails_closed(self):
        src = BASE + """
transmitter Physical
  modality electromagnetic
  role transmit
  output hardware
end
"""
        self.assertTrue(any("must be 'simulated'" in e for e in validate(parse(src))))

if __name__ == "__main__":
    unittest.main()
