#!/usr/bin/env python3
"""Decode a GY protocol binary record or zero-free .gya armor."""
import sys, base64, hashlib
from pathlib import Path

def read_uvarint(data, pos):
    value = shift = 0
    while True:
        byte = data[pos]
        pos += 1
        value |= (byte & 127) << shift
        if byte < 128:
            return value, pos
        shift += 7

def unarmor(s):
    s = s.replace("~A", "0").replace("~B", "~")
    s += "=" * ((4 - len(s) % 4) % 4)
    return base64.urlsafe_b64decode(s.encode("ascii"))

def decode(data):
    if data[:2] != b"GY":
        raise ValueError("Unknown protocol signature")
    body, digest = data[:-8], data[-8:]
    if hashlib.sha256(body).digest()[:8] != digest:
        raise ValueError("Integrity check failed")
    pos = 2
    version, direction = data[pos], data[pos + 1]
    pos += 2
    seq, pos = read_uvarint(data, pos)
    scale, pos = read_uvarint(data, pos)
    zz, pos = read_uvarint(data, pos)
    coeff = (zz >> 1) ^ -(zz & 1)
    size, pos = read_uvarint(data, pos)
    provenance = data[pos:pos + size].decode("utf-8")
    sign = "-" if coeff < 0 else ""
    digits = str(abs(coeff)).rjust(scale + 1, "0")
    decimal = sign + (digits[:-scale] + "." + digits[-scale:] if scale else digits)
    direction_name = {1: "forward", 2: "reverse"}.get(direction, "unknown")
    return {
        "protocol": "GY",
        "version": version,
        "direction": direction_name,
        "sequence": seq,
        "exact_decimal": decimal,
        "provenance": provenance,
        "integrity": "valid"
    }

p = Path(sys.argv[1])
blob = p.read_bytes()
if p.suffix == ".gya":
    blob = unarmor(blob.decode("ascii").strip())
print(decode(blob))
