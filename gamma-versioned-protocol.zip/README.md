# Ɣ Protocol — versioned reversible binary format

## Design goals
- Compact binary records for mobile transfer and local storage.
- Reversible exact-decimal interpretation.
- Explicit forward or reverse numerical direction.
- Provenance carried with each record.
- Integrity check before interpretation.
- Zero-free printable transport armor: the `.gya` text representation never emits the digit zero.

## Record structure
- Signature: `GY`
- Version byte
- Direction byte: one means forward, two means reverse
- Unsigned variable-length sequence number
- Unsigned variable-length decimal scale
- ZigZag + unsigned-varint signed coefficient
- Unsigned-varint provenance byte length
- UTF-eight provenance bytes
- First eight bytes of SHA-two-fifty-six digest over the preceding record bytes

The value is reconstructed as coefficient divided by ten raised to scale.
The sample coefficient is 1111111 and scale is six, yielding exact decimal 1.111111.
The reverse sample stores the negative coefficient and reverse direction.

## Zero-free mobile armor
The `.gya` transport form uses URL-safe Base-sixty-four without padding, then escapes
the printed digit zero as `~A`. A literal tilde is escaped as `~B`.
Decoding reverses those substitutions and restores the original bytes exactly.
Raw `.bin` files remain compact and may contain any byte value, including a byte whose
numeric value is nil; the no-printed-zero guarantee applies to `.gya` text output.

## Provenance
The sample provenance string is `source:1.111111`. Production records should use a
stable source identifier, creator or signer identity, creation timestamp, and parent
record digest. This demo stores provenance as descriptive text and does not authenticate
a person or prove an external event.

## Numerical direction
Direction is an explicit operation marker, not a guess from the number:
- forward: apply the stored signed coefficient in the forward direction
- reverse: interpret the signed coefficient in reverse direction

The protocol intentionally has no stationary direction state. Applications needing
units must add a declared unit code in a future schema version.

## Validation
The decoder verifies the digest before showing the decimal or provenance.
The digest detects accidental corruption; it is not a digital signature.
Use a signature scheme in a later production profile if sender authenticity is required.
