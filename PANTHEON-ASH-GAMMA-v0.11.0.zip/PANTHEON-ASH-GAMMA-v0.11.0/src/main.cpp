#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <map>
#include <regex>
#include <set>
#include <sstream>
#include <string>
#include <vector>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <cerrno>
#include <openssl/evp.h>
#include <openssl/pem.h>
#include <openssl/sha.h>
#include <sys/file.h>
#include <fcntl.h>
#include <sys/stat.h>

namespace fs = std::filesystem;
struct Mapping { std::string command, package, repo; };

static std::string trim(std::string s) {
    auto a=s.find_first_not_of(" \t\r\n");
    if(a==std::string::npos) return "";
    auto b=s.find_last_not_of(" \t\r\n");
    return s.substr(a,b-a+1);
}
static std::string timestamp() {
    std::time_t t=std::time(nullptr); char b[32]{};
    std::strftime(b,sizeof(b),"%Y-%m-%dT%H:%M:%SZ",std::gmtime(&t)); return b;
}
static void ledger(const std::string& event, const std::string& detail) {
    std::ofstream f("data/gamma-ledger.tsv", std::ios::app);
    f << timestamp() << "\t" << event << "\t" << detail << "\n";
}
static bool safe_token(const std::string& s) {
    return !s.empty() && std::regex_match(s, std::regex("[A-Za-z0-9_+.-]+"));
}
static std::vector<Mapping> load_registry(const std::string& path) {
    std::ifstream f(path);
    std::vector<Mapping> out;
    if(!f) return out;
    std::regex rx(R"rx(map\s+"([A-Za-z0-9_\[\].+-]+)"\s*=>\s*package\("([A-Za-z0-9_+.-]+)"\)\s+from\s+repo\("([A-Za-z0-9_-]+)"\)\s*;)rx");
    std::string line; std::smatch m;
    while(std::getline(f,line)) if(std::regex_search(line,m,rx))
        out.push_back({m[1],m[2],m[3]});
    return out;
}
static std::set<std::string> installed_packages() {
    std::set<std::string> out;
    // Fixed, read-only package query; no user-supplied text enters the shell.
    FILE* p=popen("dpkg-query -W -f='${binary:Package}\\n' 2>/dev/null","r");
    if(!p) return out;
    char buf[512];
    while(fgets(buf,sizeof(buf),p)) { auto s=trim(buf); if(!s.empty()) out.insert(s); }
    pclose(p); return out;
}
static bool executable_exists(const std::string& name) {
    if(!safe_token(name)) return false;
    std::string cmd = "command -v " + name + " >/dev/null 2>&1";
    return std::system(cmd.c_str()) == 0;
}

static int install_package(const std::string& package) {
    if(!safe_token(package)) return 2;
    std::cout << "Installing missing package: " << package << "\n";
    pid_t pid = fork();
    if(pid < 0) { perror("fork"); return 2; }
    if(pid == 0) {
        execlp("pkg", "pkg", "install", "-y", package.c_str(), (char*)nullptr);
        perror("pkg");
        _exit(127);
    }
    int status = 0;
    if(waitpid(pid, &status, 0) < 0) { perror("waitpid"); return 2; }
    if(WIFEXITED(status)) return WEXITSTATUS(status);
    return 128;
}

static std::string hex_encode(const unsigned char* data, size_t n) {
    static const char* h="0123456789abcdef"; std::string out;
    for(size_t i=0;i<n;++i){ out.push_back(h[data[i]>>4]); out.push_back(h[data[i]&15]); }
    return out;
}
static bool hex_decode(const std::string& s, std::vector<unsigned char>& out) {
    if(s.size()%2) return false;
    out.clear();
    auto val=[](char c)->int { if(c>='0'&&c<='9')return c-'0'; if(c>='a'&&c<='f')return c-'a'+10; if(c>='A'&&c<='F')return c-'A'+10; return -1; };
    for(size_t i=0;i<s.size();i+=2){int a=val(s[i]),b=val(s[i+1]);if(a<0||b<0)return false;out.push_back((a<<4)|b);} return true;
}
static bool pons_keygen(const std::string& priv, const std::string& pub) {
    EVP_PKEY_CTX* c=EVP_PKEY_CTX_new_id(EVP_PKEY_ED25519,nullptr); EVP_PKEY* k=nullptr;
    bool ok=c && EVP_PKEY_keygen_init(c)>0 && EVP_PKEY_keygen(c,&k)>0;
    FILE* f=nullptr;
    if(ok){ f=fopen(priv.c_str(),"wb"); ok=f && PEM_write_PrivateKey(f,k,nullptr,nullptr,0,nullptr,nullptr)==1; if(f)fclose(f); }
    if(ok){ f=fopen(pub.c_str(),"wb"); ok=f && PEM_write_PUBKEY(f,k)==1; if(f)fclose(f); }
    if(k) EVP_PKEY_free(k);
    if(c) EVP_PKEY_CTX_free(c);
    if(ok) chmod(priv.c_str(),0600);
    return ok;
}
static bool pons_sign(const std::string& keyfile,const std::string& payload,std::string& sighex) {
    FILE* f=fopen(keyfile.c_str(),"rb"); if(!f)return false;
    EVP_PKEY* k=PEM_read_PrivateKey(f,nullptr,nullptr,nullptr); fclose(f); if(!k)return false;
    EVP_MD_CTX* c=EVP_MD_CTX_new(); unsigned char sig[128]; size_t n=sizeof(sig);
    bool ok=c && EVP_DigestSignInit(c,nullptr,nullptr,nullptr,k)==1 &&
        EVP_DigestSign(c,sig,&n,(const unsigned char*)payload.data(),payload.size())==1;
    if(ok) sighex=hex_encode(sig,n);
    if(c) EVP_MD_CTX_free(c);
    EVP_PKEY_free(k);
    return ok;
}
static bool pons_verify(const std::string& keyfile,const std::string& payload,const std::string& sighex) {
    std::vector<unsigned char> sig; if(!hex_decode(sighex,sig))return false;
    FILE* f=fopen(keyfile.c_str(),"rb"); if(!f)return false;
    EVP_PKEY* k=PEM_read_PUBKEY(f,nullptr,nullptr,nullptr); fclose(f); if(!k)return false;
    EVP_MD_CTX* c=EVP_MD_CTX_new();
    bool ok=c && EVP_DigestVerifyInit(c,nullptr,nullptr,nullptr,k)==1 &&
        EVP_DigestVerify(c,sig.data(),sig.size(),(const unsigned char*)payload.data(),payload.size())==1;
    if(c) EVP_MD_CTX_free(c);
    EVP_PKEY_free(k);
    return ok;
}
static bool pons_issue(const std::string& key,const std::string& file,const std::string& cmd,
                       const std::string& pkg,long long expiry,unsigned long long maxuses) {
    if(!safe_token(cmd)||!safe_token(pkg)||expiry<=std::time(nullptr)||maxuses<1||maxuses>1000000)return false;
    std::string payload="PONS-ED25519-V1\n"+cmd+"\n"+pkg+"\n"+std::to_string(expiry)+"\n"+std::to_string(maxuses)+"\n";
    std::string sig; if(!pons_sign(key,payload,sig))return false;
    std::ofstream out(file,std::ios::binary|std::ios::trunc); if(!out)return false;
    out<<payload<<sig<<"\n"; out.close(); chmod(file.c_str(),0600); return bool(out);
}
struct PonsToken { std::string command,package,payload,signature; long long expiry=0; unsigned long long maxuses=0; };
static bool read_pons_token(const std::string& path,PonsToken& t) {
    std::ifstream f(path); std::string magic,expiry,uses;
    if(!std::getline(f,magic)||!std::getline(f,t.command)||!std::getline(f,t.package)||
       !std::getline(f,expiry)||!std::getline(f,uses)||!std::getline(f,t.signature))return false;
    if(magic!="PONS-ED25519-V1"||!safe_token(t.command)||!safe_token(t.package))return false;
    try { size_t a=0,b=0;t.expiry=std::stoll(expiry,&a);t.maxuses=std::stoull(uses,&b);if(a!=expiry.size()||b!=uses.size())return false; } catch(...) { return false; }
    if(t.expiry<=0||t.maxuses<1||t.maxuses>1000000)return false;
    t.payload=magic+"\n"+t.command+"\n"+t.package+"\n"+expiry+"\n"+uses+"\n"; return true;
}
// Locked local use counter. This prevents ordinary concurrent overuse; it is not rollback-proof.
static bool pons_consume(const PonsToken& t,const std::string& pubkey) {
    if(!pons_verify(pubkey,t.payload,t.signature)||t.expiry<=std::time(nullptr))return false;
    unsigned char digest[SHA256_DIGEST_LENGTH]; SHA256((const unsigned char*)t.payload.data(),t.payload.size(),digest);
    std::string id=hex_encode(digest,sizeof(digest));
    fs::create_directories("data");
    int fd=open("data/pons-token-uses.tsv",O_CREAT|O_RDWR,0600); if(fd<0)return false;
    if(flock(fd,LOCK_EX)<0){close(fd);return false;}
    FILE* f=fdopen(dup(fd),"r"); unsigned long long used=0; char line[512];
    if(f){while(fgets(line,sizeof(line),f)){char key[80];unsigned long long n;if(sscanf(line,"%79s %llu",key,&n)==2&&id==key)used=n;}fclose(f);}
    bool ok=used<t.maxuses;
    if(ok){
        std::string row=id+" "+std::to_string(used+1)+"\n";
        if(lseek(fd,0,SEEK_END)<0||write(fd,row.data(),row.size())!=(ssize_t)row.size())ok=false;
        fsync(fd);
    }
    flock(fd,LOCK_UN);close(fd); return ok;
}

static void help() {
    std::cout <<
    "PANTHEON / ASH / GAMMA v0.11.0\n"
    "  ./pantheon gamma commands [file]\n"
    "  ./pantheon gamma packages [file]\n"
    "  ./pantheon gamma resolve <command> [file]\n"
    "  ./pantheon gamma discover [file]\n"
    "  ./pantheon gamma inspect <command> [file]\n"
    "  ./pantheon gamma prepare <command> [package] [file]\n"
    "  ./pantheon gamma run <command> --token <file> [--public-key <pem>] [--package <package>] [--session 1|2|3] [-- args...]\n"
    "  ./pantheon gamma ledger\n"
    "  ./pantheon pons keygen <private.pem> <public.pem>\n"
    "  ./pantheon pons issue <private.pem> <token> <command> <package> <expiry-unix> <max-uses>\n"
    "  ./pantheon pons verify <public.pem> <token>\n"
    "\nEvery gamma run requires a signed bounded-use token AND one interactive approval per bounded session (1-3 executions).\n";
}
int main(int argc,char** argv) {
    if(argc<2) { help(); return 0; }
    std::string area=argv[1];
    if(area=="--version" || area=="version") { std::cout<<"0.11.0\n"; return 0; }
    if(area=="pons") {
        if(argc>=5 && std::string(argv[2])=="keygen") {
            if(pons_keygen(argv[3],argv[4])){std::cout<<"Ed25519 keypair created. Keep the private key offline and secret.\n";return 0;}
            std::cerr<<"PONS key generation failed.\n";return 2;
        }
        if(argc==5 && std::string(argv[2])=="verify") {
            PonsToken t;
            if(!read_pons_token(argv[4],t) || t.expiry<=std::time(nullptr) ||
               !pons_verify(argv[3],t.payload,t.signature)) {
                std::cerr<<"PONS token invalid, expired, or signature verification failed.\\n"; return 3;
            }
            std::cout<<"PONS token signature valid; command="<<t.command<<" package="<<t.package
                     <<" expiry="<<t.expiry<<" max_uses="<<t.maxuses<<"\\n"; return 0;
        }
        if(argc==9 && std::string(argv[2])=="issue") {
            long long expiry=0; unsigned long long uses=0;
            try{expiry=std::stoll(argv[7]);uses=std::stoull(argv[8]);}catch(...){std::cerr<<"Invalid expiry or use count.\n";return 2;}
            if(pons_issue(argv[3],argv[4],argv[5],argv[6],expiry,uses)){
                std::cout<<"Signed bounded-use token issued for command="<<argv[5]<<" package="<<argv[6]<<" expiry="<<expiry<<" max_uses="<<uses<<"\n";return 0;}
            std::cerr<<"PONS token issue failed. Check key, scope, expiry, and use count (1..1000000).\n";return 2;
        }
        std::cerr<<"Usage:\n  pantheon pons keygen <private.pem> <public.pem>\n  pantheon pons issue <private.pem> <token-file> <command> <package> <expiry-unix> <max-uses>\n";
        return 2;
    }
    if(area!="gamma" || argc<3) { help(); return area=="gamma"?1:0; }
    std::string action=argv[2];
    if(action=="ledger") {
        std::ifstream f("data/gamma-ledger.tsv"); std::string line;
        if(!f) { std::cout<<"No ledger entries yet.\n"; return 0; }
        while(std::getline(f,line)) std::cout<<line<<"\n";
        return 0;
    }
    int argi=3;
    std::string target;
    if(action=="resolve" || action=="inspect" || action=="prepare" || action=="run") {
        if(argc<=argi) { std::cerr<<"Missing command token.\n"; return 2; }
        target=argv[argi++];
        if(!safe_token(target)) { std::cerr<<"Invalid command token.\n"; return 2; }
    }
    // In prepare, the first optional argument is the package selector.
    // The registry path follows the selector; otherwise use the default.
    std::string path = "language/termux.og";
    if(action=="prepare") {
        if(argc > argi + 1) path = argv[argi + 1];
    } else if(action!="run" && argc > argi) {
        path = argv[argi];
    }
    auto maps=load_registry(path);
    if(maps.empty()) { std::cerr<<"No mappings parsed from "<<path<<". Check .og syntax/path.\n"; return 3; }
    auto installed=installed_packages();

    if(action=="prepare") {
        std::string requested_package;
        // Optional package argument selects a candidate for ambiguous aliases.
        if(argc > argi) requested_package = argv[argi++];
        std::vector<Mapping> hits;
        for(auto&m:maps) if(m.command==target) hits.push_back(m);
        if(hits.empty()) {
            std::cerr << "No mapping for command: " << target << "\n";
            ledger("PREPARE_REJECTED", target+" no_mapping");
            return 4;
        }
        Mapping chosen{};
        if(!requested_package.empty()) {
            if(!safe_token(requested_package)) {
                std::cerr << "Invalid package token.\n"; return 2;
            }
            bool found=false;
            for(auto&m:hits) if(m.package==requested_package) { chosen=m; found=true; break; }
            if(!found) {
                std::cerr << "Package is not a registered candidate for " << target << ".\n";
                ledger("PREPARE_REJECTED", target+" invalid_candidate="+requested_package);
                return 5;
            }
        } else {
            std::set<std::string> candidates;
            for(auto&m:hits) candidates.insert(m.package);
            if(candidates.size()!=1) {
                std::cerr << "AMBIGUOUS: choose one registered package candidate explicitly.\n";
                for(auto&c:candidates) std::cerr << "  " << c << "\n";
                ledger("PREPARE_BLOCKED", target+" ambiguous");
                return 6;
            }
            chosen=hits.front();
        }
        auto current=installed_packages();
        if(current.count(chosen.package)) {
            std::cout << "Package already installed: " << chosen.package << "\n";
            ledger("PREPARE_READY", target+" package="+chosen.package+" already_installed");
            std::cout << "Dependency flow complete. Mapped command was NOT executed.\n";
            return 0;
        }
        ledger("INSTALL_REQUESTED", target+" package="+chosen.package+" repo="+chosen.repo);
        int rc=install_package(chosen.package);
        if(rc!=0) {
            std::cerr << "Package installation failed with exit code " << rc << ".\n";
            ledger("INSTALL_FAILED", chosen.package+" exit="+std::to_string(rc));
            return rc;
        }
        auto after=installed_packages();
        if(!after.count(chosen.package)) {
            std::cerr << "Installer returned success, but package is not present in dpkg status.\n";
            ledger("INSTALL_UNVERIFIED", chosen.package);
            return 7;
        }
        ledger("PREPARE_READY", target+" package="+chosen.package+" installed");
        std::cout << "Dependency flow complete. Package verified installed.\n";
        std::cout << "Mapped command was NOT executed.\n";
        return 0;
    }
    if(action=="run") {
        // Syntax: gamma run <command> [--package <candidate>] [-- <arguments...>]
        // Execution uses execvp directly: no shell, interpolation, or command string.
        if(!isatty(STDIN_FILENO) || !isatty(STDOUT_FILENO)) {
            std::cerr << "PONS_BLOCKED: gamma run requires an interactive terminal for human approval.\n";
            ledger("RUN_BLOCKED", target+" non_interactive");
            return 20;
        }
        std::string selected_package, token_file, public_key="keys/pons-public.pem";
        unsigned int session_count=1;
        std::vector<std::string> child_args;
        int i=argi;
        while(i<argc) {
            std::string a=argv[i++];
            if(a=="--package") {
                if(i>=argc || !selected_package.empty()) {
                    std::cerr << "Usage: gamma run <command> [--package <package>] [-- <args...>]\n";
                    return 2;
                }
                selected_package=argv[i++];
                if(!safe_token(selected_package)) { std::cerr<<"Invalid package token.\n"; return 2; }
            } else if(a=="--token" || a=="--public-key") {
                if(i>=argc){std::cerr<<"Missing value for "<<a<<"\n";return 2;}
                if(a=="--token") token_file=argv[i++]; else public_key=argv[i++];
            } else if(a=="--") {
                while(i<argc) child_args.emplace_back(argv[i++]);
                break;
            } else {
                std::cerr << "Unexpected argument: " << a << "\nUse -- before command arguments.\n";
                return 2;
            }
        }
        std::vector<Mapping> hits;
        for(auto&m:maps) if(m.command==target) hits.push_back(m);
        if(hits.empty()) {
            std::cerr<<"No mapping for command: "<<target<<"\n";
            ledger("RUN_REJECTED",target+" no_mapping"); return 4;
        }
        std::set<std::string> candidates;
        for(auto&m:hits) candidates.insert(m.package);
        Mapping chosen{};
        if(selected_package.empty()) {
            if(candidates.size()!=1) {
                std::cerr<<"PONS_BLOCKED: ambiguous command; select a registered candidate with --package.\n";
                for(auto&c:candidates) std::cerr<<"  "<<c<<"\n";
                ledger("RUN_BLOCKED",target+" ambiguous"); return 6;
            }
            chosen=hits.front();
        } else {
            bool found=false;
            for(auto&m:hits) if(m.package==selected_package) { chosen=m; found=true; break; }
            if(!found) {
                std::cerr<<"PONS_BLOCKED: package is not a registered candidate.\n";
                ledger("RUN_REJECTED",target+" invalid_candidate="+selected_package); return 5;
            }
        }
        auto current=installed_packages();
        if(!current.count(chosen.package)) {
            std::cerr<<"PONS_BLOCKED: package is not installed. Run gamma prepare first.\n";
            ledger("RUN_BLOCKED",target+" package_missing="+chosen.package); return 7;
        }
        if(!executable_exists(target)) {
            std::cerr<<"PONS_BLOCKED: mapped executable is not on PATH: "<<target<<"\n";
            ledger("RUN_BLOCKED",target+" executable_missing"); return 8;
        }
        PonsToken signed_token;
        auto validate_token = [&]() -> bool {
            PonsToken fresh;
            if(token_file.empty() || !read_pons_token(token_file,fresh) ||
               fresh.command!=target || fresh.package!=chosen.package ||
               !pons_verify(public_key,fresh.payload,fresh.signature) ||
               fresh.expiry<=std::time(nullptr)) return false;
            signed_token=std::move(fresh);
            return true;
        };
        if(!validate_token()) {
            std::cerr<<"PONS_BLOCKED: missing, invalid, expired, or out-of-scope signed token.\\n";
            ledger("RUN_BLOCKED",target+" signed_token_invalid_or_expired"); return 23;
        }
        std::cout<<"PONS ACTION REVIEW\\n"
                 <<"  command: "<<target<<"\\n"
                 <<"  package: "<<chosen.package<<" ("<<chosen.repo<<")\\n"
                 <<"  session executions: "<<session_count<<" (maximum 3)\\n"
                 <<"  arguments:";
        if(child_args.empty()) std::cout<<" (none)";
        for(auto&a:child_args) std::cout<<" ["<<a<<"]";
        std::cout<<"\\n  execution: direct process launch; no shell\\n"
                 <<"  effect: the selected program may modify files, data, or device state.\\n"
                 <<"Type exactly: PONS APPROVE "<<target<<" SESSION "<<session_count<<"\\n> "<<std::flush;
        std::string approval;
        const std::string expected="PONS APPROVE "+target+" SESSION "+std::to_string(session_count);
        if(!std::getline(std::cin,approval) || approval!=expected) {
            std::cout<<"PONS_DENIED: no exact human session approval received.\\n";
            ledger("RUN_DENIED",target+" human_session_approval_missing"); return 21;
        }
        ledger("SESSION_APPROVED",target+" package="+chosen.package+" count="+std::to_string(session_count));
        std::vector<char*> exec_args;
        exec_args.push_back(const_cast<char*>(target.c_str()));
        for(auto& a:child_args) exec_args.push_back(const_cast<char*>(a.c_str()));
        exec_args.push_back(nullptr);
        int last_rc=0;
        for(unsigned int run_index=1; run_index<=session_count; ++run_index) {
            // Re-read and verify the signed scope and expiry before each launch.
            if(!validate_token()) {
                std::cerr<<"PONS_BLOCKED: token became invalid or expired during session.\\n";
                ledger("SESSION_BLOCKED",target+" token_invalid_or_expired run="+std::to_string(run_index));
                return 23;
            }
            if(!pons_consume(signed_token,public_key)) {
                std::cerr<<"PONS_BLOCKED: token use limit reached or token verification failed.\\n";
                ledger("RUN_BLOCKED",target+" token_exhausted run="+std::to_string(run_index)); return 23;
            }
            ledger("RUN_APPROVED",target+" package="+chosen.package+
                   " session_run="+std::to_string(run_index)+
                   " signed_token_use_consumed");
            std::cout<<"PONS_APPROVED: launching execution "<<run_index<<"/"<<session_count<<".\\n"<<std::flush;
            pid_t pid=fork();
            if(pid<0) { perror("fork"); ledger("RUN_FAILED",target+" fork"); return 22; }
            if(pid==0) {
                execvp(target.c_str(),exec_args.data());
                perror("execvp");
                _exit(errno==ENOENT?127:126);
            }
            int status=0;
            if(waitpid(pid,&status,0)<0) { perror("waitpid"); ledger("RUN_FAILED",target+" waitpid"); return 22; }
            last_rc=WIFEXITED(status)?WEXITSTATUS(status):(WIFSIGNALED(status)?128+WTERMSIG(status):125);
            ledger("RUN_FINISHED",target+" session_run="+std::to_string(run_index)+
                   " exit="+std::to_string(last_rc));
            if(last_rc!=0) {
                ledger("SESSION_STOPPED",target+" nonzero_exit run="+std::to_string(run_index));
                return last_rc;
            }
        }
        ledger("SESSION_FINISHED",target+" executions="+std::to_string(session_count));
        return last_rc;
    }
    if(action=="commands") {
        std::set<std::string> s; for(auto&m:maps)s.insert(m.command);
        for(auto&x:s) std::cout<<x<<"\n";
        std::cout<<"Parsed "<<maps.size()<<" mappings from "<<path<<"\n";
    } else if(action=="packages") {
        std::set<std::string> s; for(auto&m:maps)s.insert(m.package);
        for(auto&x:s) std::cout<<x<<"\n";
        std::cout<<"Unique packages: "<<s.size()<<"\n";
    } else if(action=="discover") {
        size_t found=0;
        for(auto&m:maps) if(installed.count(m.package)) ++found;
        std::cout<<"Registry mappings: "<<maps.size()<<"\n"
                 <<"Installed package matches: "<<found<<"\n"
                 <<"Discovery is read-only; it does not install or execute anything.\n";
        ledger("DISCOVER",std::to_string(found)+"/"+std::to_string(maps.size()));
    } else if(action=="resolve" || action=="inspect" || action=="prepare" || action=="run") {
        std::vector<Mapping> hits;
        for(auto&m:maps) if(m.command==target) hits.push_back(m);
        if(hits.empty()) { std::cout<<"No mapping for command: "<<target<<"\n"; return 4; }
        std::cout<<"Command: "<<target<<"\n";
        for(auto&m:hits) {
            bool pkg=installed.count(m.package)>0;
            bool bin=executable_exists(target);
            std::cout<<"- package="<<m.package<<" repo="<<m.repo
                     <<" installed="<<(pkg?"yes":"no")
                     <<" executable_on_PATH="<<(bin?"yes":"no")<<"\n";
        }
        if(hits.size()>1) std::cout<<"AMBIGUOUS: multiple package candidates; choose explicitly before any future action.\n";
        if(action=="inspect") ledger("INSPECT",target+" candidates="+std::to_string(hits.size()));
        else ledger("RESOLVE",target+" candidates="+std::to_string(hits.size()));
    } else { help(); return 2; }
    return 0;
}
