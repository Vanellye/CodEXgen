// PARCEL/0.1 strict reference parser. No eval, filesystem, network, or execution.
const KEYS = new Set([
  "OBSERVATION","SUBJECT","ORIGIN","CLAIM","CLASS","EVIDENCE","REPAIR",
  "CHECK","RETURN","STATUS","POSITIVE","REBUKE","REALITY","UNIT","SOURCE_HASH"
]);
const CLASSES = new Set(["VERIFIED","DERIVED","HYPOTHESIS","SUBJECTIVE","METAPHOR","UNKNOWN","CONTRADICTED"]);
const REQUIRED = ["OBSERVATION","SUBJECT","CLAIM","CLASS"];

function parseValue(raw, lineNo) {
  const s = raw.trim();
  if (!s) throw new Error(`line ${lineNo}: missing value`);
  if (s.startsWith('"')) {
    try {
      const v = JSON.parse(s);
      if (typeof v !== "string") throw new Error("quoted value must be a string");
      return v;
    } catch (e) {
      throw new Error(`line ${lineNo}: invalid quoted string (${e.message})`);
    }
  }
  if (s.includes('"')) throw new Error(`line ${lineNo}: quote must enclose the whole value`);
  return s;
}

export function parseParcel(input) {
  if (typeof input !== "string") throw new TypeError("PARCEL input must be text");
  if (input.includes("\u0000")) throw new Error("NUL byte is not valid PARCEL text");
  const lines = input.replace(/\r\n?/g, "\n").split("\n");
  let header = false, ended = false;
  const fields = Object.create(null);
  for (let i = 0; i < lines.length; i++) {
    let line = lines[i].trim();
    const lineNo = i + 1;
    if (!line || line.startsWith("#")) continue;
    if (!header) {
      if (line !== "PARCEL/0.1") throw new Error(`line ${lineNo}: expected PARCEL/0.1`);
      header = true; continue;
    }
    if (ended) throw new Error(`line ${lineNo}: content after END`);
    if (line === "END") { ended = true; continue; }
    const m = line.match(/^([A-Z_]+)\s+(.+)$/);
    if (!m) throw new Error(`line ${lineNo}: expected KEY value`);
    const [, key, raw] = m;
    if (!KEYS.has(key)) throw new Error(`line ${lineNo}: unknown key ${key}`);
    const value = parseValue(raw, lineNo);
    (fields[key] ??= []).push({value, line: lineNo});
  }
  if (!header) throw new Error("empty input");
  if (!ended) throw new Error("missing END");
  for (const key of REQUIRED) {
    if ((fields[key] ?? []).length !== 1) throw new Error(`required key ${key} must occur exactly once`);
  }
  const cls = fields.CLASS[0].value;
  if (!CLASSES.has(cls)) throw new Error(`invalid CLASS ${cls}`);
  if (cls === "VERIFIED" && !(fields.EVIDENCE ?? []).length)
    throw new Error("VERIFIED requires at least one EVIDENCE");
  return {format:"PARCEL/0.1", fields:Object.fromEntries(
    Object.entries(fields).map(([k, vs]) => [k, vs.map(x => x.value)])
  )};
}

export function validateObservation(record) {
  const errors = [];
  if (!record || record.format !== "PARCEL/0.1" || !record.fields) return ["invalid parsed record"];
  const f = record.fields;
  if (f.CLASS?.[0] === "VERIFIED" && !f.EVIDENCE?.length) errors.push("verified record lacks evidence");
  if (f.STATUS?.some(s => !["PROPOSED","APPLIED","VERIFIED","FAILED","NOT_RUN","BLOCKED"].includes(s)))
    errors.push("unknown repair status");
  return errors;
}
