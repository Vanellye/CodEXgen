# PARCEL/0.1 Language Specification

## Lexical rules
- UTF-8 text.
- One statement per line.
- Keywords are uppercase and case-sensitive.
- Quoted strings use JSON string escaping.
- Comments begin with `#` outside strings.
- No expressions, interpolation, evaluation, shell syntax, or implicit network references.
- Parser must consume the complete input; trailing tokens are an error.

## Grammar (EBNF)
```ebnf
document    = "PARCEL/0.1", newline, { statement, newline }, "END", [newline] ;
statement   = key, space, value ;
key         = "OBSERVATION" | "SUBJECT" | "ORIGIN" | "CLAIM" | "CLASS"
            | "EVIDENCE" | "REPAIR" | "CHECK" | "RETURN" | "STATUS"
            | "POSITIVE" | "REBUKE" | "REALITY" | "UNIT" | "SOURCE_HASH" ;
value       = quoted | bare ;
quoted      = '"', { json_char }, '"' ;
bare        = token, { space, token } ;
```

## Required semantics
- Exactly one `OBSERVATION`, `SUBJECT`, `CLAIM`, and `CLASS`.
- `CLASS` must be one of `VERIFIED`, `DERIVED`, `HYPOTHESIS`, `SUBJECTIVE`, `METAPHOR`, `UNKNOWN`, `CONTRADICTED`.
- Repeated `EVIDENCE`, `REPAIR`, `CHECK`, `POSITIVE`, `REBUKE`, `REALITY`, and `UNIT` are allowed.
- `CHECK` has the form `"check-name" EXPECT PASS|FAIL|NOT_RUN` in the richer JSON record format. The 0.1 line parser accepts the entire remainder as a value; semantic validation is required before a check is trusted.
- `VERIFIED` requires at least one evidence reference.
- `UNKNOWN` must not be promoted to verified by narrative language.
- Units are mandatory for physical quantities; metaphorical “energy” must be labelled `METAPHOR`.
