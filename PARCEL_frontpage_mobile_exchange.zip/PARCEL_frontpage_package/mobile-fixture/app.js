const catalog=[
 ["💧","Water","flow · continuity · quality","Measured claims need source, method, units and time."],
 ["🌬","Air","atmosphere · pressure · circulation","Measured claims need conditions and sensor/method."],
 ["🪨","Earth","substrate · structure · boundaries","Material claims need provenance and method."],
 ["🔥","Fire","transformation · heat · reaction","Physical claims need units and safety context."],
 ["💨","Ether","context · connection · symbolic medium","METAPHOR unless operationally defined."],
 ["🕳","Excedra","unknown · boundary · evidence gap","UNKNOWN until evidence closes the gap."]
];
const $=x=>document.getElementById(x);
$("catalog").innerHTML=catalog.map(([icon,name,terms,rule])=>`<article class="item"><strong>${icon} ${name}</strong><span class="muted">${terms}</span><p class="muted">${rule}</p></article>`).join("");
const record=()=>`PARCEL/0.1
OBSERVATION "elemental query"
SUBJECT "frontpage catalog"
CLAIM ${JSON.stringify($("query").value)}
CLASS HYPOTHESIS
EVIDENCE "catalog/elements.json"
REPAIR "Resolve each query into typed claims; attach units and source for physical measurements."
CHECK "evidence-and-unit-validation" EXPECT NOT_RUN
POSITIVE "The taxonomy can help discover overlooked relationships."
REBUKE "A poetic label must not be mistaken for measured reality."
REALITY "Unknown and unsupported units remain visible as UNKNOWN."
RETURN "frontpage"
END`;
function render(){ $("parcel").textContent=record(); }
$("query").addEventListener("input",render);$("copy").addEventListener("click",async()=>{try{await navigator.clipboard.writeText(record());$("status").textContent="Copied."}catch{$("status").textContent="Clipboard unavailable; select the record to copy."}});render();