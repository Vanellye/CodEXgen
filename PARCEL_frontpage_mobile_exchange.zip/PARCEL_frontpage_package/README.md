# PARCEL Frontpage Package

Open `mobile-fixture/index.html` in a browser for the local mobile observation console.

- `FRONTPAGE.md` — purpose, lifecycle, elemental catalog and migration policy
- `parcel/PARCEL-SPEC.md` — grammar and semantic constraints
- `parcel/parcel-parser.mjs` — strict, non-executing reference parser
- `parcel/EXAMPLE.parcel` — sample observation
- `catalog/elements.json` — water/air/earth/fire/ether/excedra taxonomy
- `observations/repair-ledger.json` — reality-classified example findings
- `vectors/parcel-conformance.json` — positive and negative parser cases
- `mobile-fixture/` — responsive local browser fixture

This is a prototype package. The parser is a JavaScript reference implementation of the PARCEL language, not a claim that all legacy JavaScript/Python/C/Kotlin tests have already been replaced. Repository migration and remote writes remain pending explicit implementation and verified access.
