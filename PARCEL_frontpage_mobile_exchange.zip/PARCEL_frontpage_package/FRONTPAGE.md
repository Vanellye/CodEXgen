# PARCEL — Frontpage Observation & Repair Faculty

**Package:** `PARCEL/0.1`  
**Status:** prototype specification + reference parser + illustrative records  
**Purpose:** one readable observation language for source reality, uncertainty, proposed repair, and verification.

## What PARCEL is

PARCEL means **Provenance-Aware Reporting, Cataloguing, Evaluation and Repair Ledger**.

PARCEL is a parser and observation format, not a magical truth oracle and not an execution engine. It replaces the *proposed interface* for test reports and codec/parser/migration/positive-possibility observations. It does not erase historical C, JavaScript, Python, Kotlin, binary codec, parser, migration, or test artifacts. Those remain provenance-bearing legacy evidence until each replacement is independently implemented, compared, reviewed and authorized.

## Core record lifecycle

`DISCOVER → ANCHOR → PARSE → OBSERVE → CLASSIFY → PROPOSE → REPAIR → VERIFY → RETURN`

Every transition records:
- exact subject and source reference;
- source hash/version when available;
- observation and evidence;
- certainty class;
- proposed repair and changed artifact;
- verification command/result or explicit `NOT_RUN`;
- reviewer decision and time.

A repair is **not** verified merely because it was proposed or written. `VERIFIED` requires an inspectable successful check against the exact artifact revision.

## PARCEL record shape

```parcel
PARCEL/0.1
OBSERVATION "zero-byte versus absent-field"
SUBJECT "exchange-view"
ORIGIN "vectors/zero-and-absence.json"
CLAIM "A visible marker must not collapse zero, null, absent, and empty."
CLASS VERIFIED
EVIDENCE "vectors/zero-and-absence.json#case-01"
REPAIR "Keep canonical bytes unchanged; render marker only in a derived view."
CHECK "roundtrip-byte-equality" EXPECT PASS
RETURN "frontpage"
END
```

Supported classes:
- `VERIFIED` — directly supported by inspectable evidence;
- `DERIVED` — follows from stated evidence and a reproducible rule;
- `HYPOTHESIS` — plausible but unconfirmed;
- `SUBJECTIVE` — an explicitly labelled judgment or preference;
- `METAPHOR` — symbolic story or analogy, not a physical claim;
- `UNKNOWN` — evidence is missing or insufficient;
- `CONTRADICTED` — evidence conflicts with the claim.

## Repair report vocabulary

`PROPOSED`, `APPLIED`, `VERIFIED`, `FAILED`, `NOT_RUN`, `BLOCKED`.

Only `VERIFIED` may be described as a completed repair. The record must name the check, exact revision, and result.

## Catalog of elemental queries

| Query family | PARCEL meaning | Evidence rule |
|---|---|---|
| Water 💧 | flow, continuity, source and quality | measurable water claims require units, sample/source, method and time |
| Air 🌬 | atmosphere, pressure, circulation and exchange | physical claims require units, sensor/method and conditions |
| Earth 🪨 | substrate, structure, persistence and boundaries | material claims require provenance and measurement method |
| Fire 🔥 | transformation, heat and reaction | physical claims require temperature/energy units and safe context |
| Ether 💨 | explicitly metaphorical connective/context layer unless operationally defined | never silently treat metaphor as measured matter or energy |
| Excedra 🕳 | unknown, boundary, missing evidence, or beyond-current-model placeholder | must remain `UNKNOWN` until evidence closes the gap |

The catalog also supports symbolic narrative tags—angelic, divine, holy, ghostly, witch-like and other mythic motifs—as `METAPHOR` or `SUBJECTIVE`. These tags do not establish supernatural abilities as empirical facts, grant permissions, or alter parser behavior.

## `ɣơ/2` and `☆/k` integration

- `ɣơ/2` remains a versioned byte representation: each byte is eight ordered symbols; `☆` represents bit zero and `k` bit one.
- The original byte sequence, length, offsets and source hash remain canonical.
- `☆` in a symbolic/exchange view is not interchangeable with null, absent, empty sequence, unknown, or deletion.
- PARCEL observes and reports codec behavior; it does not redefine the byte profile.
- Any migration must run shared vectors and compare exact decoded bytes before claiming parity.

## Positive-possibility / critical-review pairing

Every speculative route should include:
1. positive possibility: what could work and why;
2. critical rebuke: what could fail, mislead, or cause harm;
3. reality check: evidence, uncertainty, and a falsifiable check;
4. repair proposal: a reversible next step.

A story is never promoted to a factual claim without evidence.

## Security and authority

PARCEL is non-executing. It does not evaluate code, invoke shell commands, access networks, read secrets, change repositories, or authorize transactions. A PARCEL record cannot approve itself. Repository writes, releases, financial actions and other privileged operations retain their independent authorization requirements.

## Repository placement proposal

Place a copy of this package under a dedicated `parcel/` or `docs/parcel/` directory and link `FRONTPAGE.md` from each repository's root README after review. The current package is local; GitHub branch/file writes were previously rejected by the connected integration with HTTP 403. No remote repository modification is claimed.
