# ERIA Recovery Manager (v1)

A local recovery utility for ERIA repositories and application data. It supports real, reversible quarantine and hash-verified restoration. It deliberately refuses permanent purge until a real PONS verifier is integrated.

## Safety boundaries

- Operates only on paths under the current user's home directory.
- `quarantine` and `restore` are dry-run by default; `--confirm` is required to move data.
- Quarantine records file SHA-256 hashes, symlink targets, original paths, and an audit event in `~/.local/share/eria-recovery/` (override with `ERIA_RECOVERY_HOME`).
- Restore refuses to overwrite an existing destination and verifies contents before and after moving.
- Purge is blocked. A string, environment variable, or CLI flag is not accepted as PONS authorization.
- This is a local single-user tool, not yet a distributed or cryptographically tamper-evident audit service. Back up the recovery vault separately.

## Termux setup

```bash
pkg install python -y
mkdir -p ~/tools/eria-recovery
cp eria_recovery.py ~/tools/eria-recovery/
chmod 700 ~/tools/eria-recovery/eria_recovery.py
```

## Commands

```bash
python ~/tools/eria-recovery/eria_recovery.py list
python ~/tools/eria-recovery/eria_recovery.py quarantine ~/ERIA-PANTHEON-BRIDGE
# Inspect the dry-run output, then explicitly move it:
python ~/tools/eria-recovery/eria_recovery.py quarantine ~/ERIA-PANTHEON-BRIDGE --confirm

# Restore by recovery ID:
python ~/tools/eria-recovery/eria_recovery.py restore RECOVERY_ID
python ~/tools/eria-recovery/eria_recovery.py restore RECOVERY_ID --confirm

# Purge intentionally refuses until PONS verification is integrated:
python ~/tools/eria-recovery/eria_recovery.py purge RECOVERY_ID
```

## Important for existing detached-HEAD work

Quarantining the whole `ERIA-PANTHEON-BRIDGE` directory moves the working tree, including `.git` and uncommitted modifications, into the vault. It does not create a Git branch or commit. Do not quarantine the repository while Gradle, Git, or an editor is using it. Keep a separate copy of the recovery vault.

Before moving the two modified Kotlin files individually, inspect their exact paths and ensure no build/editor process is writing them. Quarantine one path at a time.

## PONS integration required before purge

The PONS adapter must verify a signed, identity-pinned approval bound to the recovery ID, manifest digest, exact target, operation `PURGE`, expiry, and a unique nonce. It must reject replay, scope mismatch, stale approvals, missing trust anchors, and any verifier error. Human approval must be a separate explicit step. Until that adapter is implemented and independently tested, purge remains disabled.
