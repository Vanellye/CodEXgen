#!/usr/bin/env python3
"""ERIA Recovery Manager: reversible quarantine and verified restore.

Purge is intentionally fail-closed until a real, pinned PONS verifier is integrated.
No shell commands are used to manipulate user paths.
"""
from __future__ import annotations
import argparse, hashlib, json, os, shutil, sys, uuid
from datetime import datetime, timezone
from pathlib import Path

APP = "ERIA Recovery Manager"
VAULT = Path(os.environ.get("ERIA_RECOVERY_HOME", Path.home() / ".local" / "share" / "eria-recovery")).expanduser()
OBJECTS = VAULT / "objects"
MANIFESTS = VAULT / "manifests"
AUDIT = VAULT / "audit.jsonl"


def now(): return datetime.now(timezone.utc).isoformat()
def sha_bytes(b: bytes) -> str: return hashlib.sha256(b).hexdigest()
def ensure_vault():
    OBJECTS.mkdir(parents=True, exist_ok=True)
    MANIFESTS.mkdir(parents=True, exist_ok=True)
    try: VAULT.chmod(0o700)
    except OSError: pass

def audit(event, **fields):
    ensure_vault()
    record = {"time": now(), "event": event, **fields}
    with AUDIT.open("a", encoding="utf-8") as f:
        f.write(json.dumps(record, sort_keys=True) + "\n")
    try: AUDIT.chmod(0o600)
    except OSError: pass

def within_home(p: Path) -> bool:
    try: p.resolve(strict=True).relative_to(Path.home().resolve())
    except (ValueError, FileNotFoundError): return False
    return True

def file_hash(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""): h.update(chunk)
    return h.hexdigest()

def inventory(root: Path):
    """Inventory regular files and symlinks without following symlinks."""
    rows = []
    if root.is_symlink():
        return [{"path": ".", "kind": "symlink", "target": os.readlink(root)}]
    if root.is_file():
        return [{"path": ".", "kind": "file", "sha256": file_hash(root), "size": root.stat().st_size}]
    for base, dirs, files in os.walk(root, followlinks=False):
        bp = Path(base)
        dirs[:] = sorted(d for d in dirs if not (bp / d).is_symlink())
        for name in sorted(dirs + files):
            p = bp / name
            rel = p.relative_to(root).as_posix()
            if p.is_symlink(): rows.append({"path": rel, "kind": "symlink", "target": os.readlink(p)})
            elif p.is_file(): rows.append({"path": rel, "kind": "file", "sha256": file_hash(p), "size": p.stat().st_size})
            elif p.is_dir(): rows.append({"path": rel, "kind": "directory"})
    return rows

def verify_inventory(root: Path, rows):
    for row in rows:
        p = root if row["path"] == "." else root / row["path"]
        kind = row["kind"]
        if kind == "file":
            if not p.is_file() or p.is_symlink() or file_hash(p) != row["sha256"]: return False, row["path"]
        elif kind == "symlink":
            if not p.is_symlink() or os.readlink(p) != row["target"]: return False, row["path"]
        elif kind == "directory" and not p.is_dir(): return False, row["path"]
    return True, None

def manifest_path(aid): return MANIFESTS / f"{aid}.json"
def load_manifest(aid):
    p = manifest_path(aid)
    if not p.is_file(): raise ValueError(f"Unknown recovery ID: {aid}")
    data = json.loads(p.read_text(encoding="utf-8"))
    if data.get("id") != aid: raise ValueError("Manifest ID mismatch")
    return data

def cmd_quarantine(args):
    src = Path(args.path).expanduser()
    if not src.exists() and not src.is_symlink(): raise ValueError("Source does not exist")
    if not within_home(src): raise ValueError("Refusing paths outside the user's home directory")
    src = src.resolve(strict=True)
    if src == Path.home().resolve() or src == VAULT.resolve(): raise ValueError("Refusing home or vault root")
    if VAULT in src.parents: raise ValueError("Source is already inside the recovery vault")
    if not args.confirm:
        print("DRY RUN: would quarantine:", src)
        print("Re-run with --confirm to move it into the recovery vault.")
        return
    ensure_vault()
    aid = uuid.uuid4().hex
    dest = OBJECTS / aid
    rows = inventory(src)
    manifest = {"schema": 1, "id": aid, "created_at": now(), "state": "prepared", "original_path": str(src), "object_path": str(dest), "inventory": rows, "inventory_sha256": sha_bytes(json.dumps(rows, sort_keys=True, separators=(",", ":")).encode())}
    mp = manifest_path(aid)
    mp.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    try:
        shutil.move(str(src), str(dest))
        ok, bad = verify_inventory(dest, rows)
        if not ok: raise RuntimeError(f"Post-move integrity check failed at {bad}")
        manifest["state"] = "quarantined"
        manifest["quarantined_at"] = now()
        mp.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        audit("QUARANTINE_SUCCESS", id=aid, original_path=str(src), object_path=str(dest), entries=len(rows))
    except Exception:
        # Best-effort rollback only if the original path is still free.
        if dest.exists() or dest.is_symlink():
            if not src.exists() and not src.is_symlink(): shutil.move(str(dest), str(src))
        manifest["state"] = "quarantine_failed_or_rolled_back"
        mp.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        audit("QUARANTINE_FAILED", id=aid, original_path=str(src))
        raise
    print(f"QUARANTINED: {aid}\nRestore with: python eria_recovery.py restore {aid} --confirm")

def cmd_restore(args):
    m = load_manifest(args.id)
    if m.get("state") != "quarantined": raise ValueError(f"Cannot restore from state: {m.get('state')}")
    obj = Path(m["object_path"])
    target = Path(args.to).expanduser() if args.to else Path(m["original_path"])
    if target.exists() or target.is_symlink(): raise ValueError(f"Restore target already exists: {target}")
    if not within_home(target.parent): raise ValueError("Restore target must be under the user's home directory")
    ok, bad = verify_inventory(obj, m["inventory"])
    if not ok: raise ValueError(f"Quarantine integrity check failed at {bad}; refusing restore")
    if not args.confirm:
        print(f"DRY RUN: would restore {args.id} to {target}\nRe-run with --confirm to restore.")
        return
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(obj), str(target))
    ok, bad = verify_inventory(target, m["inventory"])
    if not ok:
        raise RuntimeError(f"Restored data failed integrity check at {bad}; inspect {target}")
    m["state"] = "restored"
    m["restored_at"] = now()
    m["restored_path"] = str(target)
    manifest_path(args.id).write_text(json.dumps(m, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    audit("RESTORE_SUCCESS", id=args.id, restored_path=str(target))
    print(f"RESTORED AND VERIFIED: {target}")

def cmd_list(_args):
    ensure_vault()
    found = False
    for p in sorted(MANIFESTS.glob("*.json")):
        try:
            m = json.loads(p.read_text(encoding="utf-8"))
            print(f"{m.get('id')}  {m.get('state')}  {m.get('original_path')}")
            found = True
        except Exception: print(f"INVALID MANIFEST: {p}")
    if not found: print("No recovery records yet.")

def cmd_purge(args):
    # Deliberately not wired to a user-supplied boolean or environment variable.
    audit("PURGE_DENIED_NO_VERIFIER", id=args.id)
    raise PermissionError("PURGE BLOCKED: no independently verified PONS authorization adapter is configured. No data was deleted. A signed, identity-pinned PONS receipt and human confirmation workflow must be integrated before purge can be enabled.")

def main():
    ap = argparse.ArgumentParser(prog="eria-recovery", description=APP)
    sub = ap.add_subparsers(dest="cmd", required=True)
    q = sub.add_parser("quarantine", help="Move an ERIA path into recoverable quarantine")
    q.add_argument("path"); q.add_argument("--confirm", action="store_true"); q.set_defaults(func=cmd_quarantine)
    r = sub.add_parser("restore", help="Restore a quarantined item after hash verification")
    r.add_argument("id"); r.add_argument("--to"); r.add_argument("--confirm", action="store_true"); r.set_defaults(func=cmd_restore)
    l = sub.add_parser("list", help="List recovery records"); l.set_defaults(func=cmd_list)
    p = sub.add_parser("purge", help="Request permanent purge (PONS-gated; currently disabled)")
    p.add_argument("id"); p.set_defaults(func=cmd_purge)
    args = ap.parse_args()
    try: args.func(args)
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr); return 2
    return 0

if __name__ == "__main__": raise SystemExit(main())
