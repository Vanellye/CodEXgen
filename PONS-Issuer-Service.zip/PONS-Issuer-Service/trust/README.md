# Trust configuration
For development, after key generation, copy the public key into `trust/dev_trust.json`:
```json
{"trusted_issuers":{"pons-dev-key-01":{"environment":"DEVELOPMENT_ONLY","public_key_pem":"<contents of state/dev_issuer_public.pem>"}}}
```
This is local self-trust for testing, not independent PONS trust. Production trust must be provisioned out-of-band by the real PONS authority.
