import unittest,tempfile,json,subprocess,sys
from pathlib import Path
class PackageSmoke(unittest.TestCase):
 def test_cli_help(self):
  r=subprocess.run([sys.executable,"-m","pons_issuer","--help"],capture_output=True,text=True)
  self.assertEqual(r.returncode,0,r.stderr)
 def test_request_scope(self):
  r=json.loads(Path("fixtures/request.json").read_text())
  self.assertEqual(r["repositories"],["Vanellye/Ash","Vanellye/CodEXgen"])
  self.assertNotIn("live_swaps",r["operations"])
if __name__=="__main__": unittest.main()
