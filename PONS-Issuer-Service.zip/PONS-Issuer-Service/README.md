# PONS Issuer Service — development prototype

**Not a real PONS authority. No repository writes or financial execution.**

This Termux-compatible package contains:
- local Ed25519 development key generation;
- explicit CLI approval-envelope signing;
- signed payload binding to exact repositories, operations, request digest, scope and exclusions;
- Ed25519 verification against an out-of-band configured public key;
- expiry and nonce replay checks.

The local CLI `issue` command is a development demonstration. A typed issuer/approver name is not identity authentication; it is not adequate production human approval. Do not use this to approve real repository writes, transfers, swaps, trading, or deployments.

## Termux setup
```sh
pkg update -y
pkg install python unzip -y
unzip PONS-Issuer-Service.zip
cd PONS-Issuer-Service
python -m pip install -r requirements.txt
```

## Generate a development key
```sh
python -m pons_issuer keygen
```
Keep `state/dev_issuer_private.pem` private. Never upload or share it.

## Create a development-only signed approval
```sh
python -m pons_issuer issue --issuer "LOCAL DEVELOPMENT ISSUER" --approver "LOCAL TEST APPROVER"
```

## Configure local test trust
Copy the contents of `state/dev_issuer_public.pem` into `trust/dev_trust.json`:
```json
{"trusted_issuers":{"pons-dev-key-01":{"environment":"DEVELOPMENT_ONLY","public_key_pem":"PASTE_PUBLIC_KEY_PEM_HERE"}}}
```

## Verify
```sh
python -m pons_verifier state/dev_approval.json --trust trust/dev_trust.json --ledger state/used_nonces.sqlite3 --request fixtures/request.json
```
First verification succeeds as `DEVELOPMENT_SIGNATURE_VALID_NON_AUTHORIZING`; a second attempt rejects replay.

## Production requirements
A real PONS authority must authenticate issuer and approver identities, protect signing keys in HSM/KMS, publish trusted key fingerprints through an independent channel, support revocation, use a durable replay store, bind approvals to immutable commit IDs and exact payload digests, and enforce authorization inside the GitHub write adapter. Financial execution requires a separate authorization path. This prototype deliberately refuses production-environment envelopes.
