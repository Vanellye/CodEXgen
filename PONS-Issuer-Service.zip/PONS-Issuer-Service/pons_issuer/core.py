import argparse, base64, hashlib, json, os, secrets
from datetime import datetime, timezone, timedelta
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization

REPOS = ["Vanellye/Ash", "Vanellye/CodEXgen"]
OPS = ["create_isolated_branches", "write_scoped_files", "run_tests", "prepare_pull_requests"]

def canonical(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode()

def digest_file(path):
    return hashlib.sha256(canonical(json.loads(Path(path).read_text()))).hexdigest()

def generate_keypair(private_path, public_path):
    private_path, public_path = Path(private_path), Path(public_path)
    if private_path.exists() or public_path.exists():
        raise FileExistsError("Refusing to overwrite an existing key. Back it up and choose new paths.")
    private_path.parent.mkdir(parents=True, exist_ok=True)
    public_path.parent.mkdir(parents=True, exist_ok=True)
    key = Ed25519PrivateKey.generate()
    private_path.write_bytes(key.private_bytes(serialization.Encoding.PEM,
        serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
    os.chmod(private_path, 0o600)
    public_path.write_bytes(key.public_key().public_bytes(
        serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo))
    return private_path, public_path

def issue_approval(request_path, private_key_path, key_id, issuer, approver, out_path, lifetime_hours=2):
    # Explicit local CLI invocation is the human action in this development prototype.
    req=json.loads(Path(request_path).read_text())
    if req.get("repositories") != REPOS or req.get("operations") != OPS:
        raise ValueError("Request repositories or operation allow-list differs from the reviewed template")
    if req.get("exclusions") is None:
        raise ValueError("Request must explicitly declare excluded operations")
    key=serialization.load_pem_private_key(Path(private_key_path).read_bytes(),password=None)
    if not isinstance(key, Ed25519PrivateKey):
        raise ValueError("Issuer key must be Ed25519")
    now=datetime.now(timezone.utc)
    payload={
      "schema":"pons.approval.v1",
      "environment":"DEVELOPMENT_ONLY",
      "approval_id":"PONS-DEV-"+secrets.token_hex(12),
      "request_id":req["request_id"],
      "request_digest":digest_file(request_path),
      "issuer":issuer,
      "approver":approver,
      "issued_at":now.isoformat(),
      "expires_at":(now+timedelta(hours=lifetime_hours)).isoformat(),
      "repositories":REPOS,
      "operations":OPS,
      "human_approval":True,
      "nonce":secrets.token_hex(24),
      "scope":req["scope"],
      "exclusions":req["exclusions"]
    }
    signature=base64.b64encode(key.sign(canonical(payload))).decode()
    envelope={"payload":payload,"signature":{"alg":"Ed25519","key_id":key_id,"value":signature}}
    out=Path(out_path); out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(envelope,indent=2)+"\n")
    os.chmod(out,0o600)
    return envelope
