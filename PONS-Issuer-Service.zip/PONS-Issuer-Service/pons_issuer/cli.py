import argparse, json
from .core import generate_keypair, issue_approval

p=argparse.ArgumentParser(description="PONS development issuer prototype — not a production authority")
sub=p.add_subparsers(dest="cmd",required=True)
g=sub.add_parser("keygen"); g.add_argument("--private",default="state/dev_issuer_private.pem"); g.add_argument("--public",default="state/dev_issuer_public.pem")
i=sub.add_parser("issue"); i.add_argument("--request",default="fixtures/request.json")
i.add_argument("--private",default="state/dev_issuer_private.pem"); i.add_argument("--key-id",default="pons-dev-key-01")
i.add_argument("--issuer",required=True); i.add_argument("--approver",required=True)
i.add_argument("--out",default="state/dev_approval.json"); i.add_argument("--hours",type=int,default=2)
a=p.parse_args()
if a.cmd=="keygen":
    prv,pub=generate_keypair(a.private,a.public)
    print(json.dumps({"private_key":str(prv),"public_key":str(pub),"warning":"DEVELOPMENT ONLY. Protect private key. This does not establish production trust."},indent=2))
else:
    if not 1 <= a.hours <= 24: p.error("--hours must be 1..24")
    env=issue_approval(a.request,a.private,a.key_id,a.issuer,a.approver,a.out,a.hours)
    print(json.dumps({"approval_file":a.out,"approval_id":env["payload"]["approval_id"],
      "environment":"DEVELOPMENT_ONLY","warning":"Local demo signature only; not a real PONS authorization."},indent=2))
