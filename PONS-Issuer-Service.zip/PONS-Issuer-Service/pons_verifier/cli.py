import argparse,json,sys
from .core import verify
p=argparse.ArgumentParser(); p.add_argument("envelope")
p.add_argument("--trust",required=True); p.add_argument("--ledger",required=True); p.add_argument("--request",required=True)
a=p.parse_args(); ok,msg=verify(a.envelope,a.trust,a.ledger,a.request)
print(json.dumps({"verified":ok,"result":msg,"authorization_granted":False},indent=2))
sys.exit(0 if ok else 2)
