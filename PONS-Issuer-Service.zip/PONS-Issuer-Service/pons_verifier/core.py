import base64, hashlib, json, sqlite3
from pathlib import Path
from datetime import datetime, timezone
from cryptography.hazmat.primitives.serialization import load_pem_public_key
from cryptography.exceptions import InvalidSignature
REPOS=["Vanellye/Ash","Vanellye/CodEXgen"]
OPS=["create_isolated_branches","write_scoped_files","run_tests","prepare_pull_requests"]
def canonical(o): return json.dumps(o,sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False).encode()
def digest(path): return hashlib.sha256(canonical(json.loads(Path(path).read_text()))).hexdigest()
def verify(envelope_path,trust_path,ledger_path,request_path):
    try:
        e=json.loads(Path(envelope_path).read_text()); p=e["payload"]; s=e["signature"]
        t=json.loads(Path(trust_path).read_text())["trusted_issuers"][s["key_id"]]
        if p.get("schema")!="pons.approval.v1": return False,"unsupported schema"
        if p.get("environment")!="DEVELOPMENT_ONLY" or t.get("environment")!="DEVELOPMENT_ONLY":
            return False,"this prototype only verifies DEVELOPMENT_ONLY envelopes"
        if s.get("alg")!="Ed25519": return False,"unsupported signature algorithm"
        load_pem_public_key(t["public_key_pem"].encode()).verify(base64.b64decode(s["value"],validate=True),canonical(p))
        if p.get("repositories")!=REPOS: return False,"repository scope mismatch"
        if p.get("operations")!=OPS: return False,"operation scope mismatch"
        if p.get("request_digest")!=digest(request_path): return False,"request digest mismatch"
        if p.get("human_approval") is not True: return False,"human approval claim missing"
        for k in ["approval_id","request_id","issuer","approver","nonce","issued_at","expires_at"]:
            if not isinstance(p.get(k),str) or not p[k].strip(): return False,"missing "+k
        issued=datetime.fromisoformat(p["issued_at"].replace("Z","+00:00"))
        expires=datetime.fromisoformat(p["expires_at"].replace("Z","+00:00")); now=datetime.now(timezone.utc)
        if issued.tzinfo is None or expires.tzinfo is None or issued>now or expires<=now: return False,"invalid or expired validity"
        db=Path(ledger_path); db.parent.mkdir(parents=True,exist_ok=True)
        with sqlite3.connect(db,timeout=10) as con:
            con.execute("CREATE TABLE IF NOT EXISTS used(nonce TEXT PRIMARY KEY, approval_id TEXT UNIQUE, consumed_at TEXT)")
            try: con.execute("INSERT INTO used VALUES(?,?,?)",(p["nonce"],p["approval_id"],now.isoformat())); con.commit()
            except sqlite3.IntegrityError: return False,"replay detected"
        return True,"DEVELOPMENT_SIGNATURE_VALID_NON_AUTHORIZING"
    except InvalidSignature: return False,"invalid Ed25519 signature"
    except Exception as ex: return False,"rejected: "+type(ex).__name__+": "+str(ex)
