# Proposed isolated branch plan — NOT CREATED
- `Vanellye/Ash`: `feature/pons-issuer-ed25519-finance-gates`
- `Vanellye/CodEXgen`: `feature/pons-issuer-ed25519-pantheon-gates`

Protect `main`. Create branches only after real PONS authorization is independently verified.
Use separate PRs, require review, run tests, and record source commit SHA plus approval request digest.
This package does not create or push Git branches.
