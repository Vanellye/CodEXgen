package plan
import "testing"
func TestPlanIsReadOnly(t *testing.T) {
 p,e:=Build(Request{Repository:"Vanellye/CodEXgen",Target:"finance-go-dotnet"})
 if e!=nil { t.Fatal(e) }; if p.Mode!="plan-only" || len(p.Blocked)==0 { t.Fatal("expected plan-only safety boundary") }
}
func TestRejectBadRepo(t *testing.T) { if _,e:=Build(Request{Repository:"bad",Target:"finance-go-dotnet"}); e==nil { t.Fatal("expected error") } }
