package plan

import ("errors"; "regexp"; "time")
type Request struct { Repository string `json:"repository"`; Target string `json:"target"` }
type Plan struct {
 Agent string `json:"agent"`
 Repository string `json:"repository"`
 Target string `json:"target"`
 Mode string `json:"mode"`
 CreatedUTC string `json:"created_utc"`
 Steps []string `json:"steps"`
 Blocked []string `json:"blocked"`
}
var repoPattern = regexp.MustCompile(`^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$`)
func Build(r Request) (Plan,error) {
 if !repoPattern.MatchString(r.Repository) { return Plan{}, errors.New("repository must be owner/name") }
 if r.Target!="finance-go-dotnet" && r.Target!="agent-infrastructure" { return Plan{}, errors.New("unsupported target") }
 return Plan{Agent:"ERIA Forge Agent",Repository:r.Repository,Target:r.Target,Mode:"plan-only",CreatedUTC:time.Now().UTC().Format(time.RFC3339),
 Steps:[]string{"Inspect repository read-only","Prepare Go and .NET 10 finance work plans","Check IBAN syntax and MOD-97 test coverage","Run tests and produce evidence","Request scoped PONS approval before any write","Wait for human review; never merge or deploy automatically"},
 Blocked:[]string{"Repository writes disabled","Branch creation, commits, pushes and merges disabled","Financial transfers unsupported","PONS approval unverified; fail-closed"}},nil
}
