package approval

import ("context"; "testing")
func TestFailClosed(t *testing.T) {
 r := (FailClosedVerifier{}).Check(context.Background(), Request{Repository:"Vanellye/CodEXgen", Operation:"write"})
 if r.Allowed { t.Fatal("must deny without PONS verification") }
}
