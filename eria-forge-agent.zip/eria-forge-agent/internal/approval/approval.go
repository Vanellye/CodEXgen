package approval

import "context"

type Request struct {
 Repository string
 Branch string
 Operation string
 Digest string
}
type Result struct { Allowed bool `json:"allowed"`; Reason string `json:"reason"` }
type Verifier interface { Check(context.Context, Request) Result }

// FailClosedVerifier denies every operation until an authoritative PONS
// verifier is implemented and independently configured.
type FailClosedVerifier struct{}
func (FailClosedVerifier) Check(context.Context, Request) Result {
 return Result{Allowed:false, Reason:"PONS verifier is not configured; authorization denied"}
}
