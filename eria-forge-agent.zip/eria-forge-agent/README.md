# ERIA Forge Agent

Multi-runtime starter:
- GitHub Actions: PR/manual runs tests and creates a safe plan.
- Fly.io: persistent HTTP control plane (`/health`, `/v1/status`, `/v1/plan`).
- Termux: Android CLI builds and runs locally.

**Safety:** this starter is plan-only. It cannot write to repositories, create branches, commit, push, merge, deploy, access bank accounts, or transfer funds. PONS verification is deliberately fail-closed until connected to an authoritative verifier. An environment variable or chat confirmation is not proof of PONS approval.

Build/test (Go 1.23+):
```sh
go test ./...
go build ./cmd/eria-forge-agent
go build ./cmd/eria-forge-agentctl
```

Termux:
```sh
pkg update && pkg install golang
unzip eria-forge-agent.zip && cd eria-forge-agent
go test ./...
go build -o $PREFIX/bin/eria-forge-agentctl ./cmd/eria-forge-agentctl
eria-forge-agentctl plan --repo Vanellye/CodEXgen --target finance-go-dotnet
```

Fly.io (after reviewing the threat model and replacing the placeholder app):
```sh
fly launch --no-deploy
fly secrets set ERIA_AGENT_TOKEN="$(openssl rand -hex 32)"
fly deploy
```

Local API:
```sh
export ERIA_AGENT_TOKEN="$(openssl rand -hex 32)"
go run ./cmd/eria-forge-agent
```
Then POST JSON `{"repository":"Vanellye/CodEXgen","target":"finance-go-dotnet"}` to `/v1/plan` with `Authorization: Bearer $ERIA_AGENT_TOKEN`.

GitHub Actions uses read-only permissions and runs tests/plan generation only.

Before enabling any write action, implement a real PONS verifier that validates a signed, scoped, unexpired, non-replayed approval bound to repository, branch, operation and content digest. Require human review. IBAN MOD-97 validates checksum consistency only—not ownership, account existence, access or transfer permission. No banking operation is included.
