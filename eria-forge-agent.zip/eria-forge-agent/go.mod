module github.com/Vanellye/eria-forge-agent
go 1.23
