package main
import ("encoding/json"; "flag"; "fmt"; "os"; "github.com/Vanellye/eria-forge-agent/internal/plan")
func main() {
 if len(os.Args)<2 || os.Args[1]!="plan" { fmt.Fprintln(os.Stderr,"usage: eria-forge-agentctl plan --repo owner/name --target finance-go-dotnet"); os.Exit(2) }
 f:=flag.NewFlagSet("plan",flag.ExitOnError); repo:=f.String("repo","","GitHub owner/name"); target:=f.String("target","finance-go-dotnet","target"); _=f.Parse(os.Args[2:])
 p,e:=plan.Build(plan.Request{Repository:*repo,Target:*target}); if e!=nil { fmt.Fprintln(os.Stderr,e); os.Exit(1) }
 enc:=json.NewEncoder(os.Stdout); enc.SetIndent("","  "); _=enc.Encode(p)
}
