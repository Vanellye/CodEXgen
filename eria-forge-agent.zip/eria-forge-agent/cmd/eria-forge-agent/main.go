package main
import ("encoding/json"; "log"; "net/http"; "os"; "strings"; "github.com/Vanellye/eria-forge-agent/internal/approval"; "github.com/Vanellye/eria-forge-agent/internal/plan")
func main() {
 token:=os.Getenv("ERIA_AGENT_TOKEN"); mux:=http.NewServeMux()
 mux.HandleFunc("GET /health",func(w http.ResponseWriter,r *http.Request){write(w,200,map[string]any{"ok":true,"mode":"plan-only"})})
 mux.Handle("GET /v1/status",auth(token,http.HandlerFunc(func(w http.ResponseWriter,r *http.Request){
  v:=approval.FailClosedVerifier{}; write(w,200,map[string]any{"mode":"plan-only","repository_writes_enabled":false,"authorization_check":v.Check(r.Context(),approval.Request{})})
 })))
 mux.Handle("POST /v1/plan",auth(token,http.HandlerFunc(func(w http.ResponseWriter,r *http.Request){
  var q plan.Request; if e:=json.NewDecoder(http.MaxBytesReader(w,r.Body,16384)).Decode(&q); e!=nil {write(w,400,map[string]string{"error":"invalid JSON"});return}
  p,e:=plan.Build(q); if e!=nil {write(w,400,map[string]string{"error":e.Error()});return}; write(w,200,p)
 })))
 port:=os.Getenv("PORT"); if port=="" {port="8787"}; if !strings.HasPrefix(port,":"){port=":"+port}
 log.Printf("ERIA Forge Agent plan-only API on %s",port); log.Fatal(http.ListenAndServe(port,mux))
}
func auth(token string,next http.Handler) http.Handler { return http.HandlerFunc(func(w http.ResponseWriter,r *http.Request){
 if token=="" {write(w,503,map[string]string{"error":"ERIA_AGENT_TOKEN is not configured"});return}
 if r.Header.Get("Authorization")!="Bearer "+token {write(w,401,map[string]string{"error":"unauthorized"});return}; next.ServeHTTP(w,r)
})}
func write(w http.ResponseWriter,s int,v any){w.Header().Set("Content-Type","application/json");w.WriteHeader(s);_=json.NewEncoder(w).Encode(v)}
