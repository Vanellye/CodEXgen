# ERIA Pantheon NEW + FaCADE `ctypes` Bridge

This package binds the existing native C99 functions `new_build_narrative` and
`facade_build_correction` to Python through `ctypes`. It is a proposal-generation
adapter only. It does not implement a Pantheon compiler or grant PONS authority.

## Layout

- `pantheon/NEW/native/build.sh` — builds a shared library from the existing C99
  `NEW.c` and `FaCADE.c` files in an ERIA repository checkout.
- `pantheon/NEW/python/eria_pantheon/native_bridge.py` — typed `ctypes` structures,
  argument validation, native status mapping, and proposal builders.
- `tests/test_native_bridge.py` — denial and successful proposal smoke tests.

The build script compiles against the existing C source and headers in the
repository checkout. This package intentionally does not replace those files.

## Termux build

From the repository root, after placing these files under the corresponding paths:

```sh
pkg install clang python -y
chmod +x pantheon/NEW/native/build.sh
./pantheon/NEW/native/build.sh
```

## Termux use

```sh
export PYTHONPATH="$PWD/pantheon/NEW/python${PYTHONPATH:+:$PYTHONPATH}"
python -c 'from eria_pantheon import PantheonNativeBridge; b=PantheonNativeBridge(); print(b.capabilities())'
```

Then call `build_narrative({...})` or `build_correction({...})` from Python.
Both authorization booleans default to `False`; native calls will return a denial
until callers explicitly supply `True`. These booleans are **upstream assertions**
only. They are not cryptographically verified PONS grants, do not prove consent,
and must not be used to unlock execution.

## Safety and scope

- No Git, repository, filesystem, network, process, wallet, bank, or hardware writes.
- No PONS approval is created by the bridge.
- No privileged execution is exposed.
- NEW and FaCADE output remains human-reviewable proposal text.
- The C API's booleans are preserved for compatibility but are deliberately
  documented as untrusted assertions.
- A future executor needs a separate signed, exact-scope PONS authorization
  verifier, durable nonce/revocation handling, human confirmation, and an
  independently reviewed execution adapter. This package does not provide those.
