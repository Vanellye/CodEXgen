"""ctypes adapter for the native Pantheon NEW and FaCADE C99 modules.

This adapter produces reviewable text proposals only.  It does not authenticate
PONS approvals, grant capabilities, mutate repositories, access networks, or
execute external actions.  The C APIs' authorization flags are upstream claims,
not cryptographic proof; this module defaults both flags to False.
"""
from __future__ import annotations

import ctypes as C
import os
from pathlib import Path
from typing import Any, Mapping


class NativeBridgeError(RuntimeError):
    """Native library could not be loaded or invoked safely."""


class NativeStatusError(NativeBridgeError):
    def __init__(self, module: str, status: int, meaning: str):
        super().__init__(f"{module} rejected request: {meaning} (status={status})")
        self.module, self.status, self.meaning = module, status, meaning


class NewRecord(C.Structure):
    _fields_ = [
        ("source_id", C.c_char_p),
        ("record_id", C.c_char_p),
        ("permission_basis", C.c_char_p),
        ("purpose", C.c_char_p),
        ("captured_at", C.c_char_p),
        ("provenance_digest", C.c_char_p),
        ("content_summary", C.c_char_p),
        ("proof_reference", C.c_char_p),
        ("proof_method", C.c_char_p),
        ("proof_checked_at", C.c_char_p),
        ("data_class", C.c_int),
        ("evidence_status", C.c_int),
        ("authorization_confirmed", C.c_int),
    ]


class FaCADECorrection(C.Structure):
    _fields_ = [
        ("notice_id", C.c_char_p),
        ("source_record_id", C.c_char_p),
        ("target_record_id", C.c_char_p),
        ("evidence_reference", C.c_char_p),
        ("reason", C.c_char_p),
        ("recorded_at", C.c_char_p),
        ("reviewer_id", C.c_char_p),
        ("relation", C.c_int),
        ("source_authorized", C.c_int),
        ("link_verified", C.c_int),
    ]


NEW_DATA_CLASS = {"unspecified": 0, "public": 1, "consented_aggregate": 2}
NEW_EVIDENCE_STATUS = {
    "unspecified": 0,
    "source_reported": 1,
    "independently_corroborated": 2,
    "hypothesis": 3,
}
FACADE_RELATION = {
    "restores": 1,
    "corrects": 2,
    "supersedes": 3,
    "contradicts": 4,
    "derived_from": 5,
}

_NEW_STATUS = {
    0: "OK",
    1: "invalid input or enum",
    2: "authorization assertion absent",
    3: "unsupported data class",
    4: "provenance fields missing",
    5: "output buffer too small",
    6: "proof reference/method/timestamp missing for corroborated evidence",
}
_FACADE_STATUS = {
    0: "OK",
    1: "invalid input or relation",
    2: "source authorization assertion absent",
    3: "provenance fields missing",
    4: "source/target link is not marked verified",
    5: "output buffer too small",
}


def _text(value: Any, field: str, *, optional: bool = False) -> bytes | None:
    if value is None and optional:
        return None
    if not isinstance(value, str):
        raise TypeError(f"{field} must be a string" + (" or None" if optional else ""))
    if not value and not optional:
        raise ValueError(f"{field} must not be empty")
    if "\x00" in value:
        raise ValueError(f"{field} must not contain NUL")
    return value.encode("utf-8") if value else None


def _bool(value: Any, field: str) -> int:
    if type(value) is not bool:
        raise TypeError(f"{field} must be an explicit boolean")
    return int(value)


class PantheonNativeBridge:
    """Loads liberia_pantheon_native and calls NEW/FaCADE proposal builders."""

    def __init__(self, library: str | os.PathLike[str] | None = None, *, output_capacity: int = 16384):
        if not 256 <= output_capacity <= 1_048_576:
            raise ValueError("output_capacity must be between 256 and 1048576")
        if library is None:
            env = os.environ.get("ERIA_PANTHEON_NATIVE_LIB")
            library = env or (Path(__file__).resolve().parents[2] / "native" / "liberia_pantheon_native.so")
        self.library_path = Path(library).expanduser().resolve()
        if not self.library_path.is_file():
            raise NativeBridgeError(
                f"Native library not found: {self.library_path}. Run the provided build.sh first."
            )
        try:
            self._lib = C.CDLL(str(self.library_path))
        except OSError as exc:
            raise NativeBridgeError(f"Could not load {self.library_path}: {exc}") from exc
        self.output_capacity = output_capacity
        self._configure_signatures()

    def _configure_signatures(self) -> None:
        self._lib.new_build_narrative.argtypes = [C.POINTER(NewRecord), C.c_char_p, C.c_size_t]
        self._lib.new_build_narrative.restype = C.c_int
        self._lib.facade_build_correction.argtypes = [C.POINTER(FaCADECorrection), C.c_char_p, C.c_size_t]
        self._lib.facade_build_correction.restype = C.c_int

    def build_narrative(self, values: Mapping[str, Any]) -> str:
        """Build a NEW narrative. Authorization defaults to False (HOLD)."""
        if not isinstance(values, Mapping):
            raise TypeError("values must be a mapping")
        required = (
            "source_id", "record_id", "permission_basis", "purpose", "captured_at",
            "provenance_digest", "content_summary",
        )
        missing = [k for k in required if k not in values]
        if missing:
            raise ValueError("Missing NEW fields: " + ", ".join(missing))
        optional = ("proof_reference", "proof_method", "proof_checked_at")
        # Keep all encoded bytes alive for the duration of the native call.
        encoded = {k: _text(values[k], k) for k in required}
        encoded.update({k: _text(values.get(k), k, optional=True) for k in optional})
        data_key = values.get("data_class", "unspecified")
        evidence_key = values.get("evidence_status", "unspecified")
        if data_key not in NEW_DATA_CLASS:
            raise ValueError(f"Unknown NEW data_class: {data_key!r}")
        if evidence_key not in NEW_EVIDENCE_STATUS:
            raise ValueError(f"Unknown NEW evidence_status: {evidence_key!r}")
        authorized = _bool(values.get("authorization_confirmed", False), "authorization_confirmed")
        record = NewRecord(
            *(encoded[k] for k in required),
            *(encoded[k] for k in optional),
            NEW_DATA_CLASS[data_key], NEW_EVIDENCE_STATUS[evidence_key], authorized,
        )
        output = C.create_string_buffer(self.output_capacity)
        status = self._lib.new_build_narrative(C.byref(record), output, self.output_capacity)
        if status != 0:
            raise NativeStatusError("NEW", status, _NEW_STATUS.get(status, "unknown native status"))
        return output.value.decode("utf-8", errors="strict")

    def build_correction(self, values: Mapping[str, Any]) -> str:
        """Build an additive FaCADE correction proposal; authorization defaults False."""
        if not isinstance(values, Mapping):
            raise TypeError("values must be a mapping")
        required = (
            "notice_id", "source_record_id", "target_record_id", "evidence_reference",
            "reason", "recorded_at", "reviewer_id",
        )
        missing = [k for k in required if k not in values]
        if missing:
            raise ValueError("Missing FaCADE fields: " + ", ".join(missing))
        encoded = {k: _text(values[k], k) for k in required}
        relation = values.get("relation", "derived_from")
        if relation not in FACADE_RELATION:
            raise ValueError(f"Unknown FaCADE relation: {relation!r}")
        correction = FaCADECorrection(
            *(encoded[k] for k in required),
            FACADE_RELATION[relation],
            _bool(values.get("source_authorized", False), "source_authorized"),
            _bool(values.get("link_verified", False), "link_verified"),
        )
        output = C.create_string_buffer(self.output_capacity)
        status = self._lib.facade_build_correction(C.byref(correction), output, self.output_capacity)
        if status != 0:
            raise NativeStatusError("FaCADE", status, _FACADE_STATUS.get(status, "unknown native status"))
        return output.value.decode("utf-8", errors="strict")

    @staticmethod
    def capabilities() -> dict[str, Any]:
        return {
            "native_modules": ["Pantheon NEW", "Pantheon FaCADE"],
            "interface": "Python ctypes / C ABI",
            "outputs": "review-only text proposals",
            "pons_approval_granted": False,
            "repository_writes_enabled": False,
            "privileged_execution_enabled": False,
            "network_access": False,
            "money_movement": False,
            "authorization_flags_are_cryptographic_proof": False,
        }
