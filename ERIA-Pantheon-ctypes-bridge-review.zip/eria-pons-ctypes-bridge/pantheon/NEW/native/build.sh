#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../../.." && pwd)"
CC_BIN="${CC:-clang}"
OUT="$HERE/liberia_pantheon_native.so"

command -v "$CC_BIN" >/dev/null 2>&1 || {
  echo "Compiler '$CC_BIN' not found. In Termux run: pkg install clang" >&2
  exit 1
}

"$CC_BIN" -std=c99 -O2 -fPIC -shared -Wall -Wextra -Werror \
  -I"$ROOT/pantheon/NEW" \
  -I"$ROOT/pantheon/NEW/FaCADE" \
  "$ROOT/pantheon/NEW/NEW.c" \
  "$ROOT/pantheon/NEW/FaCADE/FaCADE.c" \
  -o "$OUT"

echo "Built: $OUT"
