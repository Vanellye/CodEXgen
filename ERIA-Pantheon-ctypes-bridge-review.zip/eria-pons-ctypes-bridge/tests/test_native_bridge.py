from __future__ import annotations

import os
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "pantheon" / "NEW" / "python"))
from eria_pantheon import PantheonNativeBridge, NativeStatusError


class NativeBridgeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        library = ROOT / "pantheon" / "NEW" / "native" / "liberia_pantheon_native.so"
        cls.bridge = PantheonNativeBridge(library)

    def test_new_denies_missing_authorization(self):
        record = {
            "source_id": "source-1", "record_id": "record-1",
            "permission_basis": "public source", "purpose": "test review",
            "captured_at": "2026-11-18T00:00:00Z", "provenance_digest": "a" * 64,
            "content_summary": "A source-reported statement", "data_class": "public",
            "evidence_status": "source_reported",
        }
        with self.assertRaises(NativeStatusError) as caught:
            self.bridge.build_narrative(record)
        self.assertEqual(caught.exception.status, 2)

    def test_new_returns_labeled_narrative_with_assertion(self):
        record = {
            "source_id": "source-1", "record_id": "record-1",
            "permission_basis": "public source", "purpose": "test review",
            "captured_at": "2026-11-18T00:00:00Z", "provenance_digest": "a" * 64,
            "content_summary": "A source-reported statement", "data_class": "public",
            "evidence_status": "source_reported", "authorization_confirmed": True,
        }
        output = self.bridge.build_narrative(record)
        self.assertIn("UNREVIEWED EVIDENCE NARRATIVE", output)
        self.assertIn("not independently corroborated", output)
        self.assertIn("NOT ESTABLISHED BY THIS MODULE", output)

    def test_facade_denies_missing_source_authorization(self):
        correction = {
            "notice_id": "notice-1", "source_record_id": "source-1",
            "target_record_id": "target-1", "evidence_reference": "evidence-1",
            "reason": "test", "recorded_at": "2026-11-18T00:00:00Z",
            "reviewer_id": "reviewer-1", "relation": "corrects", "link_verified": True,
        }
        with self.assertRaises(NativeStatusError) as caught:
            self.bridge.build_correction(correction)
        self.assertEqual(caught.exception.status, 2)

    def test_facade_returns_additive_proposal(self):
        correction = {
            "notice_id": "notice-1", "source_record_id": "source-1",
            "target_record_id": "target-1", "evidence_reference": "evidence-1",
            "reason": "test correction", "recorded_at": "2026-11-18T00:00:00Z",
            "reviewer_id": "reviewer-1", "relation": "corrects",
            "source_authorized": True, "link_verified": True,
        }
        output = self.bridge.build_correction(correction)
        self.assertIn("FACADE CORRECTION PROPOSAL", output)
        self.assertIn("ADDITIVE LINK", output)
        self.assertIn("not a voice or identity claim", output)

    def test_capabilities_never_claim_approval(self):
        state = self.bridge.capabilities()
        self.assertFalse(state["pons_approval_granted"])
        self.assertFalse(state["repository_writes_enabled"])
        self.assertFalse(state["privileged_execution_enabled"])


if __name__ == "__main__":
    unittest.main()
