#!/usr/bin/env python3
"""ASH launch platform starter: local-first API, rights, audit, messages and payment intents.
No real banking rails are connected. Payment execution intentionally fails closed.
"""
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
import sqlite3, json, os, secrets, hashlib, hmac, time, uuid, mimetypes
from urllib.parse import urlparse, parse_qs

ROOT=Path(__file__).resolve().parent.parent
DB=Path(os.environ.get('ASH_DB', str(Path.home()/'.ash'/'ash.sqlite3')))
DB.parent.mkdir(parents=True,exist_ok=True)
PORT=int(os.environ.get('ASH_PORT','8787'))
HOST=os.environ.get('ASH_HOST','127.0.0.1')
TOKEN_TTL=12*60*60
PERMISSIONS={
 'COMMUNICATE':'Send and receive messages', 'READ_DATA':'Read authorized data',
 'WRITE_DATA':'Create or update authorized data', 'EXPORT_DATA':'Export authorized data',
 'INITIATE_TRANSACTION':'Create a payment or transfer intent',
 'APPROVE_TRANSACTION':'Approve a specific transaction intent',
 'EXECUTE_TRANSACTION':'Submit an approved transaction to a connected provider',
 'AUTHOR_ADMIN':'Manage ASH users, roles, permissions and configuration'
}
ROLE_DEFAULTS={
 'AUTHOR':list(PERMISSIONS),
 'MEMBER':['COMMUNICATE','READ_DATA','WRITE_DATA','EXPORT_DATA','INITIATE_TRANSACTION'],
 'REVIEWER':['COMMUNICATE','READ_DATA','APPROVE_TRANSACTION'],
 'GUEST':['COMMUNICATE']
}

def db():
 c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

def init():
 c=db(); c.executescript('''
 CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY, username TEXT UNIQUE NOT NULL, salt TEXT NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL, created_at INTEGER NOT NULL, active INTEGER NOT NULL DEFAULT 1);
 CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL, expires_at INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS messages(id TEXT PRIMARY KEY, sender_id TEXT NOT NULL, recipient TEXT NOT NULL, body TEXT NOT NULL, created_at INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS data_records(id TEXT PRIMARY KEY, owner_id TEXT NOT NULL, label TEXT NOT NULL, payload TEXT NOT NULL, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS transactions(id TEXT PRIMARY KEY, owner_id TEXT NOT NULL, amount_minor INTEGER NOT NULL, currency TEXT NOT NULL, destination TEXT NOT NULL, memo TEXT NOT NULL, status TEXT NOT NULL, created_at INTEGER NOT NULL, approved_by TEXT, approved_at INTEGER);
 CREATE TABLE IF NOT EXISTS audit(id TEXT PRIMARY KEY, actor_id TEXT, action TEXT NOT NULL, object_type TEXT NOT NULL, object_id TEXT, detail TEXT NOT NULL, created_at INTEGER NOT NULL);
 ''')
 c.commit(); c.close()

def pw_hash(password,salt): return hashlib.pbkdf2_hmac('sha256',password.encode(),bytes.fromhex(salt),240000).hex()
def audit(actor,action,typ,obj,detail):
 c=db(); c.execute('INSERT INTO audit VALUES(?,?,?,?,?,?,?)',(str(uuid.uuid4()),actor,action,typ,obj,json.dumps(detail),int(time.time()))); c.commit(); c.close()
def response(handler,status,data,ctype='application/json'):
 raw=(json.dumps(data,ensure_ascii=False) if ctype=='application/json' else data).encode()
 handler.send_response(status); handler.send_header('Content-Type',ctype+'; charset=utf-8'); handler.send_header('Content-Length',str(len(raw))); handler.send_header('Cache-Control','no-store'); handler.send_header('X-Content-Type-Options','nosniff'); handler.send_header('Content-Security-Policy',"default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'"); handler.end_headers(); handler.wfile.write(raw)
def body(handler):
 n=int(handler.headers.get('Content-Length','0'))
 if n>1_000_000: raise ValueError('Request body too large')
 return json.loads(handler.rfile.read(n) or b'{}')
def actor(handler):
 tok=handler.headers.get('Authorization','').removeprefix('Bearer ').strip()
 if not tok: return None
 c=db(); row=c.execute('SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>? AND u.active=1',(hashlib.sha256(tok.encode()).hexdigest(),int(time.time()))).fetchone(); c.close(); return row
def allowed(user,perm):
 return bool(user and (perm in ROLE_DEFAULTS.get(user['role'],[]) or user['role']=='AUTHOR'))
def need(handler,perm):
 u=actor(handler)
 if not u: response(handler,401,{'error':'authentication_required'}); return None
 if not allowed(u,perm): audit(u['id'],'permission_denied','permission',perm,{}); response(handler,403,{'error':'permission_denied','permission':perm}); return None
 return u

class API(BaseHTTPRequestHandler):
 def log_message(self,*a): pass
 def do_GET(self):
  p=urlparse(self.path).path
  if p=='/':
   f=ROOT/'web'/'index.html'; response(self,200,f.read_text(), 'text/html'); return
  if p.startswith('/web/'):
   f=(ROOT/p.lstrip('/')).resolve()
   if ROOT not in f.parents or not f.is_file(): response(self,404,{'error':'not_found'}); return
   response(self,200,f.read_text(),mimetypes.guess_type(str(f))[0] or 'text/plain'); return
  if p=='/api/health': response(self,200,{'service':'ASH','status':'ready','banking_provider':'not_connected','global_federation':'not_configured'}); return
  if p=='/api/setup-status':
   c=db(); n=c.execute('SELECT COUNT(*) n FROM users').fetchone()['n']; c.close(); response(self,200,{'initialized':bool(n)}); return
  u=actor(self)
  if p=='/api/me':
   if not u: response(self,401,{'error':'authentication_required'}); return
   response(self,200,{'id':u['id'],'username':u['username'],'role':u['role'],'permissions':ROLE_DEFAULTS.get(u['role'],[])}); return
  if p=='/api/messages':
   u=need(self,'COMMUNICATE');
   if not u:return
   c=db(); rows=c.execute('SELECT id,sender_id,recipient,body,created_at FROM messages WHERE sender_id=? OR recipient=? ORDER BY created_at DESC LIMIT 100',(u['id'],u['username'])).fetchall(); c.close(); response(self,200,[dict(x) for x in rows]); return
  if p=='/api/data':
   u=need(self,'READ_DATA');
   if not u:return
   c=db(); rows=c.execute('SELECT id,owner_id,label,payload,created_at,updated_at FROM data_records WHERE owner_id=? ORDER BY updated_at DESC LIMIT 200',(u['id'],)).fetchall(); c.close(); response(self,200,[dict(x) for x in rows]); return
  if p=='/api/transactions':
   u=need(self,'READ_DATA');
   if not u:return
   c=db(); rows=c.execute('SELECT * FROM transactions WHERE owner_id=? ORDER BY created_at DESC LIMIT 100',(u['id'],)).fetchall(); c.close(); response(self,200,[dict(x) for x in rows]); return
  if p=='/api/audit':
   u=need(self,'AUTHOR_ADMIN');
   if not u:return
   c=db(); rows=c.execute('SELECT * FROM audit ORDER BY created_at DESC LIMIT 200').fetchall(); c.close(); response(self,200,[dict(x) for x in rows]); return
  if p=='/api/admin/users':
   u=need(self,'AUTHOR_ADMIN');
   if not u:return
   c=db(); rows=c.execute('SELECT id,username,role,active,created_at FROM users ORDER BY created_at').fetchall(); c.close(); response(self,200,[dict(x) for x in rows]); return
  response(self,404,{'error':'not_found'})
 def do_POST(self):
  p=urlparse(self.path).path
  try: d=body(self)
  except Exception as e: response(self,400,{'error':str(e)}); return
  if p=='/api/setup':
   c=db(); count=c.execute('SELECT COUNT(*) n FROM users').fetchone()['n']
   if count: c.close(); response(self,409,{'error':'setup_already_completed'}); return
   username=str(d.get('username','')).strip(); password=str(d.get('password',''))
   if len(username)<3 or len(password)<14: c.close(); response(self,400,{'error':'username_min_3_and_password_min_14_required'}); return
   salt=secrets.token_bytes(16).hex(); uid=str(uuid.uuid4())
   c.execute('INSERT INTO users VALUES(?,?,?,?,?,?,1)',(uid,username,salt,pw_hash(password,salt),'AUTHOR',int(time.time()))); c.commit(); c.close()
   audit(uid,'initial_author_created','user',uid,{'role':'AUTHOR'}); response(self,201,{'created':True,'message':'AUTHOR account created. Sign in to continue.'}); return
  if p=='/api/login':
   username=str(d.get('username','')).strip(); password=str(d.get('password',''))
   c=db(); u=c.execute('SELECT * FROM users WHERE username=? AND active=1',(username,)).fetchone()
   if not u or not hmac.compare_digest(pw_hash(password,u['salt']),u['password_hash']): c.close(); response(self,401,{'error':'invalid_credentials'}); return
   tok=secrets.token_urlsafe(40); c.execute('INSERT INTO sessions VALUES(?,?,?)',(hashlib.sha256(tok.encode()).hexdigest(),u['id'],int(time.time())+TOKEN_TTL)); c.commit(); c.close(); audit(u['id'],'login','session',None,{}); response(self,200,{'token':tok,'expires_in':TOKEN_TTL}); return
  if p=='/api/messages':
   u=need(self,'COMMUNICATE');
   if not u:return
   recipient=str(d.get('recipient','')).strip(); msg=str(d.get('body',''))
   if not recipient or not msg or len(msg)>10000: response(self,400,{'error':'recipient_and_message_required_max_10000_chars'}); return
   mid=str(uuid.uuid4()); c=db(); c.execute('INSERT INTO messages VALUES(?,?,?,?,?)',(mid,u['id'],recipient,msg,int(time.time()))); c.commit(); c.close(); audit(u['id'],'message_sent','message',mid,{'recipient':recipient}); response(self,201,{'id':mid,'status':'stored_locally'}); return
  if p=='/api/data':
   u=need(self,'WRITE_DATA');
   if not u:return
   label=str(d.get('label','')).strip(); payload=d.get('payload')
   if not label or payload is None: response(self,400,{'error':'label_and_payload_required'}); return
   rid=str(uuid.uuid4()); now=int(time.time()); c=db(); c.execute('INSERT INTO data_records VALUES(?,?,?,?,?,?)',(rid,u['id'],label,json.dumps(payload),now,now)); c.commit(); c.close(); audit(u['id'],'data_created','data',rid,{'label':label}); response(self,201,{'id':rid}); return
  if p=='/api/transactions':
   u=need(self,'INITIATE_TRANSACTION');
   if not u:return
   try: amount=int(d.get('amount_minor',0))
   except: amount=0
   currency=str(d.get('currency','USD')).upper(); destination=str(d.get('destination','')).strip(); memo=str(d.get('memo',''))
   if amount<=0 or amount>10**12 or len(currency)!=3 or not destination: response(self,400,{'error':'valid_positive_minor_amount_currency_destination_required'}); return
   tid=str(uuid.uuid4()); now=int(time.time()); c=db(); c.execute('INSERT INTO transactions VALUES(?,?,?,?,?,?,?,?,NULL,NULL)',(tid,u['id'],amount,currency,destination,memo,'PENDING_APPROVAL',now)); c.commit(); c.close(); audit(u['id'],'transaction_intent_created','transaction',tid,{'amount_minor':amount,'currency':currency}); response(self,201,{'id':tid,'status':'PENDING_APPROVAL','execution':'disabled_until_provider_integration'}); return
  if p.startswith('/api/transactions/') and p.endswith('/approve'):
   u=need(self,'APPROVE_TRANSACTION');
   if not u:return
   tid=p.split('/')[-2]; c=db(); tx=c.execute('SELECT * FROM transactions WHERE id=?',(tid,)).fetchone()
   if not tx: c.close(); response(self,404,{'error':'not_found'}); return
   if tx['owner_id']==u['id']: c.close(); response(self,403,{'error':'separate_approver_required'}); return
   if tx['status']!='PENDING_APPROVAL': c.close(); response(self,409,{'error':'transaction_not_pending'}); return
   c.execute("UPDATE transactions SET status='APPROVED',approved_by=?,approved_at=? WHERE id=?",(u['id'],int(time.time()),tid)); c.commit(); c.close(); audit(u['id'],'transaction_approved','transaction',tid,{}); response(self,200,{'id':tid,'status':'APPROVED','execution':'still_disabled'}); return
  if p.startswith('/api/transactions/') and p.endswith('/execute'):
   u=need(self,'EXECUTE_TRANSACTION');
   if not u:return
   audit(u['id'],'execution_blocked_no_provider','transaction',p.split('/')[-2],{}); response(self,501,{'error':'banking_provider_not_connected','message':'No payment rail is configured. Nothing was sent.'}); return
  if p=='/api/admin/users':
   u=need(self,'AUTHOR_ADMIN');
   if not u:return
   username=str(d.get('username','')).strip(); password=str(d.get('password','')); role=str(d.get('role','MEMBER'))
   if len(username)<3 or len(password)<14 or role not in ROLE_DEFAULTS or role=='AUTHOR': response(self,400,{'error':'valid_username_password_and_non_author_role_required'}); return
   salt=secrets.token_bytes(16).hex(); uid=str(uuid.uuid4()); c=db()
   try: c.execute('INSERT INTO users VALUES(?,?,?,?,?,?,1)',(uid,username,salt,pw_hash(password,salt),role,int(time.time()))); c.commit()
   except sqlite3.IntegrityError: c.close(); response(self,409,{'error':'username_exists'}); return
   c.close(); audit(u['id'],'user_created','user',uid,{'role':role}); response(self,201,{'id':uid,'role':role}); return
  response(self,404,{'error':'not_found'})
 def do_OPTIONS(self): self.send_response(204); self.send_header('Allow','GET, POST, OPTIONS'); self.end_headers()

if __name__=='__main__':
 init(); print(f'ASH listening on http://{HOST}:{PORT}'); print(f'Database: {DB}'); ThreadingHTTPServer((HOST,PORT),API).serve_forever()
