# ASH Launch Platform — foundation build

A local-first, full-stack starter for worldwide communication workflows, data exchange, permissioned transaction intents, and an AUTHOR administration plane.

## What is implemented
- Python standard-library HTTP API and SQLite persistence.
- Responsive browser frontend.
- One-time first-run AUTHOR account setup; password hashing with PBKDF2-HMAC-SHA256; opaque bearer sessions.
- Role defaults: AUTHOR, MEMBER, REVIEWER, GUEST.
- Permission checks for communication, data read/write, transaction initiation/approval/execution, and AUTHOR administration.
- Local message and data-record endpoints.
- Payment/transfer intent creation and separate-approver check.
- Append-only application audit events.
- API health endpoint and fail-closed behavior when permissions or provider capability are missing.

## Important boundaries
This is a launch-oriented foundation, **not a production bank, licensed money transmitter, or globally federated messaging network**. Messages and records are stored in this server's local SQLite database; worldwide delivery requires a deployed, secured, federated messaging service and domain configuration. Payment execution is deliberately disabled: `/api/transactions/{id}/execute` returns HTTP 501 and sends no money. No bank, Plaid, ACH, SEPA, card, Bitcoin, custody, or wallet provider is connected. Currency conversion and asset prices are not live.

AUTHOR is the highest application administrator for users, roles, and configuration. AUTHOR is not a universal override of another person's account consent, transaction approval, provider controls, or law. Real provider credentials must be held server-side in a secrets manager and never placed in browser code.

## Run in Termux
```bash
pkg update -y
pkg install python -y
unzip ASH-Launch-Platform.zip
cd ASH-Launch-Platform
python ash/server.py
```
Open `http://127.0.0.1:8787` in the phone browser. Create the first AUTHOR account. Use a unique password of at least 14 characters. The database is stored at `~/.ash/ash.sqlite3` by default.

For local-network access only, set `ASH_HOST=0.0.0.0` before starting and use a firewall. **Do not expose this starter directly to the public internet.** Put it behind HTTPS, a hardened reverse proxy, rate limiting, CSRF protection, secure cookie/session handling, backups, monitoring, and a production identity provider before any public deployment.

## API overview
- `GET /api/health`
- `POST /api/setup` — one-time AUTHOR bootstrap
- `POST /api/login`
- `GET /api/me`
- `GET|POST /api/messages`
- `GET|POST /api/data`
- `GET|POST /api/transactions`
- `POST /api/transactions/{id}/approve` — separate approver required
- `POST /api/transactions/{id}/execute` — intentionally disabled until provider integration
- `GET /api/admin/users`, `POST /api/admin/users`
- `GET /api/audit` — AUTHOR only

## Before public launch
1. Deploy to a managed host with HTTPS and a hardened reverse proxy.
2. Replace local bearer-token storage with secure, HttpOnly, SameSite cookies or a vetted OIDC provider; add CSRF protection, MFA, rate limits, lockouts, and session revocation.
3. Add organization/user consent, data retention/deletion/export controls, abuse reporting, spam controls, encryption-at-rest/key management, and independent security review.
4. Integrate a regulated banking/payment provider with verified webhook signatures, idempotency keys, reconciliation, sanctions/KYC/AML controls as applicable, transaction limits, and dispute handling. Keep money movement disabled until all are verified.
5. Add a real federation protocol, delivery queues, end-to-end encryption design, domain verification, anti-abuse, and message delivery receipts for worldwide communication.
6. Add automated tests, migrations, backups, observability, incident response, and compliance review for each launch jurisdiction.

This package does not connect to GitHub or mutate the Ash repository. Build and test locally first; keep `main` protected.
