#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python -m py_compile ash/server.py
python - <<'PY'
import ast, pathlib, json
ast.parse(pathlib.Path('ash/server.py').read_text())
json.loads(pathlib.Path('RIGHTS-MODEL.json').read_text())
for p in ['web/index.html','web/app.js','web/style.css']:
    assert pathlib.Path(p).is_file()
print('Static validation passed')
PY
