/**
 * PANTHEON semantic root-breakage and historical anchorage prototype.
 * Pure data transformation only: no filesystem, network, shell, or eval.
 */
const sha256Pattern = /^sha256:[a-f0-9]{64}$/i;
const requiredText = (v, n) => {
  if (typeof v !== 'string' || !v.trim()) throw new TypeError(`${n} must be a non-empty string`);
  return v;
};

/** Split an expression into traceable lexical units without discarding separators. */
export function breakExpression(expression, { language = 'und', expressionId = 'expr:0' } = {}) {
  requiredText(expression, 'expression');
  const units = [];
  const re = /[\p{L}\p{M}\p{N}_]+|[^\p{L}\p{M}\p{N}_]+/gu;
  let match;
  let index = 0;
  while ((match = re.exec(expression)) !== null) {
    const text = match[0];
    const start = match.index;
    const end = start + text.length;
    const byteStart = Buffer.byteLength(expression.slice(0, start), 'utf8');
    const byteEnd = byteStart + Buffer.byteLength(text, 'utf8');
    units.push(Object.freeze({
      unitId: `${expressionId}:u${index++}`,
      kind: /^[\p{L}\p{M}\p{N}_]+$/u.test(text) ? 'lexical' : 'separator',
      surface: text, language, charSpan: [start, end], byteSpan: [byteStart, byteEnd],
      preserved: true
    }));
  }
  return Object.freeze({ kind: 'RootBreakdown', expressionId, language, original: expression,
    units: Object.freeze(units), reconstruction: units.map(x => x.surface).join(''),
    lossless: units.map(x => x.surface).join('') === expression });
}

/** Follow exactly two parent edges by default; return explicit lineage, never infer missing ancestors. */
export function anchorLineage({ nodeId, nodes, levels = 2 }) {
  requiredText(nodeId, 'nodeId');
  if (!Array.isArray(nodes) || !Number.isInteger(levels) || levels < 0 || levels > 64) {
    throw new TypeError('nodes must be an array and levels an integer from 0 to 64');
  }
  const byId = new Map(nodes.map(n => [n.nodeId, n]));
  const start = byId.get(nodeId);
  if (!start) throw new Error(`Unknown node: ${nodeId}`);
  const lineage = [];
  const seen = new Set([nodeId]);
  let current = start;
  for (let depth = 1; depth <= levels; depth++) {
    const parentId = current.parentId;
    if (parentId == null) break;
    if (seen.has(parentId)) throw new Error(`Lineage cycle detected at ${parentId}`);
    const parent = byId.get(parentId);
    if (!parent) {
      lineage.push(Object.freeze({ depth, nodeId: parentId, status: 'unresolved-reference' }));
      break;
    }
    lineage.push(Object.freeze({ depth, nodeId: parent.nodeId, status: 'resolved',
      temporalRelation: parent.temporalRelation ?? 'undetermined', sourceRef: parent.sourceRef ?? null }));
    seen.add(parentId);
    current = parent;
  }
  return Object.freeze({ kind: 'HistoricalAnchorage', nodeId, requestedLevels: levels,
    lineage: Object.freeze(lineage), complete: lineage.every(x => x.status === 'resolved') });
}

/** Validate a semantic frame without collapsing subjective expression into factual assertion. */
export function createSemanticFrame(input) {
  requiredText(input?.frameId, 'frameId');
  requiredText(input?.sourceExpressionRef, 'sourceExpressionRef');
  requiredText(input?.meaning, 'meaning');
  const speaker = requiredText(input?.speaker, 'speaker');
  const modality = requiredText(input?.modality, 'modality');
  const epistemicStatus = requiredText(input?.epistemicStatus, 'epistemicStatus');
  const forms = input?.expressionForms;
  if (!Array.isArray(forms) || forms.length === 0 || forms.some(x => !x || typeof x.text !== 'string' || !x.text.length || typeof x.language !== 'string' || !x.language.length)) {
    throw new TypeError('expressionForms must contain text and language for each form');
  }
  if (!['fact', 'belief', 'opinion', 'metaphor', 'question', 'fiction', 'unknown'].includes(epistemicStatus)) {
    throw new TypeError('Unsupported epistemicStatus');
  }
  return Object.freeze({ kind: 'PantheonSemanticFrame', frameId: input.frameId,
    sourceExpressionRef: input.sourceExpressionRef, meaning: input.meaning, speaker, modality,
    epistemicStatus, audience: input.audience ?? 'unspecified', register: input.register ?? 'unspecified',
    confidence: Number.isFinite(input.confidence) ? Math.max(0, Math.min(1, input.confidence)) : null,
    expressionForms: Object.freeze(forms.map(f => Object.freeze({
      language: f.language, text: f.text, form: f.form ?? 'literal',
      preservesSubjectivity: f.preservesSubjectivity !== false
    }))),
    factualityWarning: epistemicStatus === 'fact' ? null : 'Do not promote subjective or figurative content to verified fact.'
  });
}

/** Attach pre/post Ɣơ birth references without assuming chronology or truth. */
export function createAnchorageRecord({ rootId, sourceRef, sourceDigest, birthBoundary, temporalRelation, semanticFrameRef }) {
  for (const [k, v] of Object.entries({ rootId, sourceRef, birthBoundary, temporalRelation, semanticFrameRef })) requiredText(v, k);
  if (!sha256Pattern.test(sourceDigest)) throw new TypeError('sourceDigest must be a full sha256:<64 hex> digest');
  if (!['before-yoro-birth', 'after-yoro-birth', 'at-yoro-birth', 'undetermined'].includes(temporalRelation)) {
    throw new TypeError('Invalid temporalRelation');
  }
  return Object.freeze({ kind: 'PantheonAnchorageRecord', rootId, sourceRef, sourceDigest,
    birthBoundary, temporalRelation, semanticFrameRef, canonicalSourceMutation: false,
    evidenceStatus: 'reference-recorded-not-truth-verified' });
}

/** Generate target-language expression candidates from supplied, reviewed forms only. */
export function expressAcrossForms(frame, requestedLanguages = []) {
  if (frame?.kind !== 'PantheonSemanticFrame') throw new TypeError('Validated semantic frame required');
  const wanted = new Set(requestedLanguages);
  return Object.freeze(frame.expressionForms.filter(f => wanted.size === 0 || wanted.has(f.language))
    .map(f => Object.freeze({ ...f, frameId: frame.frameId, meaningRef: frame.sourceExpressionRef,
      epistemicStatus: frame.epistemicStatus, reviewRequired: true })));
}
