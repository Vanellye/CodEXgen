/**
 * Data-only reference semantics for Ɣơ positive-possibility notation.
 * No file, network, shell, dynamic-code, or external-dispatch behavior.
 */

export const ResultKind = Object.freeze({
  VALUE: 'Value',
  MATCH: 'Match',
  MISMATCH: 'Mismatch',
  KNOWN_WRONG: 'KnownWrong',
  NUN: 'Nun',
  SILENT_RETURN: 'SilentReturn',
  REJECTED: 'Rejected',
});

export function positivePossibilityFromZero({ value, sourceDigest, byteOffset, profileVersion }) {
  if (value !== 0) throw new TypeError('Only a typed zero can be represented as ·');
  if (typeof sourceDigest !== 'string' || !sourceDigest.trim()) throw new TypeError('sourceDigest is required');
  if (!Number.isSafeInteger(byteOffset) || byteOffset < 0) throw new TypeError('byteOffset must be a non-negative safe integer');
  if (typeof profileVersion !== 'string' || !profileVersion.trim()) throw new TypeError('profileVersion is required');
  return Object.freeze({
    kind: 'Possibility', token: '·', originalValue: 0,
    sourceDigest, byteOffset, profileVersion,
    reversible: true,
  });
}

export function restorePossibility(possibility) {
  if (!possibility || possibility.kind !== 'Possibility' || possibility.token !== '·' ||
      possibility.originalValue !== 0 || possibility.reversible !== true ||
      !possibility.sourceDigest || !Number.isSafeInteger(possibility.byteOffset)) {
    throw new TypeError('Possibility lacks a valid reversible origin reference');
  }
  return 0;
}

export function recycleZero(possibility) {
  const restored = restorePossibility(possibility);
  return Object.freeze({ kind: 'RecycledZero', token: '♻️', originalValue: restored,
    sourceDigest: possibility.sourceDigest, byteOffset: possibility.byteOffset,
    profileVersion: possibility.profileVersion });
}

export function arithmetic(operator, left, right, { maxAbs = Number.MAX_SAFE_INTEGER } = {}) {
  if (!Number.isSafeInteger(left) || !Number.isSafeInteger(right)) {
    return { kind: ResultKind.REJECTED, reason: 'Operands must be safe integers' };
  }
  if (!Number.isSafeInteger(maxAbs) || maxAbs < 0) {
    return { kind: ResultKind.REJECTED, reason: 'Invalid numeric bound' };
  }
  let value;
  switch (operator) {
    case '+': value = left + right; break;
    case '×': value = left * right; break;
    case '÷':
      if (right === 0) return { kind: ResultKind.KNOWN_WRONG, reason: 'DivisionByZero', left, right };
      if (left % right !== 0) return { kind: ResultKind.REJECTED, reason: 'NonIntegralDivisionRequiresExplicitRoundingPolicy' };
      value = left / right;
      break;
    case '=': return { kind: left === right ? ResultKind.MATCH : ResultKind.MISMATCH, left, right };
    default: return { kind: ResultKind.REJECTED, reason: 'UnsupportedOperator' };
  }
  if (!Number.isSafeInteger(value) || Math.abs(value) > maxAbs) {
    return { kind: ResultKind.REJECTED, reason: 'OverflowOrBoundExceeded' };
  }
  return { kind: ResultKind.VALUE, value, zeroPreserved: true };
}

export function returnState(mode) {
  if (mode === 'nun') return { kind: ResultKind.NUN, stateChanged: false };
  if (mode === 'silent') return { kind: ResultKind.SILENT_RETURN, stateChanged: false, auditRequired: true };
  return { kind: ResultKind.REJECTED, reason: 'UnknownReturnMode' };
}

export function lockSearchSnapshot({ query, corpusRevision, scorerVersion, score, threshold, evidenceRefs, lockedAt }) {
  if (typeof query !== 'string' || !query.trim()) throw new TypeError('query is required');
  if (typeof corpusRevision !== 'string' || !corpusRevision.trim()) throw new TypeError('corpusRevision is required');
  if (typeof scorerVersion !== 'string' || !scorerVersion.trim()) throw new TypeError('scorerVersion is required');
  if (!Number.isFinite(score) || score < 0 || score > 1 || !Number.isFinite(threshold) || threshold < 0 || threshold > 1) {
    throw new RangeError('score and threshold must be in [0,1]');
  }
  if (!Array.isArray(evidenceRefs) || evidenceRefs.length === 0 || evidenceRefs.some(x => typeof x !== 'string' || !x.trim())) {
    throw new TypeError('At least one non-empty evidence reference is required');
  }
  if (typeof lockedAt !== 'string' || Number.isNaN(Date.parse(lockedAt))) throw new TypeError('lockedAt must be an ISO-compatible timestamp');
  return Object.freeze({ query, corpusRevision, scorerVersion, score, threshold,
    outcome: score >= threshold ? 'ThresholdMet' : 'BelowThreshold',
    evidenceRefs: Object.freeze([...evidenceRefs]), lockedAt, immutableSnapshot: true });
}

export function classifyMigration({ exactRecovery, externalEvidenceRequired = false, informationRemoved = false }) {
  if (informationRemoved) return 'Lossy';
  if (exactRecovery && !externalEvidenceRequired) return 'Lossless';
  if (exactRecovery && externalEvidenceRequired) return 'ConditionallyLossless';
  return 'Rejected';
}
