/** Data-only parser for the Ɣơ OPEN grammar prototype v0.1. */

const IDENT = /^[\p{L}_][\p{L}\p{N}_.-]*$/u;

function stripComment(line) {
  let quoted = false;
  let escaped = false;
  for (let i = 0; i < line.length; i += 1) {
    const ch = line[i];
    if (quoted) {
      if (escaped) escaped = false;
      else if (ch === "\\") escaped = true;
      else if (ch === '"') quoted = false;
    } else if (ch === '"') quoted = true;
    else if (ch === "#") return line.slice(0, i);
  }
  return line;
}

function identifier(value, lineNumber) {
  if (!IDENT.test(value)) throw new SyntaxError(`Line ${lineNumber}: invalid identifier '${value}'`);
  return value;
}

export function parseYoroOpen(source) {
  if (typeof source !== "string") throw new TypeError("source must be a string");
  const ast = { kind: "YoroOpenDocument", version: "0.1", declarations: [] };
  const lines = source.split(/\r?\n/u);

  for (let index = 0; index < lines.length; index += 1) {
    const lineNumber = index + 1;
    const line = stripComment(lines[index]).trim();
    if (!line) continue;

    let match;
    if ((match = line.match(/^§\s+scope\s+([^\s]+)$/u))) {
      ast.declarations.push({ kind: "Scope", name: identifier(match[1], lineNumber), line: lineNumber });
    } else if ((match = line.match(/^☆\s+("(?:\\.|[^"\\])*")$/u))) {
      let originId;
      try { originId = JSON.parse(match[1]); }
      catch { throw new SyntaxError(`Line ${lineNumber}: invalid origin string`); }
      if (!originId.length) throw new SyntaxError(`Line ${lineNumber}: origin id cannot be empty`);
      ast.declarations.push({ kind: "OriginRef", originId, line: lineNumber });
    } else if ((match = line.match(/^([●○Ẅ])\s+([^\s]+)$/u))) {
      const name = identifier(match[2], lineNumber);
      const kind = match[1] === "●" ? "Present" : match[1] === "○" ? "Absent" : "Direction";
      ast.declarations.push({ kind, name, line: lineNumber });
    } else if ((match = line.match(/^u\.v\.\s+([^\s]+)\s+([^\s]+)$/u))) {
      ast.declarations.push({ kind: "Intersection", left: identifier(match[1], lineNumber), right: identifier(match[2], lineNumber), line: lineNumber });
    } else if ((match = line.match(/^→\s+([^\s]+)\s+([^\s]+)$/u))) {
      ast.declarations.push({ kind: "DirectedRelation", from: identifier(match[1], lineNumber), to: identifier(match[2], lineNumber), line: lineNumber });
    } else {
      throw new SyntaxError(`Line ${lineNumber}: unsupported or malformed declaration`);
    }
  }
  return ast;
}
