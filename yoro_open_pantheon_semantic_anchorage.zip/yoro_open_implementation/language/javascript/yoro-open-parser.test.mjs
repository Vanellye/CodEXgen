import test from "node:test";
import assert from "node:assert/strict";
import { parseYoroOpen } from "./yoro-open-parser.mjs";

test("parses OPEN declarations into a data-only AST", () => {
  const ast = parseYoroOpen([
    "§ scope repository",
    '☆ "sha256:abc123" # source root',
    "● source_present",
    "○ source_missing",
    "Ẅ forward",
    "u.v. kotlin javascript",
    "→ origin translated",
  ].join("\n"));
  assert.deepEqual(ast.declarations.map(x => x.kind), [
    "Scope", "OriginRef", "Present", "Absent", "Direction", "Intersection", "DirectedRelation",
  ]);
  assert.equal(ast.declarations[1].originId, "sha256:abc123");
});

test("preserves empty document as an empty AST", () => {
  assert.deepEqual(parseYoroOpen("\n # only a comment\n").declarations, []);
});

test("rejects unknown syntax and reserved transition marker", () => {
  assert.throws(() => parseYoroOpen("° boundary"), /unsupported or malformed/);
  assert.throws(() => parseYoroOpen("eval something"), /unsupported or malformed/);
});

test("rejects empty origin references", () => {
  assert.throws(() => parseYoroOpen('☆ ""'), /cannot be empty/);
});

test("does not interpret present/absent markers as numeric values", () => {
  const [present, absent] = parseYoroOpen("● item\n○ item").declarations;
  assert.equal(present.kind, "Present");
  assert.equal(absent.kind, "Absent");
  assert.equal("value" in present, false);
  assert.equal("value" in absent, false);
});
