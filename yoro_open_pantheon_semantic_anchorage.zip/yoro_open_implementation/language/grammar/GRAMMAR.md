# Ɣơ OPEN grammar prototype v0.1

The prototype is UTF-8 text, one declaration per line. Whitespace separates tokens; quoted strings use JSON string escaping. `#` begins a comment outside a quoted string.

```ebnf
document       = { declaration } ;
declaration    = scope | origin | present | absent | direction | intersection | transform ;
scope          = "§" "scope" identifier ;
origin         = "☆" json-string ;
present        = "●" identifier ;
absent         = "○" identifier ;
direction      = "Ẅ" identifier ;
intersection   = "u.v." identifier identifier ;
transform      = "→" identifier identifier ;
identifier     = letter , { letter | digit | "_" | "-" | "." } ;
```

## Context and typing

- `☆ "origin-id"` creates a reference to an origin record. It does not encode a zero byte by itself.
- Zero-byte exchange substitution is performed by the byte codec, not this parser. Each `☆` exchange token must retain a reversible mapping to the original byte offset and source digest.
- `●` and `○` are explicit present/absent declarations. Neither means numeric one/zero.
- `u.v.` declares an intersection between two identifiers; it does not imply equivalence.
- `→` records a directed relation only. It is not an executable function call.
- `°` is reserved for a future context-declared transition boundary and is rejected by this prototype until its production is specified.

Unknown syntax is rejected. No implicit coercion, execution, imports, loops, I/O, or arbitrary expressions are supported.
