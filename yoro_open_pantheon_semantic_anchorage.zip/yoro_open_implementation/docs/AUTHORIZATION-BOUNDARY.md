# Authorization boundary

This workbench is a local preparation artifact. It does not create branches, push commits, alter protected refs, replace native files, or execute repository operations.

A repository mutation is eligible only when the applicable repository policy is satisfied by a genuine, independently verifiable approval artifact bound to the exact repository, immutable target commit, request digest, operation, scope, reviewer identity, signature, freshness/expiry, and revocation state. A conversational acknowledgement is not substituted for a required independent reviewer artifact.

Until the authorization evaluator returns `AuthorizationStatus.AUTHORIZED`, repository mutations remain blocked. Read-only inspection and local artifact preparation do not imply approval for subsequent mutation.
