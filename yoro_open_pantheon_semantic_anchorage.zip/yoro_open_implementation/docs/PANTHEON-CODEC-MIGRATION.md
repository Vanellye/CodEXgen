# PANTHEON codec bridge and migration contract

Status: local implementation prototype; no repository writes or native replacements performed.

## 1. Canonical bytes are the authority

The original byte sequence is the canonical record. Every codec is a reversible representation profile, not a replacement for source bytes. The same `test-vectors/pantheon-byte-vectors.tsv` file is consumed by JavaScript, Python, and Kotlin conformance runners.

Implemented profiles:

- `og-base5-syllables/0.1`: four base-5 syllables per byte (`ba`, `be`, `bi`, `bo`, `bu`).
- `og-nibble-pairs/0.2`: high-nibble vowel plus low-nibble consonant, using the versioned 16+16 alphabets in the adapters.
- `yoro-star-v2/2` (`Ɣơ/2:`): the existing repository format; each byte is represented by exactly eight `☆`/`k` bits. This is preserved exactly and checked against the original repository fixture.
- `yoro-star-exchange/1`: zero bytes appear as one `☆` token; nonzero bytes remain two-digit lowercase hex tokens. This is a separate higher-level exchange view, not a replacement for `Ɣơ/2:`. The record includes source SHA-256, byte length, zero offsets, and canonical hex.
- `pantheon-positive-possibility/1`: each zero byte additionally produces a `·` semantic record with its original byte offset and digest. This is metadata, not a mutation of the exchange or canonical bytes.

`Ɣơ/2:` and `yoro-star-exchange/1` are distinct reversible encodings. `☆` and `·` also have distinct jobs: `☆` is the byte-exchange token; `·` is the positive-possibility interpretation. Both are reversible only through the origin record.

## 2. PANTHEON translation envelope

Each future translation artifact must carry:

- `pantheon_schema_version` and `grammar_version`;
- `source_language`, `source_path`, `source_revision`, `source_sha256`;
- `source_byte_length`, `source_encoding`, and canonical byte reference;
- `codec_profile` and codec version;
- `semantic_ir_version`, `translation_target`, and translator version;
- `ov` initial-intent record, preserved verbatim with source reference;
- symbol/lexeme registry version;
- source and destination hashes;
- conformance, behavioral parity, and review evidence;
- migration state and rollback reference.

Translation is predetermined only in the sense that the mapping rules, target, profile, and expected outputs are fixed before conversion. The result remains a hypothesis until conformance and behavioral tests validate it.

## 3. Safe source-language replacement progression

The Kotlin, JavaScript, and Python implementations are independent conformance oracles during migration. PANTHEON may coordinate and eventually replace their roles, but must not erase them before the replacement has:

1. captured immutable source bytes and hashes;
2. parsed declarations and semantic structure;
3. produced Ɣơ/PANTHEON output with source maps;
4. round-tripped all shared vectors exactly;
5. passed language-specific regression and behavioral parity tests;
6. passed independent review and explicit scoped authorization;
7. completed staged cutover with a tested rollback path.

The local `migration/pantheon-rotation.mjs` planner enforces sequential evidence-bearing stages and refuses to self-assert authorization or replacement. The rotation process is versioned and dual-readable. Old profiles and decoders remain available until every dependent artifact has migrated. No in-place alphabet rotation or silent reinterpretation is permitted.

## 4. Meaning preservation and lexemes

The exact user-supplied lexemes `abra`, `cada`, `bra`, `viola`, `vwala`, `ta`, `da`, `di`, `de`, `ti`, `wi`, `we`, `wallah`, and `excedra` are stored as opaque UTF-8 lexemes in `migration/lexeme-seeds.json`. No meanings are invented. A lexeme may acquire a meaning only through a versioned definition, author/source reference, examples, and review.

`ov` is the immutable original-intent/narrative reference. English conversion is a separate target profile; it must retain source wording, token boundaries, transliteration, semantic notes, and uncertainty rather than normalizing away unfamiliar expressions.

## 5. Bias and truth evidence

Bias and misinformation markers annotate claims; they do not stain or overwrite source material. A claim record distinguishes source quotation, paraphrase, inference, contradiction, unknown, and verified evidence. Each marker records who/what assigned it, rule/model version, evidence references, confidence, timestamp, and appeal/review status. `☆True Truth☆` is treated as an aspiration for evidence traceability, not a self-certifying truth label.

## 6. File and folder policy

The local package stores source, documentation, schemas, vectors, and generated artifacts in separate folders. File extensions are not proof of content type. Before conversion, inspect magic bytes/content, declared media type, encoding, parser result, and source provenance.

- `.md`: UTF-8 Markdown documentation.
- `.docx`: modern Word document output when a Word artifact is required.
- `.doc`: legacy binary Word format; do not fake it by writing Markdown under a `.doc` extension.
- `.PhD`: custom PANTHEON handoff descriptor in UTF-8 text; it is not a standard academic or office format.
- `.pdf`, `.html`, `.adb`, `.pic`, `.abc`, `.tnt`, `.pcp` and other extensions: preserve originals; identify actual content before assigning a conversion route. Some names may be application-specific or ambiguous.

Generated documentation is additive. Duplicates use stable content hashes and manifest references; they do not overwrite originals. Deletion/tombstone (`ð`) requires a separate authorized operation and recovery evidence.

## 7. Authorization boundary

Local codec code and test vectors may be prepared and tested. Repository branch creation, commits, pushes, native-source replacement, merge, release, and privileged execution remain blocked until the repository's applicable policy verifies a genuine, independent, fresh, scoped approval artifact bound to the exact request digest and immutable target commit. A conversational request is not a substitute for that artifact.
