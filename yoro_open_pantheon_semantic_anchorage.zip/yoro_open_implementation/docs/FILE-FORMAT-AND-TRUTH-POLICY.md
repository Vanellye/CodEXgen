# File format, metadata, and evidence policy

1. Preserve every received file byte-for-byte before parsing or conversion.
2. Identify actual content using signatures/magic bytes and parser validation, not extension alone.
3. Store original, normalized copy, semantic extraction, and translated output separately.
4. Attach SHA-256, byte length, encoding, media type, acquisition source, timestamp, parser version, and transformation lineage.
5. Never overwrite an original with a converted file.
6. Mark uncertain or conflicting information as `Unknown`, `Unverified`, or `Conflicting`; never force it into a positive value.
7. Bias/misinformation labels are evidence annotations with reviewer/model provenance, not destructive edits.
8. Deduplicate by content hash while retaining every distinct source reference.
9. A `.PhD` descriptor is a custom PANTHEON metadata text file, not a standard `.doc` or `.docx` file.
