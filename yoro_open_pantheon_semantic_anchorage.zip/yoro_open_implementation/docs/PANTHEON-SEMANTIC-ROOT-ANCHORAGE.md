# PANTHEON Semantic Root Breakage & Historical Anchorage 0.1

## Purpose

Represent expressions as reversible, traceable semantic structures and regenerate reviewed forms across Ɣơ, PANTHEON, English, and other languages. Preserve the source expression and distinguish facts, beliefs, opinions, metaphors, questions, fiction, and unknown claims.

## Root breakage

`breakExpression` performs a lossless lexical segmentation. It retains every separator, punctuation mark, whitespace run, and Unicode surface string. Each unit has character and UTF-8 byte spans. This is a structural first pass, not a claim that lexical tokens are the smallest true meanings. Morphological, syntactic, idiomatic, and discourse analyses must be separate, versioned annotations.

## Anchorage and two-space traversal

`anchorLineage` defaults to two parent edges (“two spaces up”). It reports missing references and cycles rather than fabricating ancestry. Deeper history is a separately requested bounded traversal. Source refs, immutable revisions, and SHA-256 digests anchor records to evidence. Temporal relations around the Ɣơ birth boundary are explicit and may be `undetermined`.

A historical reference is not automatically true. The prototype reports `reference-recorded-not-truth-verified`; verification requires source inspection, provenance checks, corroboration where appropriate, and reviewer evidence.

## Semantic frame and expressive forms

Every semantic frame records speaker, modality, epistemic status, audience, register, confidence when supplied, and one or more reviewed expression forms. Subjective and figurative forms must not be promoted to factual assertions. A translation candidate carries its frame reference and requires review; no automatic semantic equivalence is asserted.

## Rotation contract

1. Preserve canonical bytes and original expression.
2. Break expressions into traceable units with reversible spans.
3. Attach historical anchors and provenance references.
4. Build a language-neutral semantic frame.
5. Generate candidate expressions only from declared mappings or reviewed translations.
6. Run round-trip, semantic, and behavioral validation.
7. Keep source and target representations side by side until independent review and authorization permit a staged cutover.

## Safety and authorization

This module is pure local data transformation. It does not write repositories, execute translated code, or authorize replacement. The existing PANTHEON migration state machine remains authoritative: authorization verification requires the independent policy verifier, and replacement requires a separately controlled cutover workflow.
