import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { encodeBase5, decodeBase5, encodeNibblePairs, decodeNibblePairs, toStarExchange, restoreStarExchange, positivePossibilityRecords, encodeYoroStarV2, decodeYoroStarV2, encodeOgBase5, decodeOgBase5 } from './pantheon-byte-codec.mjs';
const vectors = (await readFile(new URL('../../test-vectors/pantheon-byte-vectors.tsv', import.meta.url), 'utf8')).trimEnd().split('\n').slice(1).map(line => { const [id, hex, base5, nibble, star, yoroStarV2, ogBase64] = line.split('\t'); return { id, hex, base5, nibble, star: star ? star.split(',') : [], yoroStarV2, ogDocument: Buffer.from(ogBase64, 'base64').toString('utf8') }; });
const hex = b => [...b].map(x => x.toString(16).padStart(2,'0')).join('');
const sha = b => `sha256:${createHash('sha256').update(b).digest('hex')}`;
test('all shared vectors round-trip through base5 and nibble profiles', () => {
  for (const v of vectors) {
    const bytes = Uint8Array.from(v.hex.match(/../g) ?? [], x => parseInt(x,16));
    assert.equal(encodeBase5(bytes), v.base5, v.id);
    assert.equal(hex(decodeBase5(v.base5)), v.hex, v.id);
    assert.equal(encodeOgBase5(bytes), v.ogDocument, v.id);
    assert.equal(hex(decodeOgBase5(v.ogDocument)), v.hex, v.id);
    assert.equal(encodeNibblePairs(bytes), v.nibble, v.id);
    assert.equal(hex(decodeNibblePairs(v.nibble)), v.hex, v.id);
    assert.equal(encodeYoroStarV2(bytes), v.yoroStarV2, v.id);
    assert.equal(hex(decodeYoroStarV2(v.yoroStarV2)), v.hex, v.id);
  }
});
test('star exchange replaces every zero with ☆ and restores exact bytes', () => {
  for (const v of vectors) {
    const bytes = Uint8Array.from(v.hex.match(/../g) ?? [], x => parseInt(x,16));
    const view = toStarExchange(bytes, sha(bytes));
    assert.deepEqual(view.tokens, v.star, v.id);
    assert.equal(hex(restoreStarExchange(view, sha)), v.hex, v.id);
  }
});
test('star exchange rejects tampered origin digest and offsets', () => {
  const bytes = Uint8Array.of(0,1,0);
  const view = toStarExchange(bytes, sha(bytes));
  assert.throws(() => restoreStarExchange({...view, sourceDigest:'sha256:bad'}, sha), /digest mismatch/);
  assert.throws(() => restoreStarExchange({...view, zeroOffsets:[1]}, sha), /offset provenance mismatch/);
});
test('canonical source array is not mutated by exchange', () => {
  const bytes = Uint8Array.of(0, 0, 65, 0);
  const before = hex(bytes);
  toStarExchange(bytes, sha(bytes));
  assert.equal(hex(bytes), before);
});

test('positive possibility records are generated for every zero without changing bytes', () => {
  const bytes = Uint8Array.of(0, 1, 0, 0, 255); const before = hex(bytes); const records = positivePossibilityRecords(bytes, sha(bytes));
  assert.deepEqual(records.map(r => r.byteOffset), [0, 2, 3]);
  assert.ok(records.every(r => r.token === '·' && r.originalByte === 0 && r.reversible));
  assert.equal(hex(bytes), before);
});

test('existing repository Ɣơ/2 fixture and all 256 byte values round-trip', async () => {
  const lines = (await readFile(new URL('../../test-vectors/yoro-star-v2.tsv', import.meta.url), 'utf8')).split('\n').filter(x => x.trim() && !x.startsWith('#'));
  for (const line of lines) { const [id, hx, encoded] = line.split('|'); const bytes = Uint8Array.from(hx.match(/../g) ?? [], x => parseInt(x,16)); assert.equal(encodeYoroStarV2(bytes), encoded, id); assert.equal(hex(decodeYoroStarV2(encoded)), hx, id); }
  for (let i = 0; i < 256; i++) { const b = Uint8Array.of(i); assert.deepEqual(decodeYoroStarV2(encodeYoroStarV2(b)), b); }
});

test('OG/0 envelope rejects malformed lengths, payload counts and overflow', () => {
  const valid = encodeOgBase5(Uint8Array.of(0, 1));
  assert.throws(() => decodeOgBase5(valid.replace('length:2', 'length:3')), /token count/);
  assert.deepEqual(decodeOgBase5(valid.replace('length:2', 'length:02')), Uint8Array.of(0, 1));
  assert.throws(() => decodeOgBase5(valid.replace('length:2', 'length:２')), /length/);
  assert.throws(() => decodeOgBase5(valid.replace('ba-ba-ba-be', 'bu-bu-bu-bu')), /exceeds 255/);
});

test('all 256 byte values round-trip through base5 envelope and nibble pairs', () => {
  const bytes = Uint8Array.from({length:256}, (_, i) => i);
  assert.deepEqual(decodeOgBase5(encodeOgBase5(bytes)), bytes);
  assert.deepEqual(decodeNibblePairs(encodeNibblePairs(bytes)), bytes);
  const leading = Uint8Array.of(0, 0, 0, 1, 0, 0, 127, 255, 128, 255);
  assert.deepEqual(decodeOgBase5(encodeOgBase5(leading)), leading);
});
