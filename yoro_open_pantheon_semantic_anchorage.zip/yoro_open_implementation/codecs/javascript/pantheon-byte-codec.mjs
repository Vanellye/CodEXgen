/** Deterministic, data-only byte codecs. Canonical bytes are never mutated. */
export const BASE5 = Object.freeze(['ba', 'be', 'bi', 'bo', 'bu']);
export const HIGH_NIBBLES = Object.freeze(['a','e','i','o','u','y','ā','ē','ū','ă','ĕ','ĭ','ŏ','ŭ','ơ','æ']);
export const LOW_NIBBLES = Object.freeze(['b','c','d','f','g','h','j','k','l','m','n','p','r','s','t','v']);
export const CODEC_PROFILES = Object.freeze({
  base5: 'og-base5-syllables/0.1',
  nibble: 'og-nibble-pairs/0.2',
  star: 'yoro-star-exchange/1',
});

function assertBytes(input) {
  if (!(input instanceof Uint8Array)) throw new TypeError('Expected Uint8Array');
}

export function encodeBase5(bytes) {
  assertBytes(bytes);
  if (bytes.length === 0) return 'empty';
  return [...bytes].map(byte => {
    const digits = [Math.floor(byte / 125), Math.floor(byte / 25) % 5, Math.floor(byte / 5) % 5, byte % 5];
    return digits.map(d => BASE5[d]).join('-');
  }).join(', ');
}

export function decodeBase5(payload) {
  if (payload === 'empty') return new Uint8Array();
  if (typeof payload !== 'string' || !payload) throw new TypeError('Invalid base5 payload');
  const tokens = payload.split(', ');
  const bytes = tokens.map(token => {
    const syllables = token.split('-');
    if (syllables.length !== 4) throw new TypeError('Each byte token must contain four syllables');
    const values = syllables.map(t => BASE5.indexOf(t));
    if (values.some(v => v < 0)) throw new TypeError('Unknown base5 syllable');
    const value = values[0]*125 + values[1]*25 + values[2]*5 + values[3];
    if (value > 255) throw new TypeError('Decoded byte exceeds 255');
    return value;
  });
  return Uint8Array.from(bytes);
}

export function encodeOgBase5(bytes) {
  assertBytes(bytes);
  if (bytes.length > 1_000_000) throw new RangeError('Input exceeds OG/0 resource limit');
  return ['OG/0', 'kind:BYTES', `length:${bytes.length}`, `payload:${encodeBase5(bytes)}`, 'codec:og-base5-syllables/0.1'].join('\n');
}

export function decodeOgBase5(document) {
  if (typeof document !== 'string' || document.length > 40_000_256) throw new TypeError('Invalid or oversized OG/0 document');
  const lines = document.split(/\r?\n/u);
  if (lines.length === 6 && lines[5] === '') lines.pop();
  if (lines.length !== 5 || lines[0] !== 'OG/0' || lines[1] !== 'kind:BYTES' || !lines[2].startsWith('length:') || !lines[3].startsWith('payload:') || lines[4] !== 'codec:og-base5-syllables/0.1') {
    throw new TypeError('Malformed or unsupported OG/0 envelope');
  }
  const rawLength = lines[2].slice(7);
  if (!/^[0-9]+$/u.test(rawLength) || rawLength.length > 10) throw new TypeError('Invalid ASCII decimal length');
  const length = Number(rawLength);
  if (!Number.isSafeInteger(length) || length > 1_000_000) throw new RangeError('Declared length exceeds OG/0 resource limit');
  const bytes = decodeBase5(lines[3].slice(8));
  if (bytes.length !== length) throw new TypeError('Payload token count does not match declared length');
  return bytes;
}

export function encodeNibblePairs(bytes) {
  assertBytes(bytes);
  return [...bytes].map(b => HIGH_NIBBLES[b >> 4] + LOW_NIBBLES[b & 15]).join(' ');
}

export function decodeNibblePairs(text) {
  if (text === '') return new Uint8Array();
  if (typeof text !== 'string') throw new TypeError('Invalid nibble payload');
  const tokens = text.split(' ');
  const out = tokens.map(token => {
    if ([...token].length !== 2) throw new TypeError('Each nibble pair must contain two glyphs');
    const [hi, lo] = [...token];
    const h = HIGH_NIBBLES.indexOf(hi), l = LOW_NIBBLES.indexOf(lo);
    if (h < 0 || l < 0) throw new TypeError('Unknown nibble glyph');
    return (h << 4) | l;
  });
  return Uint8Array.from(out);
}

export function toStarExchange(bytes, sourceDigest) {
  assertBytes(bytes);
  if (typeof sourceDigest !== 'string' || !sourceDigest.startsWith('sha256:')) throw new TypeError('A SHA-256 source digest is required');
  const tokens = [...bytes].map(byte => byte === 0 ? '☆' : byte.toString(16).padStart(2, '0'));
  const zeroOffsets = [...bytes].flatMap((byte, offset) => byte === 0 ? [offset] : []);
  return Object.freeze({ profile: CODEC_PROFILES.star, sourceDigest, byteLength: bytes.length,
    tokens: Object.freeze(tokens), zeroOffsets: Object.freeze(zeroOffsets), canonicalHex: BufferlessHex(bytes) });
}

function BufferlessHex(bytes) { return [...bytes].map(b => b.toString(16).padStart(2, '0')).join(''); }

export function restoreStarExchange(view, verifySha256) {
  if (!view || view.profile !== CODEC_PROFILES.star || !Array.isArray(view.tokens) || typeof verifySha256 !== 'function') throw new TypeError('Invalid exchange view or digest verifier');
  const bytes = Uint8Array.from(view.tokens.map((token, i) => {
    if (token === '☆') return 0;
    if (typeof token !== 'string' || !/^[0-9a-f]{2}$/.test(token)) throw new TypeError(`Invalid exchange token at ${i}`);
    return Number.parseInt(token, 16);
  }));
  if (bytes.length !== view.byteLength) throw new Error('Byte length mismatch');
  const actual = verifySha256(bytes);
  if (actual !== view.sourceDigest) throw new Error('Source digest mismatch');
  const offsets = [...bytes].flatMap((b, i) => b === 0 ? [i] : []);
  if (JSON.stringify(offsets) !== JSON.stringify(view.zeroOffsets)) throw new Error('Zero-offset provenance mismatch');
  return bytes;
}

/** Semantic bridge: · is a searchable interpretation; ☆ remains the byte-exchange token. */
export function positivePossibilityRecords(bytes, sourceDigest) {
  assertBytes(bytes);
  if (typeof sourceDigest !== 'string' || !sourceDigest.startsWith('sha256:')) throw new TypeError('A SHA-256 source digest is required');
  return Object.freeze([...bytes].flatMap((byte, byteOffset) => byte === 0 ? [Object.freeze({
    kind: 'Possibility', token: '·', originalByte: 0, sourceDigest, byteOffset,
    profileVersion: 'pantheon-positive-possibility/1', reversible: true,
  })] : []));
}

/** Existing repository Ɣơ/2 profile: one ☆/k bit per symbol, eight symbols per byte. */
export function encodeYoroStarV2(bytes) {
  assertBytes(bytes);
  return 'Ɣơ/2:' + [...bytes].map(byte => Array.from({ length: 8 }, (_, bit) =>
    (byte >> (7 - bit)) & 1 ? 'k' : '☆').join('')).join('.');
}

export function decodeYoroStarV2(text) {
  const prefix = 'Ɣơ/2:';
  if (typeof text !== 'string' || !text.startsWith(prefix)) throw new TypeError('Unsupported Ɣơ/2 profile');
  const body = text.slice(prefix.length);
  if (body === '') return new Uint8Array();
  const groups = body.split('.');
  if (groups.some(group => [...group].length !== 8 || /[^☆k]/u.test(group))) {
    throw new TypeError('Each byte must contain exactly eight ☆/k symbols');
  }
  return Uint8Array.from(groups, group => [...group].reduce((value, symbol) => (value << 1) | (symbol === 'k' ? 1 : 0), 0));
}
