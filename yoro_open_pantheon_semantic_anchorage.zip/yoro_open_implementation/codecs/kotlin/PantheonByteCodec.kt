import java.security.MessageDigest

/** Deterministic byte adapters. The caller retains ownership of canonical source bytes. */
object PantheonByteCodec {
    private val base5 = listOf("ba", "be", "bi", "bo", "bu")
    private val high = listOf("a","e","i","o","u","y","ā","ē","ū","ă","ĕ","ĭ","ŏ","ŭ","ơ","æ")
    private val low = listOf("b","c","d","f","g","h","j","k","l","m","n","p","r","s","t","v")
    const val STAR_PROFILE = "yoro-star-exchange/1"

    data class PossibilityRecord(val kind: String, val token: String, val originalByte: Int, val sourceDigest: String, val byteOffset: Int, val profileVersion: String, val reversible: Boolean)

    data class StarView(
        val profile: String,
        val sourceDigest: String,
        val byteLength: Int,
        val tokens: List<String>,
        val zeroOffsets: List<Int>,
        val canonicalHex: String
    )

    private fun hex(bytes: ByteArray) = bytes.joinToString("") { "%02x".format(it.toInt() and 0xff) }
    fun sha256(bytes: ByteArray): String = "sha256:" + MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }

    fun encodeYoroStarV2(bytes: ByteArray): String = "Ɣơ/2:" + bytes.joinToString(".") { raw ->
        (7 downTo 0).joinToString("") { bit -> if ((((raw.toInt() and 0xff) ushr bit) and 1) == 1) "k" else "☆" }
    }

    fun decodeYoroStarV2(payload: String): ByteArray {
        require(payload.startsWith("Ɣơ/2:")) { "Unsupported Ɣơ/2 profile" }
        val body = payload.removePrefix("Ɣơ/2:")
        if (body.isEmpty()) return byteArrayOf()
        val groups = body.split(".")
        require(groups.all { it.length == 8 && it.all { c -> c == '☆' || c == 'k' } }) { "Each byte must contain exactly eight ☆/k symbols" }
        return groups.map { group ->
            var value = 0
            group.forEach { c -> value = (value shl 1) or if (c == 'k') 1 else 0 }
            value.toByte()
        }.toByteArray()
    }

    fun encodeBase5(bytes: ByteArray): String {
        if (bytes.isEmpty()) return "empty"
        return bytes.joinToString(", ") { raw ->
            val b = raw.toInt() and 0xff
            listOf(b / 125, (b / 25) % 5, (b / 5) % 5, b % 5).joinToString("-") { base5[it] }
        }
    }

    fun decodeBase5(payload: String): ByteArray {
        if (payload == "empty") return byteArrayOf()
        require(payload.isNotEmpty()) { "invalid base5 payload" }
        return payload.split(", ").map { token ->
            val syllables = token.split("-")
            require(syllables.size == 4) { "each byte token must contain four syllables" }
            val digits = syllables.map { base5.indexOf(it).also { n -> require(n >= 0) { "unknown base5 syllable" } } }
            val value = digits[0] * 125 + digits[1] * 25 + digits[2] * 5 + digits[3]
            require(value <= 255) { "decoded byte exceeds 255" }
            value.toByte()
        }.toByteArray()
    }

    fun encodeOgBase5(bytes: ByteArray): String {
        require(bytes.size <= 1_000_000) { "input exceeds OG/0 resource limit" }
        return listOf("OG/0", "kind:BYTES", "length:${bytes.size}", "payload:${encodeBase5(bytes)}", "codec:og-base5-syllables/0.1").joinToString("\n")
    }

    fun decodeOgBase5(document: String): ByteArray {
        require(document.length <= 40_000_256) { "document exceeds maximum size" }
        val lines = document.split(Regex("\\r?\\n")).let { if (it.lastOrNull() == "") it.dropLast(1) else it }
        require(lines.size == 5 && lines[0] == "OG/0" && lines[1] == "kind:BYTES" && lines[2].startsWith("length:") && lines[3].startsWith("payload:") && lines[4] == "codec:og-base5-syllables/0.1") { "malformed or unsupported OG/0 envelope" }
        val rawLength = lines[2].substring(7)
        require(rawLength.matches(Regex("[0-9]+")) && rawLength.length <= 10) { "invalid ASCII decimal length" }
        val length = rawLength.toLongOrNull() ?: throw IllegalArgumentException("invalid length")
        require(length <= 1_000_000) { "declared length exceeds OG/0 resource limit" }
        val data = decodeBase5(lines[3].substring(8))
        require(data.size.toLong() == length) { "payload token count does not match declared length" }
        return data
    }

    fun encodeNibblePairs(bytes: ByteArray): String = bytes.joinToString(" ") { raw ->
        val b = raw.toInt() and 0xff
        high[b ushr 4] + low[b and 15]
    }

    fun decodeNibblePairs(payload: String): ByteArray {
        if (payload.isEmpty()) return byteArrayOf()
        return payload.split(" ").map { token ->
            require(token.length == 2) { "each nibble pair must contain two glyphs" }
            val h = high.indexOf(token.substring(0, 1)); val l = low.indexOf(token.substring(1, 2))
            require(h >= 0 && l >= 0) { "unknown nibble glyph" }
            ((h shl 4) or l).toByte()
        }.toByteArray()
    }

    fun positivePossibilityRecords(bytes: ByteArray, sourceDigest: String): List<PossibilityRecord> {
        require(sourceDigest.startsWith("sha256:")) { "SHA-256 source digest is required" }
        return bytes.indices.filter { bytes[it].toInt() == 0 }.map { offset ->
            PossibilityRecord("Possibility", "·", 0, sourceDigest, offset, "pantheon-positive-possibility/1", true)
        }
    }

    fun toStarExchange(bytes: ByteArray, sourceDigest: String): StarView {
        require(sourceDigest.startsWith("sha256:")) { "SHA-256 source digest is required" }
        val tokens = bytes.map { raw -> val b = raw.toInt() and 0xff; if (b == 0) "☆" else "%02x".format(b) }
        return StarView(STAR_PROFILE, sourceDigest, bytes.size, tokens,
            bytes.indices.filter { bytes[it].toInt() == 0 }, hex(bytes))
    }

    fun restoreStarExchange(view: StarView): ByteArray {
        require(view.profile == STAR_PROFILE) { "invalid exchange profile" }
        val result = ByteArray(view.tokens.size) { i ->
            val token = view.tokens[i]
            when {
                token == "☆" -> 0.toByte()
                token.matches(Regex("[0-9a-f]{2}")) -> token.toInt(16).toByte()
                else -> throw IllegalArgumentException("invalid exchange token at $i")
            }
        }
        require(result.size == view.byteLength) { "byte length mismatch" }
        require(sha256(result) == view.sourceDigest) { "source digest mismatch" }
        require(result.indices.filter { result[it].toInt() == 0 } == view.zeroOffsets) { "zero-offset provenance mismatch" }
        return result
    }
}
