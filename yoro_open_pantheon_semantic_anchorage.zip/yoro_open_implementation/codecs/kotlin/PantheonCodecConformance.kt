import java.io.File

// Run from package root: kotlinc codecs/kotlin/PantheonByteCodec.kt codecs/kotlin/PantheonCodecConformance.kt -include-runtime -d /tmp/pantheon-vectors.jar
fun main(args: Array<String>) {
    val vectorFile = File(args.getOrNull(0) ?: "test-vectors/pantheon-byte-vectors.tsv")
    val rows = vectorFile.readLines().drop(1).filter { it.isNotBlank() }
    for (row in rows) {
        val cols = row.split('\t')
        require(cols.size == 7) { "bad shared vector row: $row" }
        val id = cols[0]; val hex = cols[1]; val base5 = cols[2]; val nibble = cols[3]; val star = cols[4]; val yoro2 = cols[5]; val ogDocument = String(java.util.Base64.getDecoder().decode(cols[6]), Charsets.UTF_8)
        val bytes = if (hex.isEmpty()) byteArrayOf() else hex.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
        check(PantheonByteCodec.encodeBase5(bytes) == base5) { "$id base5 encode" }
        check(PantheonByteCodec.decodeBase5(base5).contentEquals(bytes)) { "$id base5 decode" }
        check(PantheonByteCodec.encodeOgBase5(bytes) == ogDocument) { "$id OG/0 encode" }
        check(PantheonByteCodec.decodeOgBase5(ogDocument).contentEquals(bytes)) { "$id OG/0 decode" }
        check(PantheonByteCodec.encodeNibblePairs(bytes) == nibble) { "$id nibble encode" }
        check(PantheonByteCodec.decodeNibblePairs(nibble).contentEquals(bytes)) { "$id nibble decode" }
        check(PantheonByteCodec.encodeYoroStarV2(bytes) == yoro2) { "$id Ɣơ/2 encode" }
        check(PantheonByteCodec.decodeYoroStarV2(yoro2).contentEquals(bytes)) { "$id Ɣơ/2 decode" }
        val digest = PantheonByteCodec.sha256(bytes)
        val possibilities = PantheonByteCodec.positivePossibilityRecords(bytes, digest)
        check(possibilities.map { it.byteOffset } == bytes.indices.filter { bytes[it].toInt() == 0 }) { "$id possibility offsets" }
        check(possibilities.all { it.token == "·" && it.originalByte == 0 && it.reversible }) { "$id possibility semantics" }
        val view = PantheonByteCodec.toStarExchange(bytes, digest)
        check(view.tokens.joinToString(",") == star) { "$id star exchange" }
        check(PantheonByteCodec.restoreStarExchange(view).contentEquals(bytes)) { "$id star restore" }
    }
    val ogTwo = PantheonByteCodec.encodeOgBase5(byteArrayOf(0, 1))
    check(PantheonByteCodec.decodeOgBase5(ogTwo.replace("length:2", "length:02")).contentEquals(byteArrayOf(0, 1))) { "OG/0 legacy leading-zero length compatibility" }
    check(runCatching { PantheonByteCodec.decodeOgBase5(ogTwo.replace("length:2", "length:２")) }.isFailure) { "OG/0 non-ASCII length rejection" }
    val repoVectors = File(args.getOrNull(1) ?: "test-vectors/yoro-star-v2.tsv")
    var repoCount = 0
    repoVectors.readLines().filter { it.isNotBlank() && !it.startsWith("#") }.forEach { line ->
        val fields = line.split('|')
        require(fields.size == 3) { "Malformed repository vector: $line" }
        val raw = if (fields[1].isEmpty()) byteArrayOf() else fields[1].chunked(2).map { it.toInt(16).toByte() }.toByteArray()
        check(PantheonByteCodec.encodeYoroStarV2(raw) == fields[2]) { "Repository vector encode: ${fields[0]}" }
        check(PantheonByteCodec.decodeYoroStarV2(fields[2]).contentEquals(raw)) { "Repository vector decode: ${fields[0]}" }
        repoCount++
    }
    for (value in 0..255) {
        val one = byteArrayOf(value.toByte())
        check(PantheonByteCodec.decodeYoroStarV2(PantheonByteCodec.encodeYoroStarV2(one)).contentEquals(one)) { "Ɣơ/2 byte $value" }
        check(PantheonByteCodec.decodeOgBase5(PantheonByteCodec.encodeOgBase5(one)).contentEquals(one)) { "OG/0 byte $value" }
        check(PantheonByteCodec.decodeNibblePairs(PantheonByteCodec.encodeNibblePairs(one)).contentEquals(one)) { "nibble byte $value" }
    }
    val allBytes = ByteArray(256) { it.toByte() }
    check(PantheonByteCodec.decodeOgBase5(PantheonByteCodec.encodeOgBase5(allBytes)).contentEquals(allBytes)) { "OG/0 all-byte sequence" }
    check(PantheonByteCodec.decodeNibblePairs(PantheonByteCodec.encodeNibblePairs(allBytes)).contentEquals(allBytes)) { "nibble all-byte sequence" }
    println("PANTHEON Kotlin shared vectors: ${rows.size}; existing star-v2 vectors: $repoCount; exhaustive byte values across star-v2, OG/0, and nibble profiles: 256 passed")
}
