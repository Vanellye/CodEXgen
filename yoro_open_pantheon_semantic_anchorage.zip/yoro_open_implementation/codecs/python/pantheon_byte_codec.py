"""Reference implementation of the PANTHEON shared byte codec profiles."""
BASE5 = ('ba', 'be', 'bi', 'bo', 'bu')
HIGH = ('a','e','i','o','u','y','ā','ē','ū','ă','ĕ','ĭ','ŏ','ŭ','ơ','æ')
LOW = ('b','c','d','f','g','h','j','k','l','m','n','p','r','s','t','v')
STAR_PROFILE = 'yoro-star-exchange/1'

def _bytes(value):
    if not isinstance(value, (bytes, bytearray, memoryview)):
        raise TypeError('expected bytes-like input')
    return bytes(value)

def encode_base5(value):
    data = _bytes(value)
    if not data: return 'empty'
    return ', '.join('-'.join(BASE5[d] for d in (b // 125, (b // 25) % 5, (b // 5) % 5, b % 5)) for b in data)

def decode_base5(payload):
    if payload == 'empty': return b''
    if not isinstance(payload, str) or not payload: raise ValueError('invalid base5 payload')
    output = bytearray()
    for token in payload.split(', '):
        syllables = token.split('-')
        if len(syllables) != 4: raise ValueError('each byte token must contain four syllables')
        try: digits = [BASE5.index(t) for t in syllables]
        except ValueError as exc: raise ValueError('unknown base5 syllable') from exc
        value = digits[0]*125 + digits[1]*25 + digits[2]*5 + digits[3]
        if value > 255: raise ValueError('decoded byte exceeds 255')
        output.append(value)
    return bytes(output)

def encode_og_base5(value):
    data = _bytes(value)
    if len(data) > 1_000_000: raise ValueError('input exceeds OG/0 resource limit')
    return '\n'.join(('OG/0', 'kind:BYTES', f'length:{len(data)}', f'payload:{encode_base5(data)}', 'codec:og-base5-syllables/0.1'))

def decode_og_base5(document):
    if not isinstance(document, str) or len(document) > 40_000_256: raise ValueError('invalid or oversized OG/0 document')
    lines = document.splitlines()
    if len(lines) != 5 or lines[0] != 'OG/0' or lines[1] != 'kind:BYTES' or not lines[2].startswith('length:') or not lines[3].startswith('payload:') or lines[4] != 'codec:og-base5-syllables/0.1':
        raise ValueError('malformed or unsupported OG/0 envelope')
    raw_length = lines[2][7:]
    if not raw_length.isascii() or not raw_length.isdecimal() or len(raw_length) > 10:
        raise ValueError('invalid ASCII decimal length')
    length = int(raw_length)
    if length > 1_000_000: raise ValueError('declared length exceeds OG/0 resource limit')
    data = decode_base5(lines[3][8:])
    if len(data) != length: raise ValueError('payload token count does not match declared length')
    return data

def encode_nibble_pairs(value):
    return ' '.join(HIGH[b >> 4] + LOW[b & 15] for b in _bytes(value))

def decode_nibble_pairs(payload):
    if payload == '': return b''
    if not isinstance(payload, str): raise TypeError('nibble payload must be text')
    out = bytearray()
    for token in payload.split(' '):
        if len(token) != 2: raise ValueError('each nibble pair must contain two glyphs')
        try: hi, lo = HIGH.index(token[0]), LOW.index(token[1])
        except ValueError as exc: raise ValueError('unknown nibble glyph') from exc
        out.append((hi << 4) | lo)
    return bytes(out)

def to_star_exchange(value, source_digest):
    data = _bytes(value)
    if not isinstance(source_digest, str) or not source_digest.startswith('sha256:'):
        raise ValueError('SHA-256 source digest is required')
    return {
        'profile': STAR_PROFILE, 'sourceDigest': source_digest,
        'byteLength': len(data), 'tokens': ['☆' if b == 0 else f'{b:02x}' for b in data],
        'zeroOffsets': [i for i, b in enumerate(data) if b == 0],
        'canonicalHex': data.hex(),
    }

def restore_star_exchange(view, digest_function):
    if not isinstance(view, dict) or view.get('profile') != STAR_PROFILE:
        raise ValueError('invalid exchange profile')
    data = bytearray()
    for i, token in enumerate(view.get('tokens', [])):
        if token == '☆': data.append(0)
        elif isinstance(token, str) and len(token) == 2 and all(c in '0123456789abcdef' for c in token): data.append(int(token, 16))
        else: raise ValueError(f'invalid exchange token at {i}')
    result = bytes(data)
    if len(result) != view.get('byteLength'): raise ValueError('byte length mismatch')
    if digest_function(result) != view.get('sourceDigest'): raise ValueError('source digest mismatch')
    if [i for i, b in enumerate(result) if b == 0] != view.get('zeroOffsets'): raise ValueError('zero-offset provenance mismatch')
    return result

def positive_possibility_records(value, source_digest):
    """Return · interpretation records for zeros without changing canonical bytes."""
    data = _bytes(value)
    if not isinstance(source_digest, str) or not source_digest.startswith('sha256:'):
        raise ValueError('SHA-256 source digest is required')
    return [
        {'kind': 'Possibility', 'token': '·', 'originalByte': 0,
         'sourceDigest': source_digest, 'byteOffset': i,
         'profileVersion': 'pantheon-positive-possibility/1', 'reversible': True}
        for i, byte in enumerate(data) if byte == 0
    ]

YORO_STAR_V2_PREFIX = 'Ɣơ/2:'
def encode_yoro_star_v2(value):
    data = _bytes(value)
    return YORO_STAR_V2_PREFIX + '.'.join(''.join('k' if (byte >> bit) & 1 else '☆' for bit in range(7, -1, -1)) for byte in data)

def decode_yoro_star_v2(payload):
    if not isinstance(payload, str) or not payload.startswith(YORO_STAR_V2_PREFIX):
        raise ValueError('unsupported Ɣơ/2 profile')
    body = payload[len(YORO_STAR_V2_PREFIX):]
    if not body: return b''
    groups = body.split('.')
    if any(len(group) != 8 or any(c not in '☆k' for c in group) for group in groups):
        raise ValueError('each byte must contain exactly eight ☆/k symbols')
    return bytes(int(''.join('1' if c == 'k' else '0' for c in group), 2) for group in groups)
