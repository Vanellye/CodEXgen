import hashlib
import pathlib
import unittest
from pantheon_byte_codec import encode_base5, decode_base5, encode_nibble_pairs, decode_nibble_pairs, to_star_exchange, restore_star_exchange, positive_possibility_records, encode_yoro_star_v2, decode_yoro_star_v2, encode_og_base5, decode_og_base5

ROOT = pathlib.Path(__file__).resolve().parents[2]
VECTORS = ROOT / 'test-vectors' / 'pantheon-byte-vectors.tsv'
def sha(data): return 'sha256:' + hashlib.sha256(data).hexdigest()

class SharedVectorTests(unittest.TestCase):
    def test_all_shared_vectors(self):
        rows = VECTORS.read_text(encoding='utf-8').splitlines()[1:]
        for row in rows:
            import base64
            ident, hx, b5, nib, star, yoro2, og_b64 = row.split('\t')
            with self.subTest(vector=ident):
                data = bytes.fromhex(hx)
                self.assertEqual(encode_base5(data), b5)
                self.assertEqual(decode_base5(b5), data)
                og_doc = base64.b64decode(og_b64).decode('utf-8')
                self.assertEqual(encode_og_base5(data), og_doc)
                self.assertEqual(decode_og_base5(og_doc), data)
                self.assertEqual(encode_nibble_pairs(data), nib)
                self.assertEqual(decode_nibble_pairs(nib), data)
                self.assertEqual(encode_yoro_star_v2(data), yoro2)
                self.assertEqual(decode_yoro_star_v2(yoro2), data)
                view = to_star_exchange(data, sha(data))
                self.assertEqual(','.join(view['tokens']), star)
                self.assertEqual(restore_star_exchange(view, sha), data)

    def test_positive_possibility_offsets_preserve_source(self):
        data = b'\x00\x01\x00\x00\xff'
        records = positive_possibility_records(data, sha(data))
        self.assertEqual([r['byteOffset'] for r in records], [0, 2, 3])
        self.assertTrue(all(r['token'] == '·' and r['reversible'] for r in records))
        self.assertEqual(data, b'\x00\x01\x00\x00\xff')

    def test_existing_repository_vectors_and_all_byte_values(self):
        path = ROOT / 'test-vectors' / 'yoro-star-v2.tsv'
        for line in path.read_text(encoding='utf-8').splitlines():
            if not line.strip() or line.startswith('#'): continue
            ident, hx, expected = line.split('|')
            data = bytes.fromhex(hx)
            self.assertEqual(encode_yoro_star_v2(data), expected, ident)
            self.assertEqual(decode_yoro_star_v2(expected), data, ident)
        for value in range(256):
            data = bytes([value])
            self.assertEqual(decode_yoro_star_v2(encode_yoro_star_v2(data)), data)

    def test_all_byte_values_round_trip_through_base5_envelope_and_nibbles(self):
        data = bytes(range(256))
        self.assertEqual(decode_og_base5(encode_og_base5(data)), data)
        self.assertEqual(decode_nibble_pairs(encode_nibble_pairs(data)), data)
        leading = bytes.fromhex('0000000100007fff80ff')
        self.assertEqual(decode_og_base5(encode_og_base5(leading)), leading)

    def test_og_envelope_rejects_malformed_length_and_overflow(self):
        valid = encode_og_base5(b'\x00\x01')
        self.assertEqual(decode_og_base5(valid.replace('length:2', 'length:02')), b'\x00\x01')
        with self.assertRaisesRegex(ValueError, 'ASCII decimal'):
            decode_og_base5(valid.replace('length:2', 'length:２'))
        with self.assertRaisesRegex(ValueError, 'exceeds 255'):
            decode_og_base5(valid.replace('ba-ba-ba-be', 'bu-bu-bu-bu'))

    def test_tampered_digest_rejected(self):
        data = b'\x00\x01\x00'
        view = to_star_exchange(data, sha(data))
        view['sourceDigest'] = 'sha256:wrong'
        with self.assertRaisesRegex(ValueError, 'digest mismatch'):
            restore_star_exchange(view, sha)

if __name__ == '__main__': unittest.main()
