import test from 'node:test';
import assert from 'node:assert/strict';
import { planRotation, createMigrationRecord, advanceMigration } from './pantheon-rotation.mjs';

test('rotation plan retains old decoder and canonical source', () => {
  const plan = planRotation({ sourceProfile:'yoro-star-v2/2', targetProfile:'yoro-pantheon/3', sourceDigest:'sha256:abc', dependentArtifacts:['artifact:a'] });
  assert.equal(plan.retainSourceDecoder, true);
  assert.equal(plan.mutateCanonicalSource, false);
  assert.equal(plan.cutoverEligible, false);
});

test('migration requires sequential evidence-backed progression', () => {
  const plan = planRotation({ sourceProfile:'old/1', targetProfile:'new/2', sourceDigest:'sha256:abc', dependentArtifacts:[] });
  const start = createMigrationRecord(plan);
  assert.throws(() => advanceMigration(start, 'translated', {}), /exactly one step/);
  const represented = advanceMigration(start, 'represented', { sourceDigest:'sha256:abc', sourceByteLength:'3', codecProfile:'new/2', canonicalByteReference:'blob:abc' });
  assert.equal(represented.stage, 'represented');
  assert.equal(represented.history.length, 1);
});

test('metadata cannot self-authorize or mark a replacement complete', () => {
  const record = { stage:'independently-reviewed', history:[] };
  assert.throws(() => advanceMigration(record, 'authorization-verified', {
    authorizationArtifactRef:'approval:1', verificationReceiptRef:'receipt:1', requestDigest:'sha256:req',
    targetCommit:'commit:1', scopeRef:'scope:1', expiresAt:'2099-01-01T00:00:00Z'
  }), /independent repository policy verifier/);
  assert.throws(() => advanceMigration({stage:'staged',history:[]}, 'replaced', {cutoverEvidenceRef:'x',rollbackTestRef:'y'}), /separately verified authorization/);
});
