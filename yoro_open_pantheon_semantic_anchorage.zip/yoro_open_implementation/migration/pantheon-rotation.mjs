/** Pure planning/state validation for versioned, reversible PANTHEON rotation. */
export const MIGRATION_STAGES = Object.freeze([
  'discovered', 'represented', 'translated', 'conformance-tested', 'parity-tested',
  'independently-reviewed', 'authorization-verified', 'staged', 'replaced'
]);

const REQUIRED = Object.freeze({
  represented: ['sourceDigest', 'sourceByteLength', 'codecProfile', 'canonicalByteReference'],
  translated: ['semanticIrRef', 'translationTarget', 'translatorVersion', 'ovReference'],
  'conformance-tested': ['sharedVectorRunRef', 'roundTripDigest'],
  'parity-tested': ['behavioralParityReportRef', 'regressionRunRef'],
  'independently-reviewed': ['reviewerIdentity', 'reviewEvidenceRef'],
  'authorization-verified': ['authorizationArtifactRef', 'verificationReceiptRef', 'requestDigest', 'targetCommit', 'scopeRef', 'expiresAt'],
  staged: ['stagingRunRef', 'rollbackRef'],
  replaced: ['cutoverEvidenceRef', 'rollbackTestRef']
});

export function planRotation({ sourceProfile, targetProfile, sourceDigest, dependentArtifacts }) {
  for (const [name, value] of Object.entries({ sourceProfile, targetProfile, sourceDigest })) {
    if (typeof value !== 'string' || !value.trim()) throw new TypeError(`${name} is required`);
  }
  if (sourceProfile === targetProfile) throw new TypeError('Rotation requires distinct versioned profiles');
  if (!Array.isArray(dependentArtifacts) || dependentArtifacts.some(x => typeof x !== 'string' || !x.trim())) {
    throw new TypeError('dependentArtifacts must be an array of non-empty references');
  }
  return Object.freeze({
    kind: 'PantheonRotationPlan', sourceProfile, targetProfile, sourceDigest,
    dependentArtifacts: Object.freeze([...dependentArtifacts]),
    readPolicy: 'dual-read', writePolicy: 'new-version-only-after-validation',
    retainSourceDecoder: true, mutateCanonicalSource: false,
    cutoverEligible: false, initialStage: 'discovered'
  });
}

export function advanceMigration(record, nextStage, evidence = {}) {
  if (!record || !MIGRATION_STAGES.includes(record.stage)) throw new TypeError('Invalid migration record');
  const current = MIGRATION_STAGES.indexOf(record.stage);
  const next = MIGRATION_STAGES.indexOf(nextStage);
  if (next !== current + 1) throw new Error('Migration stages must advance exactly one step');
  const required = REQUIRED[nextStage] ?? [];
  const missing = required.filter(key => typeof evidence[key] !== 'string' || !evidence[key].trim());
  if (missing.length) throw new Error(`Missing evidence: ${missing.join(', ')}`);
  if (nextStage === 'authorization-verified') {
    throw new Error('Authorization transition requires the independent repository policy verifier; metadata alone cannot authorize it');
  }
  if (nextStage === 'replaced') {
    throw new Error('Replacement requires a separately verified authorization and controlled cutover workflow');
  }
  const event = Object.freeze({ from: record.stage, to: nextStage, evidence: Object.freeze({ ...evidence }) });
  return Object.freeze({ ...record, stage: nextStage,
    history: Object.freeze([...(record.history ?? []), event]) });
}

export function createMigrationRecord(plan) {
  if (!plan || plan.kind !== 'PantheonRotationPlan') throw new TypeError('A validated rotation plan is required');
  return Object.freeze({ plan, stage: 'discovered', history: Object.freeze([]) });
}
