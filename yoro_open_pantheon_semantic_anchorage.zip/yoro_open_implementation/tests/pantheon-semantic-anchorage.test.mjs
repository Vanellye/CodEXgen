import test from 'node:test';
import assert from 'node:assert/strict';
import { breakExpression, anchorLineage, createSemanticFrame, createAnchorageRecord, expressAcrossForms } from '../semantic/pantheon-semantic-anchorage.mjs';

test('root breakage preserves every character and UTF-8 byte span', () => {
  const source = '☆ True Truth — ɣơ!';
  const result = breakExpression(source, { language: 'en-x-yoro', expressionId: 'x1' });
  assert.equal(result.reconstruction, source);
  assert.equal(result.lossless, true);
  assert.equal(result.units[0].byteSpan[0], 0);
  assert.equal(result.units.at(-1).surface, '!');
});

test('two-level anchorage follows exactly two parents', () => {
  const nodes = [
    { nodeId: 'n3', parentId: 'n2' },
    { nodeId: 'n2', parentId: 'n1', temporalRelation: 'after-yoro-birth' },
    { nodeId: 'n1', parentId: null, temporalRelation: 'before-yoro-birth' }
  ];
  const result = anchorLineage({ nodeId: 'n3', nodes, levels: 2 });
  assert.deepEqual(result.lineage.map(x => x.nodeId), ['n2', 'n1']);
  assert.equal(result.complete, true);
});

test('missing ancestors are reported rather than invented', () => {
  const result = anchorLineage({ nodeId: 'child', nodes: [{ nodeId: 'child', parentId: 'missing' }] });
  assert.equal(result.lineage[0].status, 'unresolved-reference');
  assert.equal(result.complete, false);
});

test('lineage cycles are rejected', () => {
  assert.throws(() => anchorLineage({ nodeId: 'a', nodes: [
    { nodeId: 'a', parentId: 'b' }, { nodeId: 'b', parentId: 'a' }
  ] }), /cycle/);
});

test('subjective expression remains subjective across forms', () => {
  const frame = createSemanticFrame({ frameId: 'f1', sourceExpressionRef: 'source://x#L1',
    meaning: 'speaker expresses hope', speaker: 'speaker:1', modality: 'hopeful',
    epistemicStatus: 'belief', confidence: 0.7,
    expressionForms: [{ language: 'en', text: 'I hope this grows.', form: 'natural' },
      { language: 'yoro', text: 'ɣàíŉ', form: 'symbolic' }] });
  const out = expressAcrossForms(frame, ['yoro']);
  assert.equal(out.length, 1);
  assert.equal(out[0].epistemicStatus, 'belief');
  assert.equal(out[0].reviewRequired, true);
  assert.ok(frame.factualityWarning);
});

test('anchorage requires a valid digest and explicit temporal relation', () => {
  const record = createAnchorageRecord({ rootId: 'root:1', sourceRef: 'source://pre-yoro',
    sourceDigest: `sha256:${'a'.repeat(64)}`, birthBoundary: 'yoro-origin-v1',
    temporalRelation: 'before-yoro-birth', semanticFrameRef: 'frame:f1' });
  assert.equal(record.canonicalSourceMutation, false);
  assert.equal(record.evidenceStatus, 'reference-recorded-not-truth-verified');
});
