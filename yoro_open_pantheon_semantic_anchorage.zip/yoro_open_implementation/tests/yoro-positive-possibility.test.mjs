import test from 'node:test';
import assert from 'node:assert/strict';
import {
  positivePossibilityFromZero, restorePossibility, recycleZero,
  arithmetic, returnState, lockSearchSnapshot, classifyMigration,
} from '../language/javascript/yoro-positive-possibility.mjs';

test('zero can be represented as a reversible possibility', () => {
  const p = positivePossibilityFromZero({ value: 0, sourceDigest: 'sha256:abc', byteOffset: 8, profileVersion: 'exchange/1' });
  assert.equal(p.token, '·');
  assert.equal(restorePossibility(p), 0);
});

test('nonzero cannot be silently converted to possibility', () => {
  assert.throws(() => positivePossibilityFromZero({ value: 4, sourceDigest: 'x', byteOffset: 0, profileVersion: '1' }));
});

test('recycled zero keeps its origin', () => {
  const p = positivePossibilityFromZero({ value: 0, sourceDigest: 'sha256:abc', byteOffset: 3, profileVersion: 'exchange/1' });
  const r = recycleZero(p);
  assert.equal(r.token, '♻️');
  assert.equal(r.byteOffset, 3);
});

test('division by zero is a known wrong, not a silent zero', () => {
  assert.equal(arithmetic('÷', 9, 0).reason, 'DivisionByZero');
  assert.equal(arithmetic('÷', 9, 0).kind, 'KnownWrong');
});

test('arithmetic preserves ordinary zero values', () => {
  assert.deepEqual(arithmetic('+', 0, 5), { kind: 'Value', value: 5, zeroPreserved: true });
  assert.equal(arithmetic('=', 0, 0).kind, 'Match');
});

test('nun and silent return are different states', () => {
  assert.equal(returnState('nun').kind, 'Nun');
  assert.equal(returnState('silent').kind, 'SilentReturn');
});

test('search snapshot locks evidence and scorer version', () => {
  const s = lockSearchSnapshot({ query: 'root lineage', corpusRevision: 'index:7', scorerVersion: 'ranker/2', score: 0.8, threshold: 0.75, evidenceRefs: ['src:a#L2'], lockedAt: '2026-11-19T18:00:00Z' });
  assert.equal(s.outcome, 'ThresholdMet');
  assert.equal(s.immutableSnapshot, true);
  assert.throws(() => s.score = 0.1);
});

test('lossy migration is never classified as lossless', () => {
  assert.equal(classifyMigration({ exactRecovery: false, informationRemoved: true }), 'Lossy');
  assert.equal(classifyMigration({ exactRecovery: true }), 'Lossless');
});
